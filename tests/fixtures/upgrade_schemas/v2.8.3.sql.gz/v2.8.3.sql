-- v2.8.3: revision d36d8a10ced39db2f729f4b1c03fc7718f48e7fa, its init.sql and its own startup (converted)
--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: attach_target_asset_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.attach_target_asset_owner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE locator text; owner_id uuid;
BEGIN
    IF NEW.url !~* '^https?://' OR NEW.discovery_source='model-intake' THEN RETURN NEW; END IF;
    locator := target_asset_locator(NEW.url);
    IF locator IS NULL THEN RETURN NEW; END IF;
    INSERT INTO targets(url,name,discovery_source,root_domain,metadata_json)
    VALUES(target_asset_url(locator),locator,'host',NEW.root_domain,
           jsonb_build_object('environment',COALESCE(NEW.metadata_json->>'environment',NEW.metadata_json->>'cohort','production')))
    ON CONFLICT(canonical_key) DO UPDATE SET url=targets.url
    RETURNING id INTO owner_id;
    UPDATE targets SET asset_owner_id=owner_id WHERE id=NEW.id AND asset_owner_id IS DISTINCT FROM owner_id;
    RETURN NEW;
END $$;


--
-- Name: bind_finding_observation_scans(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bind_finding_observation_scans() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    IF NEW.scan_id IS NOT NULL THEN
                        NEW.first_seen_scan_id = COALESCE(NEW.first_seen_scan_id, NEW.scan_id);
                        NEW.last_seen_scan_id = NEW.scan_id;
                    END IF;
                    RETURN NEW;
                END;
                $$;


--
-- Name: enforce_device_target_alias(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_device_target_alias() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.device_target_id IS NOT NULL THEN
        IF NEW.target_id IS NULL THEN NEW.target_id := NEW.device_target_id;
        ELSIF NEW.target_id <> NEW.device_target_id
              AND target_asset_owner(NEW.target_id) IS DISTINCT FROM NEW.device_target_id THEN
            RAISE EXCEPTION 'device and target references name different assets' USING ERRCODE='23514';
        END IF;
    END IF;
    RETURN NEW;
END $$;


--
-- Name: hunt_permission_baselines_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.hunt_permission_baselines_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    hunt_exists BOOLEAN;
BEGIN
    -- Only the Hunt's own deletion removes its baseline: the foreign-key cascade runs after the
    -- hunt_runs row is gone, and any other delete (from a statement or another trigger) finds
    -- the Hunt still there and is refused. hunt_runs is read from this table's own schema, never
    -- through the caller's search_path.
    IF TG_OP = 'DELETE' THEN
        EXECUTE format('SELECT EXISTS (SELECT 1 FROM %I.hunt_runs WHERE id = $1)', TG_TABLE_SCHEMA)
            INTO hunt_exists USING OLD.hunt_run_id;
        IF NOT hunt_exists THEN
            RETURN OLD;
        END IF;
    END IF;
    RAISE EXCEPTION 'hunt_permission_baselines is immutable';
END
$_$;


--
-- Name: hunt_permission_events_append_only(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.hunt_permission_events_append_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Deleting the Hunt cascades here from a referential trigger (depth > 1); nothing else may
    -- change or remove an audit row.
    IF TG_OP = 'DELETE' AND pg_trigger_depth() > 1 THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION 'hunt_permission_events is append-only';
END
$$;


--
-- Name: link_device_service_origin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.link_device_service_origin() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE locator text;
BEGIN
    IF NEW.web_origin IS NULL OR NEW.web_origin !~* '^https?://' THEN RETURN NEW; END IF;
    SELECT target_asset_locator(url) INTO locator FROM targets WHERE id=NEW.device_target_id;
    IF locator IS NULL OR target_asset_locator(NEW.web_origin) IS DISTINCT FROM locator THEN RETURN NEW; END IF;
    INSERT INTO targets(url,name,discovery_source,asset_owner_id)
    VALUES(NEW.web_origin,NEW.web_origin,'device-service',NEW.device_target_id)
    ON CONFLICT(canonical_key) DO NOTHING;
    RETURN NEW;
END $$;


--
-- Name: refresh_device_active_findings_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_device_active_findings_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    UPDATE device_targets d
                    SET active_findings_count=(
                        SELECT COUNT(*) FROM findings f
                        WHERE f.device_target_id=d.id AND f.status='active'
                    ), updated_at=NOW()
                    WHERE d.id IN (OLD.device_target_id, NEW.device_target_id);
                    RETURN NULL;
                END;
                $$;


--
-- Name: retire_asset_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retire_asset_members() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.is_active AND NOT NEW.is_active AND NEW.asset_owner_id IS NULL THEN
        UPDATE targets SET is_active=false,asm_enabled=false,updated_at=NOW()
          WHERE asset_owner_id=NEW.id AND is_active
            AND target_asset_locator(url)=target_asset_locator(NEW.url);
        UPDATE schedules SET is_active=false,next_run_at=NULL,updated_at=NOW()
          WHERE (is_active OR next_run_at IS NOT NULL) AND (target_id=NEW.id OR target_id IN (
            SELECT id FROM targets WHERE asset_owner_id=NEW.id
              AND target_asset_locator(url)=target_asset_locator(NEW.url)
          ));
    END IF;
    RETURN NEW;
END $$;


--
-- Name: target_asset_access_owner(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_asset_access_owner(value uuid) RETURNS uuid
    LANGUAGE sql STABLE STRICT
    AS $$
    SELECT CASE WHEN owner.id IS NOT NULL AND owner.is_active AND member.is_active
                      AND target_asset_locator(owner.url)=target_asset_locator(member.url)
                THEN owner.id ELSE member.id END
    FROM targets member LEFT JOIN targets owner ON owner.id=member.asset_owner_id
    WHERE member.id=value
$$;


--
-- Name: target_asset_locator(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_asset_locator(value text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE authority text; locator text;
BEGIN
    IF value !~* '^(https?|host)://' THEN RETURN NULL; END IF;
    authority := split_part(split_part(split_part(regexp_replace(value, '^[A-Za-z]+://', ''), '/', 1), '?', 1), '#', 1);
    IF authority LIKE '%@%' THEN RETURN NULL; END IF;
    IF left(authority, 1) = '[' THEN
        locator := split_part(substring(authority FROM 2), ']', 1);
    ELSE
        locator := split_part(authority, ':', 1);
    END IF;
    locator := lower(rtrim(locator, '.'));
    IF locator = '' THEN RETURN NULL; END IF;
    BEGIN
        RETURN host(locator::inet);
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN locator;
    END;
END $$;


--
-- Name: target_asset_owner(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_asset_owner(value uuid) RETURNS uuid
    LANGUAGE sql STABLE STRICT
    AS $$
    SELECT COALESCE(asset_owner_id, id) FROM targets WHERE id=value
$$;


--
-- Name: target_asset_url(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_asset_url(locator text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
    SELECT 'host://' || CASE WHEN strpos(locator, ':') > 0 THEN '[' || locator || ']' ELSE locator END
$$;


--
-- Name: target_collection_visible(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_collection_visible(collection uuid, consumer uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT COALESCE((
        SELECT b.is_active AND (
            target_asset_access_owner(c.target_id)=target_asset_access_owner(consumer)
            OR (t.is_active AND t.metadata_json->'hunt_authority'->>'target_url'=t.url
                AND COALESCE(t.metadata_json->'hunt_authority'->'collection_ids','[]'::jsonb)
                    ? collection::text)
        )
        FROM request_collection_bindings b JOIN request_collections c ON c.id=b.collection_id
        JOIN targets t ON t.id=target_asset_access_owner(consumer)
        WHERE b.collection_id=collection AND b.target_id=consumer
        ORDER BY b.updated_at DESC,b.id LIMIT 1
    ), (
        SELECT target_asset_access_owner(c.target_id)=target_asset_access_owner(consumer)
        FROM request_collections c WHERE c.id=collection
    ), false)
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: credential_profile_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_profile_bindings (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    binding_kind text NOT NULL,
    binding_id text NOT NULL,
    allowed_capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    granted_by text,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT credential_profile_bindings_allowed_capabilities_check CHECK ((jsonb_typeof(allowed_capabilities) = 'array'::text)),
    CONSTRAINT credential_profile_bindings_binding_kind_check CHECK ((binding_kind = ANY (ARRAY['target'::text, 'scan'::text, 'hunt'::text])))
);


--
-- Name: target_credential_grant(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_credential_grant(profile uuid, consumer uuid) RETURNS SETOF public.credential_profile_bindings
    LANGUAGE sql STABLE
    AS $$
    SELECT b.* FROM credential_profiles p JOIN credential_profile_bindings b
      ON b.profile_id=p.id AND b.binding_kind='target'
    WHERE p.id=profile AND b.binding_id=consumer::text
    LIMIT 1
$$;


--
-- Name: target_effective_authorization_target(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.target_effective_authorization_target(consumer uuid) RETURNS uuid
    LANGUAGE sql STABLE STRICT
    AS $$
    SELECT CASE WHEN t.authorization_inheritance
                     AND target_asset_access_owner(t.id) <> t.id
                     AND NOT EXISTS (
                         SELECT 1 FROM approval_receipts a JOIN scope_receipts s ON s.id=a.scope_receipt_id
                         WHERE s.target_id=t.id AND a.action_name='target.authorization'
                     )
                THEN target_asset_access_owner(t.id) ELSE t.id END
    FROM targets t WHERE t.id=consumer AND t.is_active
$$;


--
-- Name: targets_set_canonical_key(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.targets_set_canonical_key() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
        DECLARE raw TEXT; authority TEXT; host_part TEXT; port_part TEXT; scheme_part TEXT;
        BEGIN
            raw := lower(btrim(COALESCE(NEW.url, '')));
            IF lower(COALESCE(NEW.discovery_source, '')) = 'host' THEN
                host_part := regexp_replace(raw, '^host://', '');
                host_part := regexp_replace(host_part, '[/?#].*$', '');
                host_part := btrim(host_part, '[]');
                IF host_part = '' THEN RAISE EXCEPTION 'invalid host target locator'; END IF;
                NEW.url := CASE WHEN position(':' in host_part) > 0
                    THEN 'host://[' || host_part || ']' ELSE 'host://' || host_part END;
                NEW.canonical_key := 'host:' || host_part;
                IF NOT NEW.is_active THEN
                    NEW.url := NEW.url || '#retired=' || NEW.id::text;
                    NEW.canonical_key := NEW.canonical_key || ':retired:' || NEW.id::text;
                END IF;
                RETURN NEW;
            END IF;
            scheme_part := substring(raw FROM '^(https?)://');
            raw := regexp_replace(raw, '^https?://', '');
            IF lower(COALESCE(NEW.discovery_source, '')) = 'model-intake' THEN
                NEW.canonical_key := 'artifact:' || rtrim(raw, '/');
            ELSE
                authority := regexp_replace(raw, '[/?#].*$', '');
                authority := regexp_replace(authority, '^.*@', '');
                IF authority ~ '^\[[^]]+\]' THEN
                    host_part := substring(authority FROM '^\[([^]]+)\]');
                    port_part := substring(authority FROM '^\[[^]]+\]:([0-9]+)$');
                ELSE
                    host_part := regexp_replace(authority, ':[0-9]+$', '');
                    port_part := substring(authority FROM ':([0-9]+)$');
                END IF;
                IF port_part IS NULL OR (scheme_part='https' AND port_part='443')
                   OR (scheme_part='http' AND port_part='80')
                   OR (scheme_part IS NULL AND port_part IN ('80','443')) THEN
                    port_part := NULL;
                END IF;
                NEW.canonical_key := 'web:' || rtrim(host_part, '.') || COALESCE(':' || port_part, '');
            END IF;
            RETURN NEW;
        END; $_$;


--
-- Name: update_finding_timestamps(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_finding_timestamps() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    IF NEW.status = 'resolved' AND OLD.status != 'resolved' THEN
        NEW.resolved_at = NOW();
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: update_target_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_target_stats() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    IF NEW.status = 'completed'
                       AND NEW.target_id IS NOT NULL
                       AND COALESCE(NEW.scan_role, 'standalone') <> 'shard' THEN
                        UPDATE targets SET
                            last_scan_id = NEW.id,
                            last_scanned_at = NEW.completed_at,
                            last_score = NEW.score,
                            last_grade = NEW.grade,
                            last_assurance_score = NEW.assurance_score,
                            total_scans = total_scans + 1,
                            active_findings_count = (
                                SELECT COUNT(*) FROM findings
                                WHERE target_id = NEW.target_id AND status = 'active'
                            ),
                            updated_at = NOW()
                        WHERE id = NEW.target_id;
                    END IF;
                    RETURN NEW;
                END;
                $$;


--
-- Name: write_device_target_view(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.write_device_target_view() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE owner_id uuid; locator text; saved targets%ROWTYPE;
BEGIN
    IF TG_OP = 'DELETE' THEN
        DELETE FROM targets WHERE id=OLD.id;
        RETURN OLD;
    END IF;
    locator := target_asset_locator(target_asset_url(NEW.primary_locator));
    IF locator IS NULL THEN RAISE EXCEPTION 'device locator is invalid' USING ERRCODE='22023'; END IF;
    IF TG_OP = 'INSERT' THEN
        SELECT id INTO owner_id FROM targets WHERE canonical_key='host:' || locator FOR UPDATE;
        IF owner_id IS NOT NULL AND EXISTS (SELECT 1 FROM target_device_profiles WHERE target_id=owner_id) THEN
            RAISE EXCEPTION 'device profile already exists for this target' USING ERRCODE='23505';
        END IF;
        INSERT INTO targets (id,url,name,discovery_source,metadata_json,is_active,created_at,updated_at)
        VALUES (COALESCE(owner_id,NEW.id,gen_random_uuid()),target_asset_url(locator),COALESCE(NEW.name,locator),
                'host',COALESCE(NEW.metadata_json,'{}'::jsonb) || jsonb_build_object(
                    'environment',COALESCE(NEW.environment,'production'),
                    'cohort',COALESCE(NEW.metadata_json->>'cohort',NEW.environment,'production')),
                COALESCE(NEW.is_active,true),NOW(),NOW())
        ON CONFLICT (canonical_key) DO UPDATE SET
            name=EXCLUDED.name, metadata_json=targets.metadata_json || EXCLUDED.metadata_json,
            is_active=EXCLUDED.is_active,updated_at=NOW()
        RETURNING * INTO saved;
        NEW.id := saved.id;
        INSERT INTO target_device_profiles (
            target_id,device_class,manufacturer,model,firmware_version,stable_identity,
            identity_confidence,environment,policy_id,sensor_affinity,locator_generation
        ) VALUES (NEW.id,COALESCE(NEW.device_class,'generic'),NEW.manufacturer,NEW.model,
            NEW.firmware_version,NEW.stable_identity,COALESCE(NEW.identity_confidence,'low'),
            COALESCE(NEW.environment,'production'),NEW.policy_id,NEW.sensor_affinity,
            COALESCE(NEW.locator_generation,1));
    ELSE
        IF NEW.id <> OLD.id THEN RAISE EXCEPTION 'target identity is immutable' USING ERRCODE='22023'; END IF;
        UPDATE targets SET name=NEW.name,url=target_asset_url(locator),
            metadata_json=COALESCE(NEW.metadata_json,'{}'::jsonb) || jsonb_build_object('environment',NEW.environment),
            is_active=NEW.is_active,updated_at=NOW() WHERE id=OLD.id RETURNING * INTO saved;
        UPDATE target_device_profiles SET device_class=NEW.device_class,manufacturer=NEW.manufacturer,
            model=NEW.model,firmware_version=NEW.firmware_version,stable_identity=NEW.stable_identity,
            identity_confidence=NEW.identity_confidence,environment=NEW.environment,policy_id=NEW.policy_id,
            sensor_affinity=NEW.sensor_affinity,last_scanned_at=NEW.last_scanned_at,last_scan_id=NEW.last_scan_id,
            last_score=NEW.last_score,last_grade=NEW.last_grade,active_findings_count=NEW.active_findings_count,
            locator_generation=NEW.locator_generation,updated_at=NOW() WHERE target_id=OLD.id;
    END IF;
    SELECT * INTO NEW FROM device_targets WHERE id=saved.id;
    RETURN NEW;
END $$;


--
-- Name: agent_context_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_context_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    context_version text NOT NULL,
    target_id uuid,
    context_hash text NOT NULL,
    target_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    current_surface jsonb DEFAULT '{}'::jsonb NOT NULL,
    current_gaps jsonb DEFAULT '[]'::jsonb NOT NULL,
    hypotheses_summary jsonb DEFAULT '[]'::jsonb NOT NULL,
    findings_summary jsonb DEFAULT '[]'::jsonb NOT NULL,
    allowed_commands jsonb DEFAULT '[]'::jsonb NOT NULL,
    disallowed_commands jsonb DEFAULT '[]'::jsonb NOT NULL,
    known_preconditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    redaction_profile text DEFAULT 'agent-plan-default'::text NOT NULL,
    context_pack jsonb DEFAULT '{}'::jsonb NOT NULL,
    validation_errors jsonb DEFAULT '[]'::jsonb NOT NULL,
    validation_warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'recorded'::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_context_packs_status_check CHECK ((status = ANY (ARRAY['recorded'::text, 'invalid'::text])))
);


--
-- Name: agent_decision_traces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_decision_traces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    operation_plan_id uuid,
    context_pack_id uuid,
    planner jsonb DEFAULT '{}'::jsonb NOT NULL,
    context_hash text NOT NULL,
    command_schema_version text NOT NULL,
    steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    final_rationale text,
    redaction_profile text DEFAULT 'agent-trace-default'::text NOT NULL,
    validation_errors jsonb DEFAULT '[]'::jsonb NOT NULL,
    validation_warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'recorded'::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_decision_traces_status_check CHECK ((status = ANY (ARRAY['recorded'::text, 'invalid'::text])))
);


--
-- Name: agent_hunt_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_hunt_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    episode_id uuid,
    objective text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'awaiting_planner'::text NOT NULL,
    planner_mode text DEFAULT 'agent'::text NOT NULL,
    max_iterations integer DEFAULT 12 NOT NULL,
    allow_write boolean DEFAULT false NOT NULL,
    allow_active boolean DEFAULT false NOT NULL,
    approval_receipt_id uuid,
    token_budget integer DEFAULT 6000 NOT NULL,
    state jsonb DEFAULT '{}'::jsonb NOT NULL,
    planning_token uuid,
    stop_reason text,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_hunt_runs_status_check CHECK ((status = ANY (ARRAY['awaiting_planner'::text, 'planning'::text, 'completed'::text, 'cancelled'::text, 'failed'::text])))
);


--
-- Name: ai_surface_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_surface_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    surface_id uuid,
    scan_id uuid,
    probe_pack text,
    scan_profile text,
    environment text,
    families text[],
    status text,
    proof_state text,
    findings_count integer DEFAULT 0 NOT NULL,
    critical_high_count integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_surfaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_surfaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_target_id uuid,
    surface_type text DEFAULT 'api_chat'::text NOT NULL,
    endpoint_url text,
    auth_kind text,
    owner text,
    environment text,
    risk_tier text,
    data_classification text,
    tools_count integer DEFAULT 0 NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_seen timestamp with time zone,
    last_tested timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_target_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_target_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_target_id uuid NOT NULL,
    auth_kind text DEFAULT 'none'::text NOT NULL,
    header_name text,
    secret_value text,
    secret_preview text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rotated_at timestamp with time zone,
    CONSTRAINT ai_target_credentials_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['none'::text, 'bearer'::text, 'api_key_header'::text, 'custom_header'::text, 'basic_auth'::text, 'cookie'::text, 'multi_header'::text, 'query_param'::text])))
);


--
-- Name: ai_target_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_target_principals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_target_id uuid NOT NULL,
    label text NOT NULL,
    role text DEFAULT 'attacker'::text NOT NULL,
    tenant_id text,
    auth_kind text DEFAULT 'none'::text NOT NULL,
    header_name text,
    secret_value text,
    secret_preview text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    rotated_at timestamp with time zone,
    CONSTRAINT ai_target_principals_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['none'::text, 'bearer'::text, 'api_key_header'::text, 'custom_header'::text, 'basic_auth'::text, 'cookie'::text, 'multi_header'::text, 'query_param'::text]))),
    CONSTRAINT ai_target_principals_role_check CHECK ((role = ANY (ARRAY['attacker'::text, 'victim'::text, 'admin'::text, 'service'::text, 'observer'::text])))
);


--
-- Name: ai_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_targets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    target_type text DEFAULT 'api_chat'::text NOT NULL,
    endpoint_url text NOT NULL,
    method text DEFAULT 'POST'::text NOT NULL,
    headers_template jsonb DEFAULT '{}'::jsonb NOT NULL,
    request_template jsonb DEFAULT '{}'::jsonb NOT NULL,
    response_path text,
    streaming_mode text DEFAULT 'json'::text NOT NULL,
    rate_limit_rps integer,
    token_budget integer,
    request_budget integer,
    production_mode boolean DEFAULT false,
    last_scanned_at timestamp with time zone,
    last_scan_id uuid,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ai_targets_method_check CHECK ((method = ANY (ARRAY['GET'::text, 'POST'::text, 'PUT'::text, 'PATCH'::text]))),
    CONSTRAINT ai_targets_streaming_mode_check CHECK ((streaming_mode = ANY (ARRAY['json'::text, 'sse'::text]))),
    CONSTRAINT ai_targets_target_type_check CHECK ((target_type = ANY (ARRAY['api_chat'::text, 'widget'::text, 'rag'::text, 'agent_trace'::text, 'mcp_trace'::text])))
);


--
-- Name: app_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_schema_migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: application_graph_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_graph_edges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    src_key text NOT NULL,
    dst_key text NOT NULL,
    edge_type text NOT NULL,
    attributes jsonb,
    scan_id uuid,
    first_seen_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now()
);


--
-- Name: application_graph_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_graph_nodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    device_target_id uuid,
    node_type text NOT NULL,
    node_key text NOT NULL,
    label text,
    attributes jsonb,
    scan_id uuid,
    first_seen_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now()
);


--
-- Name: approval_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scope_receipt_id text,
    risk_tier text NOT NULL,
    confirmations jsonb DEFAULT '[]'::jsonb NOT NULL,
    action_name text,
    action_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    approved_by text,
    denial_reason text,
    expires_at timestamp with time zone,
    status text DEFAULT 'active'::text NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    revocation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT approval_receipts_approved_or_denied_check CHECK (((approved_by IS NOT NULL) OR (denial_reason IS NOT NULL))),
    CONSTRAINT approval_receipts_risk_check CHECK ((risk_tier = ANY (ARRAY['active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT approval_receipts_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


--
-- Name: asm_endpoint_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asm_endpoint_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    endpoint_id uuid NOT NULL,
    scan_id uuid,
    parent_scan_id uuid,
    campaign_id uuid,
    worker_id text,
    auth_state text DEFAULT 'anonymous'::text NOT NULL,
    check_family text DEFAULT 'all'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    status text NOT NULL,
    attempted_params_count integer DEFAULT 0 NOT NULL,
    completed_params_count integer DEFAULT 0 NOT NULL,
    finding_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    error_summary text,
    scanner_telemetry_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id uuid NOT NULL,
    owner_kind text NOT NULL,
    owner_id uuid NOT NULL,
    target_kind text NOT NULL,
    target_id uuid NOT NULL,
    target_binding_digest text NOT NULL,
    service_origin text,
    profile_id uuid NOT NULL,
    profile_version integer NOT NULL,
    principal_slot text NOT NULL,
    principal_label text,
    auth_kind text NOT NULL,
    compatible_capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    encrypted_headers text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    established_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    refresh_after timestamp with time zone NOT NULL,
    last_refreshed_at timestamp with time zone,
    refresh_count integer DEFAULT 0 NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason text,
    evidence_receipt_digest text NOT NULL,
    evidence_receipt_id uuid,
    source_action_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT auth_sessions_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['form_login'::text, 'oauth_client_credentials'::text, 'oauth_password'::text, 'json_login'::text]))),
    CONSTRAINT auth_sessions_compatible_capabilities_check CHECK ((jsonb_typeof(compatible_capabilities) = 'array'::text)),
    CONSTRAINT auth_sessions_encrypted_headers_check CHECK ((encrypted_headers ~~ 'enc:fernet:%'::text)),
    CONSTRAINT auth_sessions_evidence_receipt_digest_check CHECK ((evidence_receipt_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT auth_sessions_expiry_check CHECK (((established_at < expires_at) AND (refresh_after >= established_at) AND (refresh_after < expires_at))),
    CONSTRAINT auth_sessions_owner_kind_check CHECK ((owner_kind = ANY (ARRAY['scan'::text, 'hunt'::text]))),
    CONSTRAINT auth_sessions_principal_slot_check CHECK ((principal_slot = ANY (ARRAY['primary'::text, 'secondary'::text, 'service'::text]))),
    CONSTRAINT auth_sessions_profile_version_check CHECK ((profile_version > 0)),
    CONSTRAINT auth_sessions_refresh_count_check CHECK ((refresh_count >= 0)),
    CONSTRAINT auth_sessions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text, 'expired'::text]))),
    CONSTRAINT auth_sessions_target_binding_digest_check CHECK ((target_binding_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT auth_sessions_target_kind_check CHECK ((target_kind = ANY (ARRAY['web'::text, 'api'::text, 'network'::text, 'device'::text])))
);


--
-- Name: authenticated_profile_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authenticated_profile_revisions (
    profile_id uuid NOT NULL,
    revision integer NOT NULL,
    credential_version integer NOT NULL,
    credential_record_version integer CONSTRAINT authenticated_profile_revisi_credential_record_version_not_null NOT NULL,
    configuration_json jsonb NOT NULL,
    configuration_digest text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text NOT NULL,
    CONSTRAINT authenticated_profile_revisions_configuration_digest_check CHECK ((configuration_digest ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT authenticated_profile_revisions_configuration_json_check CHECK ((jsonb_typeof(configuration_json) = 'object'::text)),
    CONSTRAINT authenticated_profile_revisions_credential_record_version_check CHECK ((credential_record_version >= 0)),
    CONSTRAINT authenticated_profile_revisions_credential_version_check CHECK ((credential_version > 0)),
    CONSTRAINT authenticated_profile_revisions_revision_check CHECK ((revision > 0))
);


--
-- Name: authentication_validation_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_validation_requests (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    revision integer NOT NULL,
    approval_receipt_id uuid NOT NULL,
    target_binding_json jsonb NOT NULL,
    process_generation uuid NOT NULL,
    expected_build_fingerprint text CONSTRAINT authentication_validation_r_expected_build_fingerprint_not_null NOT NULL,
    allow_insecure_transport boolean DEFAULT false CONSTRAINT authentication_validation_req_allow_insecure_transport_not_null NOT NULL,
    status text NOT NULL,
    reason_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deadline_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_by text NOT NULL,
    worker_id text,
    budget_used_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    reservation_id text NOT NULL,
    validation_record_id uuid,
    CONSTRAINT authentication_validation_requests_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: authentication_validations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_validations (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    revision integer NOT NULL,
    record_json jsonb NOT NULL,
    checked_at timestamp with time zone NOT NULL,
    CONSTRAINT authentication_validations_record_json_check CHECK ((jsonb_typeof(record_json) = 'object'::text))
);


--
-- Name: broker_job_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broker_job_leases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    node_id uuid NOT NULL,
    worker_id text NOT NULL,
    queue_name text NOT NULL,
    stream_key text NOT NULL,
    message_id text NOT NULL,
    consumer_name text NOT NULL,
    lease_token_hash text NOT NULL,
    payload_sha256 text NOT NULL,
    budget_reservation jsonb DEFAULT '{}'::jsonb NOT NULL,
    job_id text,
    scan_id uuid,
    status text DEFAULT 'leased'::text NOT NULL,
    delivery_attempts integer DEFAULT 1 NOT NULL,
    lease_expires_at timestamp with time zone NOT NULL,
    last_heartbeat_at timestamp with time zone DEFAULT now() NOT NULL,
    ingest_enqueued_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT broker_job_leases_status_check CHECK ((status = ANY (ARRAY['leased'::text, 'submitted'::text, 'ingesting'::text, 'completed'::text, 'failed'::text, 'cancelled'::text, 'lost'::text])))
);


--
-- Name: broker_job_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broker_job_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lease_id uuid NOT NULL,
    result_sha256 text NOT NULL,
    result jsonb NOT NULL,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    ingested_at timestamp with time zone
);


--
-- Name: budget_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_reservations (
    id text NOT NULL,
    owner_kind text NOT NULL,
    owner_id text NOT NULL,
    action_id text NOT NULL,
    action_digest text NOT NULL,
    capability_name text NOT NULL,
    status text NOT NULL,
    requested_json jsonb NOT NULL,
    actual_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    hold_applied boolean DEFAULT false NOT NULL,
    worker_id text,
    lease_expires_at timestamp with time zone,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    execution_receipt_hash text,
    failure_reason text,
    execution_uncertain boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    state_digest text NOT NULL,
    state_json jsonb NOT NULL,
    ledger_after_hold_json jsonb,
    ledger_after_settlement_json jsonb,
    receipt_json jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT budget_reservations_action_digest_check CHECK ((action_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT budget_reservations_actual_json_check CHECK ((jsonb_typeof(actual_json) = 'object'::text)),
    CONSTRAINT budget_reservations_committed_receipt_check CHECK (((status <> 'committed'::text) OR (execution_receipt_hash ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT budget_reservations_ledger_after_hold_json_check CHECK (((ledger_after_hold_json IS NULL) OR (jsonb_typeof(ledger_after_hold_json) = 'object'::text))),
    CONSTRAINT budget_reservations_ledger_after_settlement_json_check CHECK (((ledger_after_settlement_json IS NULL) OR (jsonb_typeof(ledger_after_settlement_json) = 'object'::text))),
    CONSTRAINT budget_reservations_owner_kind_check CHECK ((owner_kind = ANY (ARRAY['scan'::text, 'hunt'::text, 'validation'::text]))),
    CONSTRAINT budget_reservations_receipt_json_check CHECK (((receipt_json IS NULL) OR (jsonb_typeof(receipt_json) = 'object'::text))),
    CONSTRAINT budget_reservations_requested_json_check CHECK ((jsonb_typeof(requested_json) = 'object'::text)),
    CONSTRAINT budget_reservations_runtime_state_check CHECK ((((status = 'requested'::text) AND (hold_applied = false) AND (worker_id IS NULL) AND (lease_expires_at IS NULL) AND (started_at IS NULL) AND (finished_at IS NULL)) OR ((status = 'reserved'::text) AND (hold_applied = true) AND (worker_id IS NULL) AND (lease_expires_at IS NOT NULL) AND (started_at IS NULL) AND (finished_at IS NULL)) OR ((status = 'running'::text) AND (hold_applied = true) AND (worker_id IS NOT NULL) AND (lease_expires_at IS NOT NULL) AND (started_at IS NOT NULL) AND (finished_at IS NULL)) OR ((status = ANY (ARRAY['committed'::text, 'released'::text, 'failed'::text])) AND (lease_expires_at IS NULL) AND (finished_at IS NOT NULL)))),
    CONSTRAINT budget_reservations_state_digest_check CHECK ((state_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT budget_reservations_state_json_check CHECK ((jsonb_typeof(state_json) = 'object'::text)),
    CONSTRAINT budget_reservations_status_check CHECK ((status = ANY (ARRAY['requested'::text, 'reserved'::text, 'running'::text, 'committed'::text, 'released'::text, 'failed'::text]))),
    CONSTRAINT budget_reservations_uncertain_check CHECK (((execution_uncertain = false) OR ((status = 'failed'::text) AND (hold_applied = true)))),
    CONSTRAINT budget_reservations_version_check CHECK ((version > 0))
);


--
-- Name: campaign_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    campaign_id uuid,
    operation_plan_id uuid,
    command_result_id uuid,
    target_id uuid,
    submission_id uuid,
    scope_receipt_id text,
    approval_receipt_id uuid,
    scan_id uuid,
    command text NOT NULL,
    action_name text NOT NULL,
    status text NOT NULL,
    dry_run boolean DEFAULT false NOT NULL,
    risk_tier text DEFAULT 'read_only'::text NOT NULL,
    finding_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    hypothesis_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    evidence_object_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_receipt_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocked_by jsonb DEFAULT '[]'::jsonb NOT NULL,
    next_action text,
    operator_message text,
    result_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    mission_campaign_id uuid,
    CONSTRAINT campaign_actions_risk_check CHECK ((risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT campaign_actions_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'blocked'::text, 'approval_required'::text, 'approved'::text, 'queued'::text, 'running'::text, 'completed'::text, 'partial'::text, 'degraded'::text, 'failed'::text, 'cancelled'::text, 'evidence_bound'::text, 'retest_scheduled'::text, 'refuter_requested'::text])))
);


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaigns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    objective text NOT NULL,
    campaign_type text NOT NULL,
    target_id uuid,
    target_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_tier text DEFAULT 'read_only'::text NOT NULL,
    policy_profile text,
    planner jsonb DEFAULT '{}'::jsonb NOT NULL,
    operation_plan_id uuid,
    context_hash text,
    status text DEFAULT 'planned'::text NOT NULL,
    deployment_impact jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaigns_risk_check CHECK ((risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT campaigns_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'active'::text, 'paused'::text, 'completed'::text, 'cancelled'::text]))),
    CONSTRAINT campaigns_type_check CHECK ((campaign_type = ANY (ARRAY['continuous_asm'::text, 'authenticated_dast'::text, 'api_authz'::text, 'ai_red_team'::text, 'model_intake'::text, 'benchmark'::text, 'incident_retest'::text, 'source_informed_dast'::text, 'finding_retest'::text, 'focused_family'::text, 'autonomous_research'::text])))
);


--
-- Name: command_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    command text NOT NULL,
    status text NOT NULL,
    dry_run boolean DEFAULT false NOT NULL,
    risk_tier text DEFAULT 'read_only'::text NOT NULL,
    operation_plan_id uuid,
    scope_receipt_id text,
    approval_receipt_id uuid,
    campaign_id uuid,
    scan_id uuid,
    finding_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    hypothesis_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    evidence_object_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_receipt_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocked_by jsonb DEFAULT '[]'::jsonb NOT NULL,
    next_action text,
    operator_message text NOT NULL,
    result_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT command_results_risk_check CHECK ((risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT command_results_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'blocked'::text, 'approval_required'::text, 'approved'::text, 'queued'::text, 'running'::text, 'completed'::text, 'partial'::text, 'degraded'::text, 'failed'::text, 'cancelled'::text, 'evidence_bound'::text, 'retest_scheduled'::text, 'refuter_requested'::text])))
);


--
-- Name: credential_profile_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_profile_versions (
    profile_id uuid NOT NULL,
    version integer NOT NULL,
    auth_kind text NOT NULL,
    encrypted_secret text NOT NULL,
    encrypted_metadata text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT credential_profile_versions_encrypted_metadata_check CHECK ((encrypted_metadata ~~ 'enc:fernet:%'::text)),
    CONSTRAINT credential_profile_versions_encrypted_secret_check CHECK ((encrypted_secret ~~ 'enc:fernet:%'::text)),
    CONSTRAINT credential_profile_versions_version_check CHECK ((version > 0))
);


--
-- Name: credential_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_profiles (
    id uuid NOT NULL,
    target_kind text NOT NULL,
    target_id uuid NOT NULL,
    name text NOT NULL,
    auth_kind text NOT NULL,
    principal_label text,
    principal_slot text NOT NULL,
    configuration_json jsonb NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    record_version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    rotated_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    service_port integer,
    CONSTRAINT credential_profiles_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['authorization_header'::text, 'bearer_token'::text, 'api_key_header'::text, 'cookie'::text, 'basic_auth'::text, 'form_login'::text, 'oauth_client_credentials'::text, 'oauth_password'::text, 'json_login'::text, 'custom_headers'::text, 'query_parameter'::text, 'ssh_password'::text, 'ssh_private_key'::text, 'ssh_private_key_with_passphrase'::text]))),
    CONSTRAINT credential_profiles_configuration_json_check CHECK ((jsonb_typeof(configuration_json) = 'object'::text)),
    CONSTRAINT credential_profiles_current_version_check CHECK ((current_version > 0)),
    CONSTRAINT credential_profiles_expiry_check CHECK (((expires_at IS NULL) OR (expires_at > created_at))),
    CONSTRAINT credential_profiles_principal_slot_check CHECK ((principal_slot = ANY (ARRAY['primary'::text, 'secondary'::text, 'service'::text, 'ssh'::text]))),
    CONSTRAINT credential_profiles_record_version_check CHECK ((record_version > 0)),
    CONSTRAINT credential_profiles_service_port_check CHECK (((service_port >= 1) AND (service_port <= 65535))),
    CONSTRAINT credential_profiles_target_kind_check CHECK ((target_kind = ANY (ARRAY['web'::text, 'api'::text, 'network'::text, 'device'::text])))
);


--
-- Name: findings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.findings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid,
    first_seen_scan_id uuid,
    last_seen_scan_id uuid,
    target_id uuid,
    ai_target_id uuid,
    device_target_id uuid,
    hunt_run_id uuid,
    fingerprint text NOT NULL,
    title text NOT NULL,
    description text,
    severity text NOT NULL,
    cvss_score numeric(3,1),
    tool text,
    cwe text,
    cwe_name text,
    owasp text,
    url text,
    evidence jsonb,
    request text,
    response text,
    status text DEFAULT 'active'::text,
    first_seen_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    resurfaced_count integer DEFAULT 0,
    ai_verdict text,
    ai_confidence numeric(3,2),
    ai_rationale text,
    ai_recommendations jsonb,
    notes text,
    last_verification_status text,
    last_verification_verdict text,
    last_verification_confidence numeric(3,2),
    last_verified_at timestamp with time zone,
    verification_count integer DEFAULT 0,
    source text DEFAULT 'scan'::text,
    session_id text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    ai_classification_source text,
    analyst_verdict text,
    analyst_verdict_at timestamp with time zone,
    analyst_verdict_notes text
);


--
-- Name: scans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    target_url text NOT NULL,
    job_id text,
    worker_id text,
    executing_node_id uuid,
    execution_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    scan_job_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    scan_job_digest text,
    status text DEFAULT 'pending'::text NOT NULL,
    progress integer DEFAULT 0,
    current_phase text,
    options jsonb DEFAULT '{}'::jsonb,
    scan_type text DEFAULT 'quick'::text,
    scan_generation text DEFAULT 'legacy'::text NOT NULL,
    policy_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    budget_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    budget_used_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    scan_action_plan_json jsonb,
    scan_action_plan_digest text,
    scan_action_plan_schema text,
    scan_continuation_allocation_json jsonb,
    scan_continuation_allocation_digest text,
    scan_continuation_applied_at timestamp with time zone,
    coverage_status text,
    coverage_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    domain_rate_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    run_kind text DEFAULT 'web_dast'::text NOT NULL,
    subject_ref text,
    result jsonb,
    score integer,
    grade text,
    assurance_score integer,
    findings_count integer DEFAULT 0,
    baseline_scan_id uuid,
    delta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_seconds integer,
    error_message text,
    retry_count integer DEFAULT 0,
    parent_scan_id uuid,
    scan_role text DEFAULT 'standalone'::text NOT NULL,
    shard_index integer,
    shard_count integer,
    ai_target_id uuid,
    device_target_id uuid,
    campaign_id uuid,
    CONSTRAINT scans_run_kind_check CHECK ((run_kind = ANY (ARRAY['web_dast'::text, 'ai_api'::text, 'ai_widget'::text, 'ai_rag'::text, 'ai_trace'::text, 'ai_mcp'::text, 'model_intake'::text, 'device_posture'::text, 'device_probe'::text, 'device_web_dast'::text])))
);


--
-- Name: latest_scans; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.latest_scans AS
 SELECT DISTINCT ON (target_url) id,
    target_id,
    target_url,
    job_id,
    worker_id,
    executing_node_id,
    execution_context,
    scan_job_payload,
    scan_job_digest,
    status,
    progress,
    current_phase,
    options,
    scan_type,
    scan_generation,
    policy_json,
    budget_json,
    budget_used_json,
    scan_action_plan_json,
    scan_action_plan_digest,
    scan_action_plan_schema,
    scan_continuation_allocation_json,
    scan_continuation_allocation_digest,
    scan_continuation_applied_at,
    coverage_status,
    coverage_json,
    domain_rate_json,
    run_kind,
    subject_ref,
    result,
    score,
    grade,
    assurance_score,
    findings_count,
    baseline_scan_id,
    delta,
    created_at,
    started_at,
    completed_at,
    duration_seconds,
    error_message,
    retry_count,
    parent_scan_id,
    scan_role,
    shard_index,
    shard_count,
    ai_target_id,
    device_target_id,
    campaign_id
   FROM public.scans
  WHERE ((status = 'completed'::text) AND ((scan_role IS NULL) OR (scan_role <> 'shard'::text)) AND (COALESCE(run_kind, 'web_dast'::text) <> ALL (ARRAY['device_posture'::text, 'device_probe'::text, 'device_web_dast'::text])))
  ORDER BY target_url, completed_at DESC;


--
-- Name: targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.targets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    url text NOT NULL,
    canonical_key text,
    name text,
    root_domain text,
    is_root boolean DEFAULT false,
    discovery_source text DEFAULT 'manual'::text,
    parent_target_id uuid,
    is_active boolean DEFAULT true,
    scan_options jsonb DEFAULT '{}'::jsonb,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    asm_enabled boolean DEFAULT false NOT NULL,
    asm_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    asm_last_test_at timestamp with time zone,
    asm_last_recon_at timestamp with time zone,
    last_scan_id uuid,
    last_scanned_at timestamp with time zone,
    last_score integer,
    last_grade text,
    last_assurance_score integer,
    total_scans integer DEFAULT 0,
    active_findings_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    asset_owner_id uuid,
    authorization_inheritance boolean DEFAULT true NOT NULL,
    CONSTRAINT targets_asset_not_self CHECK (((asset_owner_id IS NULL) OR (asset_owner_id <> id)))
);


--
-- Name: dashboard_metrics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.dashboard_metrics AS
 SELECT ( SELECT count(*) AS count
           FROM public.targets
          WHERE ((targets.is_active = true) AND (COALESCE(targets.discovery_source, 'manual'::text) <> 'model-intake'::text))) AS total_targets,
    ( SELECT count(*) AS count
           FROM public.scans
          WHERE ((scans.status = 'completed'::text) AND ((scans.scan_role IS NULL) OR (scans.scan_role <> 'shard'::text)) AND (COALESCE(scans.run_kind, 'web_dast'::text) <> ALL (ARRAY['device_posture'::text, 'device_probe'::text, 'device_web_dast'::text])))) AS total_scans,
    ( SELECT count(*) AS count
           FROM public.scans
          WHERE ((scans.status = 'running'::text) AND ((scans.scan_role IS NULL) OR (scans.scan_role <> 'shard'::text)) AND (COALESCE(scans.run_kind, 'web_dast'::text) <> ALL (ARRAY['device_posture'::text, 'device_probe'::text, 'device_web_dast'::text])))) AS running_scans,
    ( SELECT count(*) AS count
           FROM public.findings
          WHERE ((findings.status = 'active'::text) AND (COALESCE(findings.source, 'scan'::text) <> 'device'::text))) AS active_findings,
    ( SELECT count(*) AS count
           FROM public.findings
          WHERE ((findings.status = 'active'::text) AND (findings.severity = 'critical'::text) AND (COALESCE(findings.source, 'scan'::text) <> 'device'::text))) AS critical_findings,
    ( SELECT count(*) AS count
           FROM public.findings
          WHERE ((findings.status = 'active'::text) AND (findings.severity = 'high'::text) AND (COALESCE(findings.source, 'scan'::text) <> 'device'::text))) AS high_findings,
    ( SELECT avg(latest_scans.score) AS avg
           FROM public.latest_scans) AS avg_score;


--
-- Name: device_agent_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_agent_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    device_target_id uuid NOT NULL,
    tool_name text NOT NULL,
    tool_tier integer NOT NULL,
    fragility_cost integer DEFAULT 0 NOT NULL,
    rationale text,
    evidence_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    outcome text NOT NULL,
    result_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    target_id uuid,
    CONSTRAINT device_agent_actions_fragility_cost_check CHECK (((fragility_cost >= 0) AND (fragility_cost <= 100))),
    CONSTRAINT device_agent_actions_outcome_check CHECK ((outcome = ANY (ARRAY['completed'::text, 'blocked'::text, 'failed'::text]))),
    CONSTRAINT device_agent_actions_tool_tier_check CHECK (((tool_tier >= 0) AND (tool_tier <= 3)))
);


--
-- Name: device_agent_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_agent_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_target_id uuid NOT NULL,
    objective text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'awaiting_planner'::text NOT NULL,
    planner_mode text DEFAULT 'agent'::text NOT NULL,
    safety_profile text DEFAULT 'safe_remote'::text NOT NULL,
    max_turns integer DEFAULT 12 NOT NULL,
    approval_receipt_id uuid,
    state jsonb DEFAULT '{}'::jsonb NOT NULL,
    planning_token uuid,
    stop_reason text,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    target_id uuid,
    CONSTRAINT device_agent_runs_max_turns_check CHECK (((max_turns >= 1) AND (max_turns <= 30))),
    CONSTRAINT device_agent_runs_planner_mode_check CHECK ((planner_mode = 'agent'::text)),
    CONSTRAINT device_agent_runs_safety_check CHECK ((safety_profile = ANY (ARRAY['observe_only'::text, 'safe_remote'::text, 'authenticated_active'::text, 'lab_invasive'::text]))),
    CONSTRAINT device_agent_runs_status_check CHECK ((status = ANY (ARRAY['awaiting_planner'::text, 'planning'::text, 'completed'::text, 'cancelled'::text, 'failed'::text])))
);


--
-- Name: device_credential_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_credential_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_target_id uuid NOT NULL,
    credential_profile_id uuid NOT NULL,
    scan_id uuid,
    outcome text NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    target_id uuid,
    CONSTRAINT device_credential_attempts_outcome_check CHECK ((outcome = ANY (ARRAY['succeeded'::text, 'rejected'::text, 'error'::text])))
);


--
-- Name: target_device_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_device_profiles (
    target_id uuid NOT NULL,
    device_class text DEFAULT 'generic'::text NOT NULL,
    manufacturer text,
    model text,
    firmware_version text,
    stable_identity text,
    identity_confidence text DEFAULT 'low'::text NOT NULL,
    environment text DEFAULT 'production'::text NOT NULL,
    policy_id uuid,
    sensor_affinity text,
    last_scanned_at timestamp with time zone,
    last_scan_id uuid,
    last_score integer,
    last_grade text,
    active_findings_count integer DEFAULT 0 NOT NULL,
    locator_generation integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT target_device_profiles_identity_confidence_check CHECK ((identity_confidence = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'verified'::text]))),
    CONSTRAINT target_device_profiles_locator_generation_check CHECK ((locator_generation >= 1))
);


--
-- Name: device_credential_profiles; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.device_credential_profiles AS
 SELECT p.id,
    d.target_id AS device_target_id,
    d.target_id,
    p.target_id AS home_target_id,
    p.name,
        CASE p.auth_kind
            WHEN 'ssh_password'::text THEN 'ssh_password'::text
            WHEN 'ssh_private_key'::text THEN 'ssh_private_key'::text
            WHEN 'ssh_private_key_with_passphrase'::text THEN 'ssh_private_key'::text
            WHEN 'cookie'::text THEN 'web_cookie'::text
            WHEN 'form_login'::text THEN 'web_form'::text
            ELSE 'web_authorization_header'::text
        END AS auth_kind,
    p.auth_kind AS canonical_auth_kind,
    NULL::text AS username,
    v.encrypted_secret AS secret_value,
    NULL::text AS secret_preview,
    NULL::text AS login_path,
    p.service_port AS port,
    p.expires_at,
    (p.is_active AND b.is_active AND (b.revoked_at IS NULL)) AS is_active,
    '{}'::jsonb AS metadata_json,
    p.current_version,
    p.record_version,
    b.allowed_capabilities,
    p.rotated_at,
    p.created_at,
    p.updated_at
   FROM (((public.target_device_profiles d
     CROSS JOIN public.credential_profiles p)
     JOIN LATERAL public.target_credential_grant(p.id, d.target_id) b(id, profile_id, binding_kind, binding_id, allowed_capabilities, is_active, granted_by, revoked_at, created_at, updated_at) ON (true))
     JOIN public.credential_profile_versions v ON (((v.profile_id = p.id) AND (v.version = p.current_version))));


--
-- Name: device_interfaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_interfaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_target_id uuid NOT NULL,
    interface_type text DEFAULT 'network'::text NOT NULL,
    locator_type text DEFAULT 'ip'::text NOT NULL,
    locator text NOT NULL,
    mac_address text,
    hostname text,
    network_zone text,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    target_id uuid
);


--
-- Name: device_locator_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_locator_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_target_id uuid NOT NULL,
    previous_locator text,
    locator text NOT NULL,
    locator_type text NOT NULL,
    change_reason text,
    change_source text DEFAULT 'operator'::text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    target_id uuid
);


--
-- Name: device_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    device_class text DEFAULT 'generic'::text NOT NULL,
    environment text DEFAULT 'production'::text NOT NULL,
    rules jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: request_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_collections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    device_target_id uuid,
    name text NOT NULL,
    format text NOT NULL,
    schema_version text DEFAULT 'request-collection/v2'::text NOT NULL,
    encrypted_payload text NOT NULL,
    payload_sha256 text NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    safe_request_count integer DEFAULT 0 NOT NULL,
    potentially_mutating_request_count integer DEFAULT 0 NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT request_collections_target_check CHECK (((target_id IS NOT NULL) AND ((device_target_id IS NULL) OR (device_target_id = target_id))))
);


--
-- Name: device_request_collections; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.device_request_collections AS
 SELECT c.id,
    d.target_id AS device_target_id,
    d.target_id,
    c.target_id AS home_target_id,
    c.name,
    c.format,
    c.payload_sha256 AS document_sha256,
    c.encrypted_payload,
    (c.metadata_json || jsonb_build_object('request_count', c.request_count, 'state_changing_request_count', c.potentially_mutating_request_count, 'document_sha256', c.payload_sha256)) AS summary_json,
    c.is_active,
    c.created_at,
    c.updated_at
   FROM (public.target_device_profiles d
     JOIN public.request_collections c ON (public.target_collection_visible(c.id, d.target_id)));


--
-- Name: device_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_target_id uuid NOT NULL,
    scan_id uuid,
    interface_id uuid,
    transport text NOT NULL,
    port integer NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    service_name text DEFAULT 'unknown'::text NOT NULL,
    product text,
    version text,
    cpe text,
    encrypted boolean,
    web_origin text,
    policy_disposition text,
    policy_reason text,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    target_id uuid,
    CONSTRAINT device_services_policy_disposition_check CHECK (((policy_disposition IS NULL) OR (policy_disposition = ANY (ARRAY['allow'::text, 'deny'::text, 'review'::text, 'require'::text, 'not_evaluated'::text])))),
    CONSTRAINT device_services_port_check CHECK (((port >= 1) AND (port <= 65535))),
    CONSTRAINT device_services_state_check CHECK ((state = ANY (ARRAY['open'::text, 'open|filtered'::text, 'not_observed'::text]))),
    CONSTRAINT device_services_transport_check CHECK ((transport = ANY (ARRAY['tcp'::text, 'udp'::text])))
);


--
-- Name: device_targets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.device_targets AS
 SELECT t.id,
    t.name,
    public.target_asset_locator(t.url) AS primary_locator,
    p.device_class,
    p.manufacturer,
    p.model,
    p.firmware_version,
    p.stable_identity,
    p.identity_confidence,
    COALESCE((t.metadata_json ->> 'environment'::text), (t.metadata_json ->> 'cohort'::text), p.environment) AS environment,
    p.policy_id,
    p.sensor_affinity,
    t.metadata_json,
    p.last_scanned_at,
    p.last_scan_id,
    p.last_score,
    p.last_grade,
    p.active_findings_count,
    p.locator_generation,
    t.is_active,
    t.created_at,
    GREATEST(t.updated_at, p.updated_at) AS updated_at
   FROM (public.targets t
     JOIN public.target_device_profiles p ON ((p.target_id = t.id)));


--
-- Name: discovery_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discovery_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    root_domain text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    subdomains_found integer DEFAULT 0,
    new_subdomains integer DEFAULT 0,
    result jsonb,
    sources_used jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    requested_by text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: evidence_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_instances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    finding_id uuid,
    evidence_object_id uuid,
    scan_id uuid,
    target_id uuid,
    concrete_url text,
    object_id text,
    payload_variant text,
    request_response_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    principal_pair jsonb DEFAULT '{}'::jsonb NOT NULL,
    proof_observation jsonb DEFAULT '{}'::jsonb NOT NULL,
    campaign_action_id uuid,
    tool_receipt_id uuid,
    redaction_profile text DEFAULT 'redact_sensitive_v1'::text NOT NULL,
    hash text NOT NULL,
    retention_policy text DEFAULT 'standard'::text NOT NULL,
    proof_state text DEFAULT 'unverified'::text NOT NULL,
    evidence_strength text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    candidate_id uuid,
    device_target_id uuid,
    research_episode_id uuid,
    device_agent_run_id uuid,
    contract_id text,
    contract_version text,
    proof_basis text,
    CONSTRAINT evidence_instances_proof_state_check CHECK ((proof_state = ANY (ARRAY['verified'::text, 'suspected'::text, 'unverified'::text, 'refuted'::text, 'inconclusive'::text]))),
    CONSTRAINT evidence_instances_retention_check CHECK ((retention_policy = ANY (ARRAY['standard'::text, 'short'::text, 'audit'::text, 'legal_hold'::text, 'sensitive'::text]))),
    CONSTRAINT evidence_instances_strength_check CHECK (((evidence_strength IS NULL) OR (evidence_strength = ANY (ARRAY['claimed'::text, 'signal'::text, 'reproduced'::text, 'cross_principal_verified'::text]))))
);


--
-- Name: evidence_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid,
    finding_id uuid,
    object_type text DEFAULT 'finding_evidence'::text NOT NULL,
    content_sha256 text,
    size_bytes integer,
    storage_uri text,
    redaction_profile text,
    retention_class text DEFAULT 'standard'::text NOT NULL,
    content jsonb,
    retention_delete_preview_id uuid,
    retention_delete_pending_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: evidence_retention_previews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_retention_previews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    schema_version integer NOT NULL,
    criteria_json jsonb NOT NULL,
    candidate_snapshot_json jsonb NOT NULL,
    preview_hash text NOT NULL,
    policy_hash text NOT NULL,
    status text DEFAULT 'ready'::text NOT NULL,
    approval_receipt_id uuid,
    scope_receipt_id text,
    operation_id uuid,
    result_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    execution_started_at timestamp with time zone,
    consumed_at timestamp with time zone,
    CONSTRAINT evidence_retention_previews_status_check CHECK ((status = ANY (ARRAY['ready'::text, 'executing'::text, 'consumed'::text, 'stale'::text])))
);


--
-- Name: export_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.export_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    export_kind text NOT NULL,
    command text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    risk_tier text DEFAULT 'read_only'::text NOT NULL,
    target_id uuid,
    scan_id uuid,
    finding_id uuid,
    bundle_hash text,
    manifest_hash text,
    object_count integer DEFAULT 0 NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    evidence_object_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    finding_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    scan_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    replay_plan jsonb DEFAULT '{}'::jsonb NOT NULL,
    operator_message text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT export_events_risk_check CHECK ((risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT export_events_status_check CHECK ((status = ANY (ARRAY['completed'::text, 'partial'::text, 'degraded'::text, 'failed'::text])))
);


--
-- Name: finding_exceptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finding_exceptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    finding_id text,
    fingerprint text,
    policy_id uuid,
    target_id uuid,
    scope text,
    owner text,
    approver text,
    reason text,
    compensating_controls text,
    status text DEFAULT 'active'::text NOT NULL,
    expires_at timestamp with time zone,
    edit_history jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT finding_exceptions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'approved'::text, 'accepted_risk'::text, 'revoked'::text, 'expired'::text])))
);


--
-- Name: finding_hunt_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finding_hunt_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    finding_id uuid NOT NULL,
    hunt_run_id uuid NOT NULL,
    action_id uuid NOT NULL,
    role text NOT NULL,
    verified_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT finding_hunt_verifications_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'additional'::text])))
);


--
-- Name: finding_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finding_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    finding_id uuid,
    scan_id uuid,
    target_id uuid,
    job_id text,
    requested_by text DEFAULT 'api'::text,
    status text DEFAULT 'queued'::text NOT NULL,
    result_status text,
    verdict text,
    verdict_reason text,
    finding_type text NOT NULL,
    target_url text NOT NULL,
    original_url text,
    param text,
    payload text,
    method text,
    request_body text,
    replay_commands jsonb,
    auth_context jsonb,
    proof jsonb,
    artifacts jsonb,
    confidence numeric(3,2),
    attempt_count integer DEFAULT 0,
    attempts_exhausted boolean DEFAULT false,
    retry_class text,
    retryable boolean DEFAULT false,
    message text,
    error_message text,
    verification_mode text DEFAULT 'deterministic'::text,
    ai_plan jsonb,
    ai_reasoning text,
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    campaign_id uuid,
    candidate_id uuid,
    device_target_id uuid,
    research_episode_id uuid,
    device_agent_run_id uuid,
    contract_id text,
    contract_version text,
    proof_basis text,
    traffic_receipt_id uuid
);


--
-- Name: findings_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.findings_summary AS
 SELECT target_id,
    count(*) FILTER (WHERE ((severity = 'critical'::text) AND (status = 'active'::text))) AS critical_count,
    count(*) FILTER (WHERE ((severity = 'high'::text) AND (status = 'active'::text))) AS high_count,
    count(*) FILTER (WHERE ((severity = 'medium'::text) AND (status = 'active'::text))) AS medium_count,
    count(*) FILTER (WHERE ((severity = 'low'::text) AND (status = 'active'::text))) AS low_count,
    count(*) FILTER (WHERE ((severity = 'info'::text) AND (status = 'active'::text))) AS info_count,
    count(*) FILTER (WHERE (status = 'active'::text)) AS total_active,
    count(*) FILTER (WHERE (status = 'resolved'::text)) AS total_resolved,
    count(*) FILTER (WHERE (status = 'false_positive'::text)) AS total_false_positive
   FROM public.findings
  GROUP BY target_id;


--
-- Name: fleet_node_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_node_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    node_id uuid,
    event_type text NOT NULL,
    actor_type text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT fleet_node_events_actor_type_check CHECK ((actor_type = ANY (ARRAY['operator'::text, 'node'::text, 'system'::text, 'broker'::text]))),
    CONSTRAINT fleet_node_events_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warning'::text, 'error'::text])))
);


--
-- Name: http_archive_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.http_archive_stats (
    owner_kind text NOT NULL,
    owner_id uuid NOT NULL,
    attempted integer DEFAULT 0 NOT NULL,
    stored integer DEFAULT 0 NOT NULL,
    failed integer DEFAULT 0 NOT NULL,
    dropped integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT http_archive_stats_owner_kind_check CHECK ((owner_kind = ANY (ARRAY['scan'::text, 'hunt'::text])))
);


--
-- Name: http_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.http_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plane text NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    scan_id uuid,
    hunt_run_id uuid,
    hunt_action_id uuid,
    scan_action_id text,
    target_id uuid,
    device_target_id uuid,
    capability_name text,
    adapter text,
    principal_slot text,
    method text NOT NULL,
    url text NOT NULL,
    http_version text,
    status_code integer,
    request_headers_object_id uuid,
    request_body_object_id uuid,
    request_body_sha256 text,
    request_body_bytes integer DEFAULT 0 NOT NULL,
    response_headers_object_id uuid,
    response_body_object_id uuid,
    response_body_sha256 text,
    response_body_bytes integer DEFAULT 0 NOT NULL,
    remote_ip text,
    direct_origin boolean DEFAULT false NOT NULL,
    redirect_of uuid,
    started_at timestamp with time zone,
    elapsed_ms integer,
    error text,
    truncated boolean DEFAULT false NOT NULL,
    retention_class text DEFAULT 'sensitive'::text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT http_transactions_owner_check CHECK ((num_nonnulls(scan_id, hunt_run_id) = 1)),
    CONSTRAINT http_transactions_plane_check CHECK ((plane = ANY (ARRAY['scan'::text, 'hunt'::text, 'device'::text, 'interactive'::text])))
);


--
-- Name: hunt_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    capability_name text NOT NULL,
    status text NOT NULL,
    input_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    private_http_result text,
    receipt_id uuid,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT hunt_actions_private_http_result_check CHECK (((private_http_result IS NULL) OR (private_http_result ~~ 'enc:fernet:%'::text))),
    CONSTRAINT hunt_actions_status_check CHECK ((status = ANY (ARRAY['reserved'::text, 'running'::text, 'completed'::text, 'blocked'::text, 'cancelled'::text, 'failed'::text, 'partial'::text, 'awaiting_permission'::text])))
);


--
-- Name: hunt_budget_amendments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_budget_amendments (
    id uuid NOT NULL,
    hunt_run_id uuid NOT NULL,
    revision integer NOT NULL,
    request_key_sha256 text NOT NULL,
    request_digest text NOT NULL,
    limits_before jsonb NOT NULL,
    limits_after jsonb NOT NULL,
    used_snapshot jsonb NOT NULL,
    reason text NOT NULL,
    status_before text NOT NULL,
    status_after text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_budget_amendments_revision_check CHECK ((revision > 0))
);


--
-- Name: hunt_cancellable_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_cancellable_jobs (
    hunt_id uuid NOT NULL,
    job_id uuid NOT NULL,
    signal_state text DEFAULT 'pending'::text NOT NULL,
    cancel_requested_at timestamp with time zone,
    signalled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_cancellable_jobs_state_check CHECK ((signal_state = ANY (ARRAY['pending'::text, 'signalled'::text, 'terminal'::text])))
);


--
-- Name: hunt_coverage_angle_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_coverage_angle_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    fingerprint text NOT NULL,
    family text NOT NULL,
    locus_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    mechanism text DEFAULT ''::text NOT NULL,
    principal_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    hypothesis text DEFAULT ''::text NOT NULL,
    status text NOT NULL,
    evidence_action_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    contradictory_evidence_action_ids jsonb DEFAULT '[]'::jsonb CONSTRAINT hunt_coverage_angle_events_contradictory_evidence_acti_not_null NOT NULL,
    candidate_id uuid,
    blocker text,
    proof_gap text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    event_seq bigint NOT NULL,
    CONSTRAINT hunt_coverage_angle_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'testing'::text, 'negative'::text, 'partial'::text, 'blocked'::text, 'candidate'::text])))
);


--
-- Name: hunt_coverage_angle_events_event_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hunt_coverage_angle_events_event_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hunt_coverage_angle_events_event_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hunt_coverage_angle_events_event_seq_seq OWNED BY public.hunt_coverage_angle_events.event_seq;


--
-- Name: hunt_credential_uses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_credential_uses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    action_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    profile_version integer NOT NULL,
    source text NOT NULL,
    slot text NOT NULL,
    used_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_credential_uses_profile_version_check CHECK ((profile_version > 0)),
    CONSTRAINT hunt_credential_uses_slot_check CHECK ((slot ~ '^[a-z0-9:_.-]{1,80}$'::text)),
    CONSTRAINT hunt_credential_uses_source_check CHECK (((source = ANY (ARRAY['selected'::text, 'target_own'::text])) OR (source ~ '^(selected_)?shared_from:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'::text) OR (source ~ '^(live_grant|preauthorized):[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'::text)))
);


--
-- Name: hunt_permission_baselines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_permission_baselines (
    hunt_run_id uuid NOT NULL,
    policy_json jsonb NOT NULL,
    source text NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_permission_baselines_source_check CHECK ((source = ANY (ARRAY['first_grant'::text, 'reconstructed'::text])))
);


--
-- Name: hunt_permission_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_permission_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    request_id uuid,
    grant_id uuid,
    action_id uuid,
    event text NOT NULL,
    actor text NOT NULL,
    source text NOT NULL,
    detail_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT hunt_permission_events_actor_check CHECK (((length(actor) >= 1) AND (length(actor) <= 200))),
    CONSTRAINT hunt_permission_events_event_check CHECK ((event = ANY (ARRAY['requested'::text, 'decided'::text, 'auto_granted'::text, 'used'::text, 'expired'::text, 'withdrawn'::text, 'revoked'::text, 'preauthorized'::text]))),
    CONSTRAINT hunt_permission_events_source_check CHECK (((length(source) >= 1) AND (length(source) <= 80)))
);


--
-- Name: hunt_permission_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_permission_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    request_id uuid NOT NULL,
    preauthorization_id uuid,
    kind text NOT NULL,
    subject_json jsonb NOT NULL,
    subject_digest text NOT NULL,
    scope text NOT NULL,
    effect_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    persisted_ref text,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    CONSTRAINT hunt_permission_grants_created_by_check CHECK (((length(created_by) >= 1) AND (length(created_by) <= 200))),
    CONSTRAINT hunt_permission_grants_kind_check CHECK ((kind = ANY (ARRAY['target.authorize'::text, 'credential.use'::text, 'capability.enable'::text, 'budget.raise'::text, 'ssh.exec'::text, 'ssh.host_trust'::text, 'preauthorization'::text]))),
    CONSTRAINT hunt_permission_grants_scope_check CHECK ((scope = ANY (ARRAY['hunt'::text, 'target'::text]))),
    CONSTRAINT hunt_permission_grants_subject_digest_check CHECK ((subject_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: hunt_permission_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_permission_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    kind text NOT NULL,
    reason_code text NOT NULL,
    subject_json jsonb NOT NULL,
    subject_digest text NOT NULL,
    display_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    action_id uuid,
    capability_name text,
    input_digest text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    decided_at timestamp with time zone,
    decided_by text,
    decision_via text,
    decision_scope text,
    decision_choice_json jsonb,
    decision_key_sha256 text,
    grant_id uuid,
    CONSTRAINT hunt_permission_requests_check CHECK ((expires_at > created_at)),
    CONSTRAINT hunt_permission_requests_check1 CHECK (((status = 'pending'::text) = (decided_at IS NULL))),
    CONSTRAINT hunt_permission_requests_decision_scope_check CHECK (((decision_scope IS NULL) OR (decision_scope = ANY (ARRAY['hunt'::text, 'target'::text])))),
    CONSTRAINT hunt_permission_requests_decision_via_check CHECK (((decision_via IS NULL) OR (decision_via = ANY (ARRAY['preauthorization'::text, 'terminal_stepup'::text, 'approver_session'::text, 'ui_session'::text, 'local_confirm'::text])))),
    CONSTRAINT hunt_permission_requests_kind_check CHECK ((kind = ANY (ARRAY['target.authorize'::text, 'credential.use'::text, 'capability.enable'::text, 'budget.raise'::text, 'ssh.exec'::text, 'ssh.host_trust'::text, 'preauthorization'::text]))),
    CONSTRAINT hunt_permission_requests_reason_code_check CHECK ((reason_code ~ '^[a-z][a-z_]{2,63}$'::text)),
    CONSTRAINT hunt_permission_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'granted'::text, 'denied'::text, 'expired'::text, 'withdrawn'::text]))),
    CONSTRAINT hunt_permission_requests_subject_digest_check CHECK ((subject_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: hunt_preauthorizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_preauthorizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    bounds_json jsonb NOT NULL,
    bounds_digest text NOT NULL,
    created_by text NOT NULL,
    proof text NOT NULL,
    source_request_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_preauthorizations_bounds_digest_check CHECK ((bounds_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT hunt_preauthorizations_created_by_check CHECK (((length(created_by) >= 1) AND (length(created_by) <= 200))),
    CONSTRAINT hunt_preauthorizations_proof_check CHECK ((proof = ANY (ARRAY['stepup'::text, 'launch_stepup'::text, 'local'::text, 'request_approval'::text])))
);


--
-- Name: hunt_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_id uuid,
    device_target_id uuid,
    objective text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    budget_revision integer DEFAULT 0 NOT NULL,
    budget_profile text DEFAULT 'balanced'::text NOT NULL,
    policy_json jsonb DEFAULT '{"allow_oob_interactions": false}'::jsonb NOT NULL,
    budget_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    budget_used_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    context_pack jsonb DEFAULT '{}'::jsonb NOT NULL,
    notes jsonb DEFAULT '[]'::jsonb NOT NULL,
    final_debrief jsonb DEFAULT '{}'::jsonb NOT NULL,
    approval_receipt_id uuid,
    stop_reason text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT hunt_runs_budget_profile_check CHECK ((budget_profile = ANY (ARRAY['fast'::text, 'balanced'::text, 'thorough'::text]))),
    CONSTRAINT hunt_runs_status_check CHECK ((status = ANY (ARRAY['created'::text, 'active'::text, 'awaiting_planner'::text, 'completed'::text, 'cancelled'::text, 'failed'::text, 'budget_exhausted'::text]))),
    CONSTRAINT hunt_runs_target_check CHECK ((((target_kind = ANY (ARRAY['web'::text, 'api'::text, 'network'::text])) AND (target_id IS NOT NULL) AND (device_target_id IS NULL)) OR ((target_kind = 'device'::text) AND (target_id IS NOT NULL) AND (device_target_id = target_id)))),
    CONSTRAINT hunt_runs_target_kind_check CHECK ((target_kind = ANY (ARRAY['web'::text, 'api'::text, 'device'::text, 'network'::text])))
);


--
-- Name: hunt_skill_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hunt_skill_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hunt_run_id uuid NOT NULL,
    skill_id text NOT NULL,
    event_type text NOT NULL,
    skill_version text NOT NULL,
    body_sha256 text NOT NULL,
    reason text,
    evidence_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    action_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hunt_skill_events_event_type_check CHECK ((event_type = ANY (ARRAY['read'::text, 'bound'::text, 'selection_removed'::text, 'unbound'::text, 'used'::text, 'completed'::text, 'deferred'::text])))
);


--
-- Name: hypotheses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hypotheses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    campaign_id uuid,
    campaign_action_id uuid,
    source text NOT NULL,
    family text NOT NULL,
    cwe text,
    title text,
    description text,
    severity_guess text,
    confidence double precision DEFAULT 0 NOT NULL,
    dedupe_key text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    claim_owner text,
    claim_lease_expires_at timestamp with time zone,
    smoke_score double precision,
    evidence_object_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_receipt_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    promoted_finding_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    next_test_action jsonb,
    endorsements jsonb DEFAULT '[]'::jsonb NOT NULL,
    refutations jsonb DEFAULT '[]'::jsonb NOT NULL,
    terminal_reason text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hypotheses_confidence_check CHECK (((confidence >= (0)::double precision) AND (confidence <= (1)::double precision))),
    CONSTRAINT hypotheses_severity_check CHECK (((severity_guess IS NULL) OR (severity_guess = ANY (ARRAY['critical'::text, 'high'::text, 'medium'::text, 'low'::text, 'info'::text])))),
    CONSTRAINT hypotheses_smoke_score_check CHECK (((smoke_score IS NULL) OR ((smoke_score >= (0)::double precision) AND (smoke_score <= (1)::double precision)))),
    CONSTRAINT hypotheses_source_check CHECK ((source = ANY (ARRAY['app_graph'::text, 'source_ingest'::text, 'ai_planner'::text, 'scanner_signal'::text, 'ai_gate'::text, 'model_intake'::text, 'benchmark'::text, 'invariant'::text, 'manual'::text]))),
    CONSTRAINT hypotheses_status_check CHECK ((status = ANY (ARRAY['open'::text, 'claimed'::text, 'testing'::text, 'supported'::text, 'refuted'::text, 'blocked'::text, 'exhausted'::text, 'promoted'::text, 'dead'::text])))
);


--
-- Name: investigation_candidate_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investigation_candidate_observations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    candidate_id uuid NOT NULL,
    research_episode_id uuid,
    agent_hunt_run_id uuid,
    device_agent_run_id uuid,
    hunt_run_id uuid,
    source_kind text DEFAULT 'hunt'::text NOT NULL,
    title text NOT NULL,
    claim text NOT NULL,
    claimed_severity text DEFAULT 'info'::text NOT NULL,
    evidence_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    verifier_contract_id text,
    observation_context jsonb DEFAULT '{}'::jsonb CONSTRAINT investigation_candidate_observatio_observation_context_not_null NOT NULL,
    created_by text,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT investigation_candidate_observation_severity_check CHECK ((claimed_severity = ANY (ARRAY['critical'::text, 'high'::text, 'medium'::text, 'low'::text, 'info'::text])))
);


--
-- Name: investigation_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investigation_candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plane text NOT NULL,
    target_id uuid,
    device_target_id uuid,
    research_episode_id uuid,
    agent_hunt_run_id uuid,
    device_agent_run_id uuid,
    hunt_run_id uuid,
    family text NOT NULL,
    canonical_locus jsonb DEFAULT '{}'::jsonb NOT NULL,
    title text NOT NULL,
    claim text NOT NULL,
    claimed_severity text DEFAULT 'info'::text NOT NULL,
    evidence_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    verifier_contract_id text,
    verification_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_kind text DEFAULT 'hunt'::text NOT NULL,
    fingerprint text NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    latest_verification_id uuid,
    created_by text,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT investigation_candidates_plane_check CHECK ((plane = ANY (ARRAY['web'::text, 'device'::text]))),
    CONSTRAINT investigation_candidates_severity_check CHECK ((claimed_severity = ANY (ARRAY['critical'::text, 'high'::text, 'medium'::text, 'low'::text, 'info'::text]))),
    CONSTRAINT investigation_candidates_status_check CHECK ((status = ANY (ARRAY['new'::text, 'verification_queued'::text, 'verifying'::text, 'verified'::text, 'refuted'::text, 'inconclusive'::text, 'blocked'::text, 'expired'::text]))),
    CONSTRAINT investigation_candidates_target_check CHECK ((((plane = 'web'::text) AND (target_id IS NOT NULL) AND (device_target_id IS NULL)) OR ((plane = 'device'::text) AND (target_id IS NOT NULL) AND (device_target_id = target_id))))
);


--
-- Name: model_intake_admission_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_admission_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admission_id uuid NOT NULL,
    event_type text NOT NULL,
    trigger_type text,
    actor text,
    reason text,
    previous_status text,
    new_status text,
    evidence_digest text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_admissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid NOT NULL,
    target_id uuid,
    submission_id uuid,
    artifact_sha256 text NOT NULL,
    repository_snapshot_sha256 text,
    statement_sha256 text NOT NULL,
    admission_package jsonb NOT NULL,
    decision text NOT NULL,
    status text NOT NULL,
    schema_version text DEFAULT 'model-intake-admission/v1'::text NOT NULL,
    deployment_bundle_sha256 text,
    evidence_manifest_sha256 text,
    policy_decision_sha256 text,
    target_environment text,
    idempotency_key_sha256 text,
    policy_profile text,
    policy_version text,
    issued_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    reassessment_due_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    revocation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_admission_status_check CHECK ((status = ANY (ARRAY['active'::text, 'denied'::text, 'reassessment_required'::text, 'revoked'::text, 'expired'::text, 'superseded'::text])))
);


--
-- Name: model_intake_agent_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_agent_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    iteration integer NOT NULL,
    action_name text NOT NULL,
    arguments_sha256 text NOT NULL,
    status text NOT NULL,
    result_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_agent_actions_status_check CHECK ((status = ANY (ARRAY['completed'::text, 'rejected'::text, 'error'::text])))
);


--
-- Name: model_intake_agent_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_agent_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    objective text NOT NULL,
    status text NOT NULL,
    max_iterations integer NOT NULL,
    iteration integer DEFAULT 0 NOT NULL,
    action_budget integer NOT NULL,
    actions_used integer DEFAULT 0 NOT NULL,
    transcript_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    final_assessment_json jsonb,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_agent_sessions_action_budget_check CHECK (((action_budget >= 1) AND (action_budget <= 100))),
    CONSTRAINT model_intake_agent_sessions_max_iterations_check CHECK (((max_iterations >= 1) AND (max_iterations <= 30))),
    CONSTRAINT model_intake_agent_sessions_status_check CHECK ((status = ANY (ARRAY['awaiting_planner'::text, 'completed'::text, 'cancelled'::text])))
);


--
-- Name: model_intake_approval_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_approval_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    evidence_manifest_id uuid NOT NULL,
    receipt_sha256 text NOT NULL,
    receipt_json jsonb NOT NULL,
    approval_type text NOT NULL,
    decision text NOT NULL,
    approved_by_subject text NOT NULL,
    approved_by_role text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revocation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_automatic_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_automatic_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid,
    submission_id uuid,
    conversion_job_id uuid,
    calibration_job_id uuid,
    runtime_job_id uuid,
    source_kind text NOT NULL,
    source_label text DEFAULT 'Model review'::text NOT NULL,
    source_reference_hash text NOT NULL,
    requested_environment text NOT NULL,
    state text DEFAULT 'static_scan_pending'::text NOT NULL,
    current_step text DEFAULT 'static_scan'::text NOT NULL,
    progress integer DEFAULT 5 NOT NULL,
    technical_outcome text,
    deployment_bundle_json jsonb,
    known_answer_embedding_sha256 text,
    pending_controls jsonb DEFAULT '[]'::jsonb NOT NULL,
    timeline_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    error_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT model_intake_automatic_reviews_progress_check CHECK (((progress >= 0) AND (progress <= 100)))
);


--
-- Name: model_intake_deployment_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_deployment_bindings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    admission_id uuid,
    deployment_bundle_sha256 text CONSTRAINT model_intake_deployment_bindi_deployment_bundle_sha256_not_null NOT NULL,
    environment text NOT NULL,
    observed_bundle_sha256 text,
    verifier_status text DEFAULT 'not_observed'::text NOT NULL,
    deployment_reference text,
    observed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_evidence_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_evidence_manifests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    version integer NOT NULL,
    manifest_sha256 text NOT NULL,
    evidence_ids jsonb NOT NULL,
    manifest_json jsonb NOT NULL,
    deployment_bundle_json jsonb NOT NULL,
    subject_bundle_sha256 text NOT NULL,
    frozen_at timestamp with time zone NOT NULL,
    frozen_by text NOT NULL,
    supersedes_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_evidence_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_evidence_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    evidence_type text NOT NULL,
    schema_version text NOT NULL,
    provenance_class text NOT NULL,
    producer_id text NOT NULL,
    producer_version text NOT NULL,
    builder_id text NOT NULL,
    invocation_id text NOT NULL,
    subject_bindings jsonb NOT NULL,
    input_manifest_sha256 text,
    payload_sha256 text NOT NULL,
    payload_json jsonb,
    object_storage_uri text,
    signature_envelope jsonb,
    status text NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    expires_at timestamp with time zone,
    supersedes_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_evidence_provenance_check CHECK ((provenance_class = ANY (ARRAY['DECLARED'::text, 'PROVIDER_RESOLVED'::text, 'GENERATED_STATIC'::text, 'GENERATED_RUNTIME'::text, 'GENERATED_EVALUATION'::text, 'GENERATED_DATA_PLANE'::text, 'HUMAN_APPROVAL'::text, 'POLICY_DECISION'::text, 'DEPLOYMENT_OBSERVED'::text])))
);


--
-- Name: model_intake_policy_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_policy_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    evidence_manifest_id uuid NOT NULL,
    decision_sha256 text NOT NULL,
    decision_json jsonb NOT NULL,
    decision text NOT NULL,
    policy_provider text NOT NULL,
    policy_bundle_sha256 text NOT NULL,
    input_sha256 text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_runner_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_runner_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    operation text NOT NULL,
    state text NOT NULL,
    remote_job_id uuid NOT NULL,
    request_sha256 text NOT NULL,
    request_json jsonb NOT NULL,
    result_json jsonb,
    error_json jsonb,
    evidence_record_id uuid,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_runner_jobs_operation_check CHECK ((operation = ANY (ARRAY['calibration'::text, 'runtime'::text, 'conversion'::text]))),
    CONSTRAINT model_intake_runner_jobs_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: model_intake_subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_subjects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    subject_kind text NOT NULL,
    immutable_uri text,
    sha256 text NOT NULL,
    size_bytes bigint,
    manifest_sha256 text,
    source_revision text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_submission_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_submission_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    event_type text NOT NULL,
    actor text NOT NULL,
    reason text NOT NULL,
    previous_state text NOT NULL,
    new_state text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: model_intake_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid,
    requested_by text NOT NULL,
    requested_environment text NOT NULL,
    source_kind text NOT NULL,
    source_reference_hash text NOT NULL,
    expected_artifact_sha256 text,
    intended_use jsonb DEFAULT '{}'::jsonb NOT NULL,
    declared_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    state text DEFAULT 'submitted'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_submission_environment_check CHECK ((requested_environment = ANY (ARRAY['development'::text, 'test'::text, 'staging'::text, 'production'::text]))),
    CONSTRAINT model_intake_submission_state_check CHECK ((state = ANY (ARRAY['submitted'::text, 'scanning'::text, 'evidence_ready'::text, 'evidence_frozen'::text, 'awaiting_approval'::text, 'policy_decided'::text, 'admitted'::text, 'promoted'::text, 'blocked'::text, 'cancelled'::text])))
);


--
-- Name: model_intake_trust_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_intake_trust_anchors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    public_key_pem text,
    public_key_sha256 text,
    policy_profile text,
    purpose text DEFAULT 'publisher_signature'::text NOT NULL,
    environment text DEFAULT 'production'::text NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_until timestamp with time zone,
    revoked_at timestamp with time zone,
    revocation_reason text,
    issuer_constraint text,
    subject_constraint text,
    builder_id_constraint text,
    source text DEFAULT 'operator'::text NOT NULL,
    version text DEFAULT '1'::text NOT NULL,
    owner text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_intake_trust_anchor_environment_check CHECK ((environment = ANY (ARRAY['development'::text, 'test'::text, 'staging'::text, 'production'::text]))),
    CONSTRAINT model_intake_trust_anchor_material_check CHECK ((((public_key_pem IS NOT NULL) AND (btrim(public_key_pem) <> ''::text)) OR ((public_key_sha256 IS NOT NULL) AND (btrim(public_key_sha256) <> ''::text)))),
    CONSTRAINT model_intake_trust_anchor_purpose_check CHECK ((purpose = ANY (ARRAY['publisher_signature'::text, 'upstream_attestation'::text, 'runtime_runner'::text, 'evaluation_runner'::text, 'data_plane_runner'::text, 'approval_signer'::text, 'admission_signer'::text])))
);


--
-- Name: node_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    node_id uuid NOT NULL,
    credential_hash text NOT NULL,
    credential_version integer DEFAULT 1 NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT node_credentials_credential_version_check CHECK ((credential_version > 0))
);


--
-- Name: node_join_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_join_tokens (
    token_hash text NOT NULL,
    token_id uuid DEFAULT gen_random_uuid() NOT NULL,
    role text NOT NULL,
    transport text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    max_uses integer DEFAULT 1 NOT NULL,
    use_count integer DEFAULT 0 NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    consumed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT node_join_tokens_check CHECK (((use_count >= 0) AND (use_count <= max_uses))),
    CONSTRAINT node_join_tokens_max_uses_check CHECK (((max_uses >= 1) AND (max_uses <= 128))),
    CONSTRAINT node_join_tokens_role_check CHECK ((role = 'worker'::text)),
    CONSTRAINT node_join_tokens_transport_check CHECK ((transport = ANY (ARRAY['overlay'::text, 'broker'::text]))),
    CONSTRAINT node_join_tokens_use_count_check CHECK (((use_count >= 0) AND (use_count <= max_uses)))
);


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    hostname text,
    role text NOT NULL,
    overlay_ip inet,
    wireguard_public_key text,
    egress_ip inet,
    region text,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    build_fingerprint text,
    worker_image_digest text,
    active_worker_image_digest text,
    agent_version text,
    desired_state_version integer DEFAULT 1 NOT NULL,
    desired_state_changed_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_state_version integer DEFAULT 0 NOT NULL,
    last_error text,
    desired_worker_count integer DEFAULT 0 NOT NULL,
    active_worker_count integer DEFAULT 0 NOT NULL,
    capacity jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'joining'::text NOT NULL,
    drain boolean DEFAULT false NOT NULL,
    rollout_in_progress boolean DEFAULT false NOT NULL,
    last_heartbeat_at timestamp with time zone,
    connection_bundle_delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT nodes_active_worker_count_check CHECK (((active_worker_count >= 0) AND (active_worker_count <= 128))),
    CONSTRAINT nodes_applied_state_version_check CHECK ((applied_state_version >= 0)),
    CONSTRAINT nodes_desired_state_version_check CHECK ((desired_state_version > 0)),
    CONSTRAINT nodes_desired_worker_count_check CHECK (((desired_worker_count >= 0) AND (desired_worker_count <= 128))),
    CONSTRAINT nodes_role_check CHECK ((role = ANY (ARRAY['control_plane'::text, 'worker'::text]))),
    CONSTRAINT nodes_status_check CHECK ((status = ANY (ARRAY['joining'::text, 'healthy'::text, 'stale'::text, 'draining'::text, 'disabled'::text])))
);


--
-- Name: operation_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operation_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    objective text NOT NULL,
    planner jsonb DEFAULT '{}'::jsonb NOT NULL,
    context_hash text NOT NULL,
    target_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_tier text NOT NULL,
    actions jsonb DEFAULT '[]'::jsonb NOT NULL,
    confirmations jsonb DEFAULT '[]'::jsonb NOT NULL,
    missing_inputs jsonb DEFAULT '[]'::jsonb NOT NULL,
    stop_conditions jsonb DEFAULT '[]'::jsonb NOT NULL,
    success_criteria jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'planned'::text NOT NULL,
    validation_errors jsonb DEFAULT '[]'::jsonb NOT NULL,
    validation_warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    scope_receipt_id text,
    approval_receipt_id uuid,
    plan_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operation_plans_risk_check CHECK ((risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT operation_plans_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'blocked'::text, 'approved'::text, 'rejected'::text, 'stale'::text])))
);


--
-- Name: policy_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    product_area text DEFAULT 'ai_gate'::text NOT NULL,
    environment text DEFAULT 'production'::text NOT NULL,
    minimum_block_severity text DEFAULT 'high'::text NOT NULL,
    expires_days integer DEFAULT 30 NOT NULL,
    strict_model_intake boolean DEFAULT false NOT NULL,
    allow_active_exceptions boolean DEFAULT true NOT NULL,
    owner text,
    version text,
    is_active boolean DEFAULT true NOT NULL,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    required_trust_anchor_ids jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: public_api_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_api_idempotency (
    method text NOT NULL,
    path text NOT NULL,
    key_sha256 text NOT NULL,
    request_sha256 text NOT NULL,
    state text DEFAULT 'processing'::text NOT NULL,
    response_status integer,
    response_headers jsonb DEFAULT '{}'::jsonb NOT NULL,
    response_body bytea,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT public_api_idempotency_key_sha256_check CHECK ((key_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT public_api_idempotency_request_sha256_check CHECK ((request_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT public_api_idempotency_state_check CHECK ((state = ANY (ARRAY['processing'::text, 'completed'::text])))
);


--
-- Name: refuter_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refuter_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject_type text NOT NULL,
    subject_id text,
    target_id uuid,
    finding_id uuid,
    hypothesis_id uuid,
    campaign_id uuid,
    trigger_reason text NOT NULL,
    refuter_signal text DEFAULT 'question'::text NOT NULL,
    refuter_verdict text,
    verdict_basis text DEFAULT 'signal_only'::text NOT NULL,
    confidence_delta double precision,
    evidence_object_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_receipt_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    counterevidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    notes text,
    status text DEFAULT 'recorded'::text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT refuter_reviews_basis_check CHECK ((verdict_basis = ANY (ARRAY['signal_only'::text, 'deterministic_replay'::text, 'cryptographic'::text, 'parser_protocol'::text, 'human_approved_review'::text]))),
    CONSTRAINT refuter_reviews_signal_check CHECK ((refuter_signal = ANY (ARRAY['support'::text, 'question'::text, 'weaken'::text, 'refute'::text]))),
    CONSTRAINT refuter_reviews_status_check CHECK ((status = ANY (ARRAY['recorded'::text, 'verdict_recorded'::text, 'rejected'::text]))),
    CONSTRAINT refuter_reviews_subject_check CHECK ((subject_type = ANY (ARRAY['finding'::text, 'hypothesis'::text, 'target'::text, 'ai_gate_scan'::text, 'model_intake'::text, 'benchmark'::text, 'planner'::text, 'deployment_gate'::text, 'parser_output'::text, 'manual'::text]))),
    CONSTRAINT refuter_reviews_verdict_check CHECK (((refuter_verdict IS NULL) OR (refuter_verdict = ANY (ARRAY['supported'::text, 'weakened'::text, 'refuted'::text, 'inconclusive'::text]))))
);


--
-- Name: request_collection_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_collection_bindings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    collection_id uuid NOT NULL,
    target_kind text NOT NULL,
    target_id uuid NOT NULL,
    allowed_origins jsonb NOT NULL,
    environment_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT request_collection_bindings_allowed_origins_check CHECK (((jsonb_typeof(allowed_origins) = 'array'::text) AND (jsonb_array_length(allowed_origins) > 0))),
    CONSTRAINT request_collection_bindings_target_kind_check CHECK ((target_kind = ANY (ARRAY['web'::text, 'api'::text, 'network'::text, 'device'::text])))
);


--
-- Name: request_collection_environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_collection_environments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    collection_id uuid NOT NULL,
    name text NOT NULL,
    encrypted_payload text NOT NULL,
    payload_sha256 text NOT NULL,
    variable_count integer DEFAULT 0 NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT request_collection_environments_encrypted_payload_check CHECK ((encrypted_payload ~~ 'enc:fernet:%'::text)),
    CONSTRAINT request_collection_environments_metadata_json_check CHECK ((jsonb_typeof(metadata_json) = 'object'::text)),
    CONSTRAINT request_collection_environments_payload_sha256_check CHECK ((payload_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT request_collection_environments_variable_count_check CHECK ((variable_count >= 0))
);


--
-- Name: request_collection_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_collection_requests (
    collection_id uuid NOT NULL,
    request_id text NOT NULL,
    ordinal integer NOT NULL,
    folder text,
    name text,
    method text NOT NULL,
    redacted_url text,
    normalized_path text,
    body_mode text,
    auth_type text,
    tags_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    content_type text,
    body_field_names_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    safe_method boolean DEFAULT false NOT NULL,
    supported boolean DEFAULT true NOT NULL
);


--
-- Name: request_collection_selections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_collection_selections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    collection_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    name text NOT NULL,
    replay_policy text NOT NULL,
    selector_json jsonb NOT NULL,
    selection_digest text NOT NULL,
    selected_request_count integer DEFAULT 0 NOT NULL,
    selected_mutating_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT request_collection_selections_replay_policy_check CHECK ((replay_policy = ANY (ARRAY['discovery_only'::text, 'safe_reads'::text, 'safe_authentication'::text, 'confirmed_active'::text]))),
    CONSTRAINT request_collection_selections_selected_mutating_count_check CHECK ((selected_mutating_count >= 0)),
    CONSTRAINT request_collection_selections_selected_request_count_check CHECK ((selected_request_count >= 0)),
    CONSTRAINT request_collection_selections_selection_digest_check CHECK ((selection_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT request_collection_selections_selector_json_check CHECK ((jsonb_typeof(selector_json) = 'object'::text))
);


--
-- Name: research_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    episode_id uuid NOT NULL,
    observation_id uuid NOT NULL,
    sequence integer NOT NULL,
    decision_version text NOT NULL,
    planner jsonb DEFAULT '{}'::jsonb NOT NULL,
    decision_type text NOT NULL,
    hypothesis_id uuid,
    action jsonb DEFAULT '{}'::jsonb NOT NULL,
    expected_signal text,
    falsifier text,
    reason text,
    confidence double precision DEFAULT 0 NOT NULL,
    requested_input text,
    stop_reason text,
    status text NOT NULL,
    validation_errors jsonb DEFAULT '[]'::jsonb NOT NULL,
    validation_warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    policy_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    command_result_id uuid,
    idempotency_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT research_decisions_confidence_check CHECK (((confidence >= (0)::double precision) AND (confidence <= (1)::double precision))),
    CONSTRAINT research_decisions_sequence_check CHECK ((sequence >= 1)),
    CONSTRAINT research_decisions_status_check CHECK ((status = ANY (ARRAY['accepted'::text, 'rejected'::text, 'dispatching'::text, 'completed'::text, 'blocked'::text, 'failed'::text]))),
    CONSTRAINT research_decisions_type_check CHECK ((decision_type = ANY (ARRAY['execute_action'::text, 'request_input'::text, 'stop'::text])))
);


--
-- Name: research_episodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_episodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    operation_plan_id uuid,
    campaign_id uuid,
    objective text NOT NULL,
    episode_version text NOT NULL,
    planner jsonb DEFAULT '{}'::jsonb NOT NULL,
    execution_mode text DEFAULT 'read_only'::text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    max_risk_tier text DEFAULT 'read_only'::text NOT NULL,
    allowed_families jsonb DEFAULT '[]'::jsonb NOT NULL,
    budget_limits jsonb DEFAULT '{}'::jsonb NOT NULL,
    budget_used jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope_receipt_id text,
    approval_receipt_id uuid,
    current_observation_id uuid,
    current_decision_id uuid,
    step_count integer DEFAULT 0 NOT NULL,
    cancel_requested boolean DEFAULT false NOT NULL,
    autopilot_enabled boolean DEFAULT false NOT NULL,
    autopilot_error text,
    autopilot_consecutive_failures integer DEFAULT 0 NOT NULL,
    stop_reason text,
    requested_input text,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT research_episodes_execution_mode_check CHECK ((execution_mode = ANY (ARRAY['shadow'::text, 'read_only'::text, 'gated'::text]))),
    CONSTRAINT research_episodes_risk_check CHECK ((max_risk_tier = ANY (ARRAY['read_only'::text, 'passive'::text, 'active'::text, 'intrusive'::text, 'credential'::text, 'dangerous'::text]))),
    CONSTRAINT research_episodes_status_check CHECK ((status = ANY (ARRAY['created'::text, 'awaiting_planner'::text, 'validating_decision'::text, 'dispatching'::text, 'awaiting_observation'::text, 'awaiting_input'::text, 'approval_required'::text, 'completed'::text, 'cancelled'::text, 'failed'::text, 'budget_exhausted'::text, 'blocked'::text]))),
    CONSTRAINT research_episodes_step_count_check CHECK ((step_count >= 0))
);


--
-- Name: research_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    episode_id uuid NOT NULL,
    sequence bigint NOT NULL,
    event_type text NOT NULL,
    status text NOT NULL,
    summary text NOT NULL,
    observation_id uuid,
    decision_id uuid,
    command_result_id uuid,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: research_events_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.research_events_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: research_events_sequence_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.research_events_sequence_seq OWNED BY public.research_events.sequence;


--
-- Name: research_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_observations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    episode_id uuid NOT NULL,
    sequence integer NOT NULL,
    observation_version text NOT NULL,
    context_hash text NOT NULL,
    episode_version integer NOT NULL,
    observation_pack jsonb NOT NULL,
    previous_command_result_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT research_observations_sequence_check CHECK ((sequence >= 0))
);


--
-- Name: scan_action_attempt_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_action_attempt_checkpoints (
    scan_id uuid NOT NULL,
    action_id text NOT NULL,
    action_digest character(64) NOT NULL,
    attempt_id character(64) NOT NULL,
    candidate_id text NOT NULL,
    status text NOT NULL,
    budget_consumed jsonb DEFAULT '{}'::jsonb NOT NULL,
    observations_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    errors_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    timed_out boolean DEFAULT false NOT NULL,
    proof_state text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_action_attempt_checkpoints_action_digest_check CHECK ((action_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_action_attempt_checkpoints_attempt_id_check CHECK ((attempt_id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_action_attempt_checkpoints_budget_consumed_check CHECK ((jsonb_typeof(budget_consumed) = 'object'::text)),
    CONSTRAINT scan_action_attempt_checkpoints_errors_json_check CHECK ((jsonb_typeof(errors_json) = 'array'::text)),
    CONSTRAINT scan_action_attempt_checkpoints_observations_json_check CHECK ((jsonb_typeof(observations_json) = 'array'::text)),
    CONSTRAINT scan_action_attempt_checkpoints_status_check CHECK ((status = ANY (ARRAY['success'::text, 'partial'::text, 'skipped'::text, 'blocked'::text, 'failed'::text, 'cancelled'::text, 'timed_out'::text])))
);


--
-- Name: scan_action_plan_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_action_plan_revisions (
    scan_id uuid NOT NULL,
    revision integer NOT NULL,
    plan_digest character(64) NOT NULL,
    parent_plan_digest character(64),
    continuation_allocation_digest character(64),
    revision_schema text,
    discovery_result_digest character(64),
    work_manifest_refs_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    continuation_plan_digest character(64),
    revision_digest character(64),
    plan_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_action_plan_revisions_continuation_allocation_digest_check CHECK (((continuation_allocation_digest IS NULL) OR (continuation_allocation_digest ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT scan_action_plan_revisions_continuation_plan_digest_check CHECK (((continuation_plan_digest IS NULL) OR (continuation_plan_digest ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT scan_action_plan_revisions_discovery_result_digest_check CHECK (((discovery_result_digest IS NULL) OR (discovery_result_digest ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT scan_action_plan_revisions_multi_round_bound_check CHECK (((revision >= 0) AND (revision <= 9))),
    CONSTRAINT scan_action_plan_revisions_multi_round_shape_check CHECK ((((revision = 0) AND (parent_plan_digest IS NULL) AND (continuation_allocation_digest IS NULL) AND (discovery_result_digest IS NULL) AND (work_manifest_refs_json = '[]'::jsonb) AND (continuation_plan_digest IS NULL)) OR (((revision >= 1) AND (revision <= 9)) AND (parent_plan_digest IS NOT NULL) AND (continuation_allocation_digest IS NOT NULL) AND (discovery_result_digest IS NOT NULL) AND (jsonb_array_length(work_manifest_refs_json) > 0) AND (continuation_plan_digest IS NOT NULL)))),
    CONSTRAINT scan_action_plan_revisions_parent_plan_digest_check CHECK (((parent_plan_digest IS NULL) OR (parent_plan_digest ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT scan_action_plan_revisions_plan_digest_check CHECK ((plan_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_action_plan_revisions_plan_json_check CHECK ((jsonb_typeof(plan_json) = 'object'::text)),
    CONSTRAINT scan_action_plan_revisions_revision_digest_check CHECK (((revision_digest IS NULL) OR (revision_digest ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT scan_action_plan_revisions_work_manifest_refs_json_check CHECK ((jsonb_typeof(work_manifest_refs_json) = 'array'::text))
);


--
-- Name: scan_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_artifacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid NOT NULL,
    parent_scan_id uuid,
    shard_index integer,
    executing_node_id uuid,
    artifact_type text NOT NULL,
    artifact_key text NOT NULL,
    content_type text DEFAULT 'application/octet-stream'::text NOT NULL,
    storage_uri text NOT NULL,
    storage_backend text NOT NULL,
    content_sha256 text NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    retention_class text DEFAULT 'standard'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    expires_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_artifacts_status_check CHECK ((status = ANY (ARRAY['available'::text, 'deleting'::text, 'upload_failed'::text, 'missing'::text, 'deleted'::text])))
);


--
-- Name: scan_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_campaigns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    root_domain text,
    requested_by text DEFAULT 'api'::text NOT NULL,
    mode text NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    budget_profile text,
    wide_budget jsonb DEFAULT '{}'::jsonb NOT NULL,
    deep_budget jsonb DEFAULT '{}'::jsonb NOT NULL,
    check_families jsonb DEFAULT '[]'::jsonb NOT NULL,
    auth_states jsonb DEFAULT '[]'::jsonb NOT NULL,
    allowed_windows jsonb DEFAULT '{}'::jsonb NOT NULL,
    daily_cap integer,
    rate_caps jsonb DEFAULT '{}'::jsonb NOT NULL,
    parent_scan_id uuid,
    policy_id uuid,
    status text DEFAULT 'active'::text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: scan_capability_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_capability_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_id uuid NOT NULL,
    action_id text NOT NULL,
    stage text NOT NULL,
    ordinal integer NOT NULL,
    capability_name text NOT NULL,
    adapter_name text NOT NULL,
    adapter_version text NOT NULL,
    output_schema text NOT NULL,
    action_digest character(64) NOT NULL,
    execution_plan_digest character(64) NOT NULL,
    target_binding_digest character(64) NOT NULL,
    input_binding_digest character(64) NOT NULL,
    requested_budget jsonb NOT NULL,
    placement_json jsonb NOT NULL,
    dependencies_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    required boolean NOT NULL,
    supporting boolean NOT NULL,
    status text DEFAULT 'planned'::text NOT NULL,
    reason_code text,
    reservation_id text,
    reservation_owner_kind text GENERATED ALWAYS AS ('scan'::text) STORED,
    reservation_owner_id text GENERATED ALWAYS AS ((scan_id)::text) STORED,
    receipt_id text,
    receipt_hash character(64),
    observation_manifest_id uuid,
    result_digest character(64),
    result_json jsonb,
    receipt_json jsonb,
    backend_name text,
    worker_id text,
    lease_id uuid,
    lease_token_hash character(64),
    lease_expires_at timestamp with time zone,
    attempt integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_capability_actions_action_digest_check CHECK ((action_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_capability_actions_attempt_check CHECK ((attempt >= 0)),
    CONSTRAINT scan_capability_actions_dependencies_json_check CHECK ((jsonb_typeof(dependencies_json) = 'array'::text)),
    CONSTRAINT scan_capability_actions_execution_plan_digest_check CHECK ((execution_plan_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_capability_actions_input_binding_digest_check CHECK ((input_binding_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_capability_actions_ordinal_check CHECK (((ordinal >= 0) AND (ordinal < 512))),
    CONSTRAINT scan_capability_actions_placement_json_check CHECK ((jsonb_typeof(placement_json) = 'object'::text)),
    CONSTRAINT scan_capability_actions_requested_budget_check CHECK ((jsonb_typeof(requested_budget) = 'object'::text)),
    CONSTRAINT scan_capability_actions_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'leased'::text, 'running'::text, 'success'::text, 'partial'::text, 'skipped'::text, 'blocked'::text, 'failed'::text, 'cancelled'::text, 'timed_out'::text]))),
    CONSTRAINT scan_capability_actions_target_binding_digest_check CHECK ((target_binding_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_capability_actions_terminal_result_check CHECK (((status <> ALL (ARRAY['success'::text, 'partial'::text, 'failed'::text, 'timed_out'::text])) OR ((receipt_hash ~ '^[0-9a-f]{64}$'::text) AND (result_digest ~ '^[0-9a-f]{64}$'::text))))
);


--
-- Name: scan_observation_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_observation_manifests (
    id uuid NOT NULL,
    scan_id uuid NOT NULL,
    action_id text NOT NULL,
    capability_name text NOT NULL,
    output_schema text NOT NULL,
    manifest_digest character(64) NOT NULL,
    content_sha256 character(64) NOT NULL,
    observation_count integer NOT NULL,
    size_bytes integer NOT NULL,
    object_key text NOT NULL,
    manifest_json jsonb NOT NULL,
    observations_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_observation_manifests_content_sha256_check CHECK ((content_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_observation_manifests_manifest_digest_check CHECK ((manifest_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_observation_manifests_manifest_json_check CHECK ((jsonb_typeof(manifest_json) = 'object'::text)),
    CONSTRAINT scan_observation_manifests_observation_count_check CHECK (((observation_count >= 0) AND (observation_count <= 100000))),
    CONSTRAINT scan_observation_manifests_observations_json_check CHECK ((jsonb_typeof(observations_json) = 'array'::text)),
    CONSTRAINT scan_observation_manifests_size_bytes_check CHECK (((size_bytes >= 0) AND (size_bytes <= 67108864)))
);


--
-- Name: scan_stage_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_stage_checkpoints (
    scan_id uuid NOT NULL,
    job_id text NOT NULL,
    stage_index smallint NOT NULL,
    stage_name text NOT NULL,
    status text NOT NULL,
    execution_plan_digest text NOT NULL,
    target_binding_digest text NOT NULL,
    history_digest text NOT NULL,
    stage_row_digest text NOT NULL,
    stage_row_json jsonb NOT NULL,
    worker_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_stage_checkpoints_execution_plan_digest_check CHECK ((execution_plan_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_stage_checkpoints_history_digest_check CHECK ((history_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_stage_checkpoints_stage_index_check CHECK (((stage_index >= 0) AND (stage_index < 32))),
    CONSTRAINT scan_stage_checkpoints_stage_name_check CHECK ((stage_name ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}$'::text)),
    CONSTRAINT scan_stage_checkpoints_stage_row_digest_check CHECK ((stage_row_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_stage_checkpoints_stage_row_json_check CHECK (((jsonb_typeof(stage_row_json) = 'object'::text) AND ((stage_row_json - ARRAY['index'::text, 'name'::text, 'enabled'::text, 'status'::text, 'reason'::text, 'adapter'::text, 'capability_names'::text, 'output_keys'::text, 'elapsed_ms'::text]) = '{}'::jsonb))),
    CONSTRAINT scan_stage_checkpoints_status_check CHECK ((status = ANY (ARRAY['completed'::text, 'partial'::text, 'skipped'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT scan_stage_checkpoints_target_binding_digest_check CHECK ((target_binding_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: scan_work_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_work_manifests (
    id uuid NOT NULL,
    scan_id uuid NOT NULL,
    kind text NOT NULL,
    schema_version text NOT NULL,
    content_schema text NOT NULL,
    target_binding_digest character(64) NOT NULL,
    source_action_ids jsonb NOT NULL,
    status text NOT NULL,
    reason_code text,
    entry_count integer NOT NULL,
    manifest_digest character(64) NOT NULL,
    content_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_work_manifest_reason_check CHECK ((((status = 'complete'::text) AND (reason_code IS NULL)) OR ((status <> 'complete'::text) AND (reason_code IS NOT NULL)))),
    CONSTRAINT scan_work_manifests_content_json_check CHECK ((jsonb_typeof(content_json) = 'object'::text)),
    CONSTRAINT scan_work_manifests_entry_count_check CHECK (((entry_count >= 0) AND (entry_count <= 100000))),
    CONSTRAINT scan_work_manifests_kind_check CHECK ((kind = ANY (ARRAY['endpoint'::text, 'candidate'::text, 'request_candidate'::text, 'request'::text, 'template'::text]))),
    CONSTRAINT scan_work_manifests_manifest_digest_check CHECK ((manifest_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT scan_work_manifests_source_action_ids_check CHECK ((jsonb_typeof(source_action_ids) = 'array'::text)),
    CONSTRAINT scan_work_manifests_status_check CHECK ((status = ANY (ARRAY['complete'::text, 'partial'::text, 'cancelled'::text]))),
    CONSTRAINT scan_work_manifests_target_binding_digest_check CHECK ((target_binding_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid,
    name text,
    frequency text NOT NULL,
    day_of_week integer,
    time_of_day text DEFAULT '02:00'::text,
    timezone text DEFAULT 'UTC'::text,
    jitter_minutes integer DEFAULT 30,
    schedule_kind text DEFAULT 'normal_scan'::text,
    scan_type text DEFAULT 'standard'::text,
    scan_options jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: scope_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scope_receipts (
    id text NOT NULL,
    target_id uuid,
    input_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    normalized_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    verdict text NOT NULL,
    blocked_by jsonb DEFAULT '[]'::jsonb NOT NULL,
    warnings jsonb DEFAULT '[]'::jsonb NOT NULL,
    checks jsonb DEFAULT '[]'::jsonb NOT NULL,
    environment text DEFAULT 'production'::text NOT NULL,
    allowed_hosts jsonb DEFAULT '[]'::jsonb NOT NULL,
    allowed_root_domains jsonb DEFAULT '[]'::jsonb NOT NULL,
    redirect_destinations jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scope_receipts_verdict_check CHECK ((verdict = ANY (ARRAY['allowed'::text, 'blocked'::text, 'needs_approval'::text])))
);


--
-- Name: target_credential_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_credential_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    name text NOT NULL,
    auth_kind text NOT NULL,
    secret_value text NOT NULL,
    secret_preview text,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    rotated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT target_credential_profiles_auth_kind_check CHECK ((auth_kind = ANY (ARRAY['authorization_header'::text, 'cookie'::text])))
);


--
-- Name: target_endpoint_expectations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_endpoint_expectations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    endpoint_id uuid,
    method text DEFAULT 'GET'::text NOT NULL,
    path text NOT NULL,
    param_shape text DEFAULT ''::text NOT NULL,
    param_location text DEFAULT 'query'::text NOT NULL,
    principal_id uuid,
    principal_role text,
    tenant_id text,
    expected_access text DEFAULT 'unknown'::text NOT NULL,
    expected_http_status integer,
    expectation_source text DEFAULT 'manual'::text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT target_endpoint_expectations_access_check CHECK ((expected_access = ANY (ARRAY['allow'::text, 'deny'::text, 'requires_role'::text, 'unknown'::text])))
);


--
-- Name: target_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_endpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    method text DEFAULT 'GET'::text NOT NULL,
    path text NOT NULL,
    param_shape text DEFAULT ''::text NOT NULL,
    fingerprint text NOT NULL,
    source text,
    auth_state text DEFAULT 'anonymous'::text NOT NULL,
    param_location text DEFAULT 'query'::text NOT NULL,
    replay_spec text,
    content_type text,
    content_hash text,
    priority_score integer DEFAULT 10 NOT NULL,
    test_status text DEFAULT 'untested'::text NOT NULL,
    last_attempt_status text,
    last_verdict text,
    last_finding_id uuid,
    credential_ref text,
    campaign_id uuid,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_http_status integer,
    unreachable_streak integer DEFAULT 0 NOT NULL,
    last_reachability_at timestamp with time zone,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_tested_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_scan_id uuid
);


--
-- Name: target_invariant_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_invariant_contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    contract_version text NOT NULL,
    contract_kind text NOT NULL,
    title text NOT NULL,
    source_text text,
    subject_role text,
    action text,
    resource text,
    method text,
    path text,
    field_name text,
    operator text,
    expected_value jsonb,
    expected_access text,
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    approved_at timestamp with time zone,
    approved_by text,
    retired_at timestamp with time zone,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT target_invariant_contracts_access_check CHECK (((expected_access IS NULL) OR (expected_access = ANY (ARRAY['allow'::text, 'deny'::text, 'requires_role'::text])))),
    CONSTRAINT target_invariant_contracts_kind_check CHECK ((contract_kind = ANY (ARRAY['access_control'::text, 'field_constraint'::text, 'workflow_transition'::text, 'ownership'::text]))),
    CONSTRAINT target_invariant_contracts_operator_check CHECK (((operator IS NULL) OR (operator = ANY (ARRAY['eq'::text, 'ne'::text, 'lt'::text, 'lte'::text, 'gt'::text, 'gte'::text, 'in'::text, 'not_in'::text])))),
    CONSTRAINT target_invariant_contracts_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'approved'::text, 'retired'::text])))
);


--
-- Name: target_principal_provisioning_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_principal_provisioning_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    principal_label text NOT NULL,
    auth_state text NOT NULL,
    encrypted_variables text CONSTRAINT target_principal_provisioning_atte_encrypted_variables_not_null NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT target_principal_provisioning_attempts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: target_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.target_principals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid NOT NULL,
    label text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    tenant_id text,
    auth_state text DEFAULT 'user1'::text NOT NULL,
    credential_profile text,
    is_active boolean DEFAULT true NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tool_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tool_name text NOT NULL,
    tool_version text,
    adapter_version text NOT NULL,
    command_hash text NOT NULL,
    redacted_argv jsonb DEFAULT '[]'::jsonb NOT NULL,
    worker_build text,
    container_image text,
    target_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope_receipt_id text,
    approval_receipt_id uuid,
    policy_profile_id uuid,
    status text DEFAULT 'recorded'::text NOT NULL,
    parser_status text DEFAULT 'not_run'::text NOT NULL,
    exit_code integer,
    timed_out boolean DEFAULT false NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    stdout_evidence_object_id uuid,
    stderr_evidence_object_id uuid,
    parsed_evidence_instance_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    redaction_summary text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    capability_name text,
    adapter_name text,
    budget_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    partial boolean DEFAULT false NOT NULL,
    output_artifact_id uuid,
    hunt_id uuid,
    CONSTRAINT tool_receipts_parser_status_check CHECK ((parser_status = ANY (ARRAY['not_run'::text, 'parsed'::text, 'partial'::text, 'failed'::text, 'not_applicable'::text]))),
    CONSTRAINT tool_receipts_status_check CHECK ((status = ANY (ARRAY['success'::text, 'failed'::text, 'timeout'::text, 'skipped'::text, 'waived'::text, 'parser_error'::text, 'recorded'::text])))
);


--
-- Name: hunt_coverage_angle_events event_seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_coverage_angle_events ALTER COLUMN event_seq SET DEFAULT nextval('public.hunt_coverage_angle_events_event_seq_seq'::regclass);


--
-- Name: research_events sequence; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events ALTER COLUMN sequence SET DEFAULT nextval('public.research_events_sequence_seq'::regclass);


--
-- Data for Name: agent_context_packs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_decision_traces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_hunt_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_surface_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_surfaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_target_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_target_principals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ai_targets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: app_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.app_schema_migrations VALUES ('v2_credential_profiles_v1', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_credential_query_parameter_v1', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_credential_profile_grants_v1', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_auth_sessions_v1', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_budget_reservations_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_budget_reservations_v2', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_budget_reservation_identity_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_budget_validation_owner_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_stage_checkpoints_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_capability_actions_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_action_budget_link_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_action_budget_identity_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_action_leases_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_action_continuations_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_plan_revision_chain_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_plan_revision_immutability_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_plan_multi_round_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_work_manifests_request_candidates_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_observation_manifests_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('authenticated_scan_assurance_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('authentication_validation_requests_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('asm_endpoint_fingerprint_v2', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('campaign_scan_finding_links_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_request_collection_runtime_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('legacy_autonomous_candidates_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('evidence_scan_identity_v2', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_hunt_service_assets_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_target_credentials_to_generic_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_scan_execute_to_semantic_capabilities_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_device_credentials_to_generic_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('v2_ai_credentials_to_generic_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('target_host_identity_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('target_port_identity_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('unified_target_assets_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('unified_target_asset_inputs_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('unified_target_asset_authority_v2', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('unified_target_asset_compatibility_v3', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('target_hunt_delegation_v1', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.app_schema_migrations VALUES ('target_host_canonical_spelling_v1', '2026-10-10 18:42:27.404729+00');


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: application_graph_edges; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: application_graph_nodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asm_endpoint_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: authenticated_profile_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: authentication_validation_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: authentication_validations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: broker_job_leases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: broker_job_results; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: budget_reservations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: campaign_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: command_results; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: credential_profile_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: credential_profile_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: credential_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_agent_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_agent_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_credential_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_interfaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_locator_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: device_policies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.device_policies VALUES ('71c20561-d450-4146-a7b1-e8700bcf0340', 'media-device-baseline-v1', 'Smart TV, streaming, and conference display service baseline.', 'media', 'production', '[{"ports": [21, 23, 2323], "action": "deny", "reason": "Legacy cleartext administration is forbidden.", "service": "any", "severity": "critical", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "publickey_auth": true, "weak_algorithms": false}}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "Cleartext media-device web management requires network isolation.", "service": "http", "severity": "medium", "encrypted": false, "transport": "tcp"}, {"ports": [1900], "action": "allow", "service": "upnp", "transport": "udp"}, {"ports": [5353], "action": "allow", "service": "mdns", "transport": "udp"}, {"action": "review", "reason": "Unexpected media-device service.", "service": "unknown", "severity": "medium", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.device_policies VALUES ('95835c97-1b52-42dc-ac36-c4fb6fa8b09e', 'camera-baseline-v1', 'IP camera and video endpoint baseline.', 'camera', 'production', '[{"ports": [21, 23, 2323], "action": "deny", "reason": "Legacy cleartext administration is forbidden.", "service": "any", "severity": "critical", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "publickey_auth": true, "weak_algorithms": false}}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "Camera management traffic is unencrypted.", "service": "http", "severity": "high", "encrypted": false, "transport": "tcp"}, {"action": "review", "reason": "Confirm RTSP authentication and network isolation.", "service": "rtsp", "severity": "medium", "transport": "tcp"}, {"action": "review", "reason": "Unexpected camera service.", "service": "unknown", "severity": "high", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.device_policies VALUES ('8d859872-da21-40e0-99ad-23c1ea1515df', 'printer-baseline-v1', 'Printer and multifunction-device baseline.', 'printer', 'production', '[{"ports": [21, 23, 2323], "action": "deny", "reason": "Legacy cleartext administration is forbidden.", "service": "any", "severity": "high", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "publickey_auth": true, "weak_algorithms": false}}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "Printer management is unencrypted.", "service": "http", "severity": "medium", "encrypted": false, "transport": "tcp"}, {"ports": [631, 9100], "action": "review", "reason": "Confirm print service access is limited to print networks.", "service": "any", "severity": "low", "transport": "tcp"}, {"ports": [161], "action": "review", "reason": "Confirm SNMPv3 and restricted management access.", "service": "snmp", "severity": "medium", "transport": "udp"}, {"action": "review", "reason": "Unexpected printer service.", "service": "unknown", "severity": "medium", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.device_policies VALUES ('5cb1a7c4-eba5-4446-ac62-489501c3597c', 'network-appliance-baseline-v1', 'Router, access point, NAS, and network appliance baseline.', 'router', 'production', '[{"ports": [21, 23, 2323], "action": "deny", "reason": "Legacy cleartext administration is forbidden.", "service": "any", "severity": "critical", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "publickey_auth": true, "weak_algorithms": false}}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "Network appliance management is unencrypted.", "service": "http", "severity": "high", "encrypted": false, "transport": "tcp"}, {"ports": [53], "action": "allow", "service": "domain", "transport": "any"}, {"ports": [161], "action": "review", "reason": "Confirm SNMPv3 and management-plane isolation.", "service": "snmp", "severity": "medium", "transport": "udp"}, {"action": "review", "reason": "Unexpected network appliance service.", "service": "unknown", "severity": "high", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.054205+00');
INSERT INTO public.device_policies VALUES ('ee2ab9af-134a-482d-a35d-dfe39e99a855', 'connected-device-default-v1', 'Safe baseline: forbid cleartext administration, flag unknown services, and require secure SSH.', 'generic', 'production', '[{"ports": [23, 2323], "action": "deny", "reason": "Cleartext remote administration is forbidden.", "service": "any", "severity": "critical", "transport": "tcp"}, {"ports": [21], "action": "deny", "reason": "Cleartext file transfer is forbidden.", "service": "any", "severity": "high", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "weak_algorithms": false}}, {"action": "allow", "service": "http", "severity": "medium", "encrypted": false, "transport": "tcp"}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "An unclassified listening service requires review.", "service": "unknown", "severity": "medium", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.404729+00');
INSERT INTO public.device_policies VALUES ('c6284d13-e11d-4413-b577-6bca04c83bb4', 'connected-device-default-v2', 'Fail-closed generic baseline: block cleartext administration, require hardened SSH, review cleartext web and unknown services.', 'generic', 'production', '[{"ports": [23, 2323], "action": "deny", "reason": "Cleartext remote administration is forbidden.", "service": "any", "severity": "critical", "transport": "tcp"}, {"ports": [21], "action": "deny", "reason": "Cleartext file transfer is forbidden.", "service": "any", "severity": "high", "transport": "tcp"}, {"action": "require", "service": "ssh", "severity": "high", "transport": "tcp", "requirements": {"password_auth": false, "publickey_auth": true, "weak_algorithms": false}}, {"action": "allow", "service": "https", "encrypted": true, "transport": "tcp"}, {"action": "review", "reason": "Cleartext device management should be isolated or upgraded to HTTPS.", "service": "http", "severity": "medium", "encrypted": false, "transport": "tcp"}, {"action": "review", "reason": "An unclassified listening service requires review.", "service": "unknown", "severity": "medium", "transport": "any"}]', true, true, '2026-10-10 18:42:27.054205+00', '2026-10-10 18:42:27.404729+00');


--
-- Data for Name: device_services; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discovery_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: evidence_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: evidence_objects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: evidence_retention_previews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: export_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finding_exceptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finding_hunt_verifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finding_verifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fleet_node_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: http_archive_stats; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: http_transactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_budget_amendments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_cancellable_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_coverage_angle_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_credential_uses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_permission_baselines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_permission_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_permission_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_permission_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_preauthorizations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hunt_skill_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: hypotheses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: investigation_candidate_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: investigation_candidates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_admission_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_admissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_agent_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_agent_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_approval_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_automatic_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_deployment_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_evidence_manifests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_evidence_records; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_policy_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_runner_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_subjects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_submission_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_submissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_intake_trust_anchors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: node_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: node_join_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: operation_plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: policy_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_api_idempotency; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: refuter_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: request_collection_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: request_collection_environments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: request_collection_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: request_collection_selections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: request_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: research_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: research_episodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: research_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: research_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_action_attempt_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_action_plan_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_artifacts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_capability_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_observation_manifests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_stage_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scan_work_manifests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scope_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_credential_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_device_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_endpoint_expectations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_endpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_invariant_contracts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_principal_provisioning_attempts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: target_principals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: targets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tool_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: hunt_coverage_angle_events_event_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hunt_coverage_angle_events_event_seq_seq', 1, false);


--
-- Name: research_events_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.research_events_sequence_seq', 1, false);


--
-- Name: agent_context_packs agent_context_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_context_packs
    ADD CONSTRAINT agent_context_packs_pkey PRIMARY KEY (id);


--
-- Name: agent_decision_traces agent_decision_traces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_decision_traces
    ADD CONSTRAINT agent_decision_traces_pkey PRIMARY KEY (id);


--
-- Name: agent_hunt_runs agent_hunt_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_hunt_runs
    ADD CONSTRAINT agent_hunt_runs_pkey PRIMARY KEY (id);


--
-- Name: ai_surface_attempts ai_surface_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surface_attempts
    ADD CONSTRAINT ai_surface_attempts_pkey PRIMARY KEY (id);


--
-- Name: ai_surface_attempts ai_surface_attempts_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surface_attempts
    ADD CONSTRAINT ai_surface_attempts_unique UNIQUE (surface_id, scan_id);


--
-- Name: ai_surfaces ai_surfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surfaces
    ADD CONSTRAINT ai_surfaces_pkey PRIMARY KEY (id);


--
-- Name: ai_surfaces ai_surfaces_target_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surfaces
    ADD CONSTRAINT ai_surfaces_target_unique UNIQUE (ai_target_id);


--
-- Name: ai_target_credentials ai_target_credentials_ai_target_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_credentials
    ADD CONSTRAINT ai_target_credentials_ai_target_id_key UNIQUE (ai_target_id);


--
-- Name: ai_target_credentials ai_target_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_credentials
    ADD CONSTRAINT ai_target_credentials_pkey PRIMARY KEY (id);


--
-- Name: ai_target_principals ai_target_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_principals
    ADD CONSTRAINT ai_target_principals_pkey PRIMARY KEY (id);


--
-- Name: ai_target_principals ai_target_principals_target_label_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_principals
    ADD CONSTRAINT ai_target_principals_target_label_unique UNIQUE (ai_target_id, label);


--
-- Name: ai_targets ai_targets_endpoint_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_targets
    ADD CONSTRAINT ai_targets_endpoint_url_key UNIQUE (endpoint_url);


--
-- Name: ai_targets ai_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_targets
    ADD CONSTRAINT ai_targets_pkey PRIMARY KEY (id);


--
-- Name: application_graph_edges app_graph_edge_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_edges
    ADD CONSTRAINT app_graph_edge_unique UNIQUE (target_id, src_key, dst_key, edge_type);


--
-- Name: application_graph_nodes app_graph_node_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_nodes
    ADD CONSTRAINT app_graph_node_unique UNIQUE (target_id, node_type, node_key);


--
-- Name: app_schema_migrations app_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_schema_migrations
    ADD CONSTRAINT app_schema_migrations_pkey PRIMARY KEY (name);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: application_graph_edges application_graph_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_edges
    ADD CONSTRAINT application_graph_edges_pkey PRIMARY KEY (id);


--
-- Name: application_graph_nodes application_graph_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_nodes
    ADD CONSTRAINT application_graph_nodes_pkey PRIMARY KEY (id);


--
-- Name: approval_receipts approval_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_receipts
    ADD CONSTRAINT approval_receipts_pkey PRIMARY KEY (id);


--
-- Name: asm_endpoint_attempts asm_endpoint_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asm_endpoint_attempts
    ADD CONSTRAINT asm_endpoint_attempts_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: authenticated_profile_revisions authenticated_profile_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticated_profile_revisions
    ADD CONSTRAINT authenticated_profile_revisions_pkey PRIMARY KEY (profile_id, revision);


--
-- Name: authentication_validation_requests authentication_validation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validation_requests
    ADD CONSTRAINT authentication_validation_requests_pkey PRIMARY KEY (id);


--
-- Name: authentication_validations authentication_validations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validations
    ADD CONSTRAINT authentication_validations_pkey PRIMARY KEY (id);


--
-- Name: broker_job_leases broker_job_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_leases
    ADD CONSTRAINT broker_job_leases_pkey PRIMARY KEY (id);


--
-- Name: broker_job_leases broker_job_leases_stream_key_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_leases
    ADD CONSTRAINT broker_job_leases_stream_key_message_id_key UNIQUE (stream_key, message_id);


--
-- Name: broker_job_results broker_job_results_lease_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_results
    ADD CONSTRAINT broker_job_results_lease_id_key UNIQUE (lease_id);


--
-- Name: broker_job_results broker_job_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_results
    ADD CONSTRAINT broker_job_results_pkey PRIMARY KEY (id);


--
-- Name: budget_reservations budget_reservations_action_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_reservations
    ADD CONSTRAINT budget_reservations_action_unique UNIQUE (owner_kind, owner_id, action_id);


--
-- Name: budget_reservations budget_reservations_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_reservations
    ADD CONSTRAINT budget_reservations_identity_unique UNIQUE (id, owner_kind, owner_id, action_id, action_digest);


--
-- Name: budget_reservations budget_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_reservations
    ADD CONSTRAINT budget_reservations_pkey PRIMARY KEY (id);


--
-- Name: campaign_actions campaign_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: command_results command_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_pkey PRIMARY KEY (id);


--
-- Name: credential_profile_bindings credential_profile_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profile_bindings
    ADD CONSTRAINT credential_profile_bindings_pkey PRIMARY KEY (id);


--
-- Name: credential_profile_bindings credential_profile_bindings_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profile_bindings
    ADD CONSTRAINT credential_profile_bindings_unique UNIQUE (profile_id, binding_kind, binding_id);


--
-- Name: credential_profile_versions credential_profile_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profile_versions
    ADD CONSTRAINT credential_profile_versions_pkey PRIMARY KEY (profile_id, version);


--
-- Name: credential_profiles credential_profiles_id_auth_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profiles
    ADD CONSTRAINT credential_profiles_id_auth_unique UNIQUE (id, auth_kind);


--
-- Name: credential_profiles credential_profiles_id_target_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profiles
    ADD CONSTRAINT credential_profiles_id_target_unique UNIQUE (id, target_kind, target_id);


--
-- Name: credential_profiles credential_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profiles
    ADD CONSTRAINT credential_profiles_pkey PRIMARY KEY (id);


--
-- Name: credential_profiles credential_profiles_target_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profiles
    ADD CONSTRAINT credential_profiles_target_name_unique UNIQUE (target_kind, target_id, name);


--
-- Name: device_agent_actions device_agent_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_actions
    ADD CONSTRAINT device_agent_actions_pkey PRIMARY KEY (id);


--
-- Name: device_agent_runs device_agent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_runs
    ADD CONSTRAINT device_agent_runs_pkey PRIMARY KEY (id);


--
-- Name: device_credential_attempts device_credential_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_pkey PRIMARY KEY (id);


--
-- Name: device_credential_attempts device_credential_attempts_scan_profile_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_scan_profile_unique UNIQUE (scan_id, credential_profile_id);


--
-- Name: device_interfaces device_interfaces_locator_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_interfaces
    ADD CONSTRAINT device_interfaces_locator_unique UNIQUE (device_target_id, interface_type, locator_type, locator);


--
-- Name: device_interfaces device_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_interfaces
    ADD CONSTRAINT device_interfaces_pkey PRIMARY KEY (id);


--
-- Name: device_locator_history device_locator_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_locator_history
    ADD CONSTRAINT device_locator_history_pkey PRIMARY KEY (id);


--
-- Name: device_policies device_policies_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_policies
    ADD CONSTRAINT device_policies_name_key UNIQUE (name);


--
-- Name: device_policies device_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_policies
    ADD CONSTRAINT device_policies_pkey PRIMARY KEY (id);


--
-- Name: device_services device_services_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_identity_unique UNIQUE (device_target_id, transport, port);


--
-- Name: device_services device_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_pkey PRIMARY KEY (id);


--
-- Name: discovery_runs discovery_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discovery_runs
    ADD CONSTRAINT discovery_runs_pkey PRIMARY KEY (id);


--
-- Name: evidence_instances evidence_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_pkey PRIMARY KEY (id);


--
-- Name: evidence_objects evidence_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_objects
    ADD CONSTRAINT evidence_objects_pkey PRIMARY KEY (id);


--
-- Name: evidence_retention_previews evidence_retention_previews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_retention_previews
    ADD CONSTRAINT evidence_retention_previews_pkey PRIMARY KEY (id);


--
-- Name: export_events export_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_events
    ADD CONSTRAINT export_events_pkey PRIMARY KEY (id);


--
-- Name: finding_exceptions finding_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_exceptions
    ADD CONSTRAINT finding_exceptions_pkey PRIMARY KEY (id);


--
-- Name: finding_hunt_verifications finding_hunt_verifications_action_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_hunt_verifications
    ADD CONSTRAINT finding_hunt_verifications_action_unique UNIQUE (finding_id, action_id);


--
-- Name: finding_hunt_verifications finding_hunt_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_hunt_verifications
    ADD CONSTRAINT finding_hunt_verifications_pkey PRIMARY KEY (id);


--
-- Name: finding_verifications finding_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_pkey PRIMARY KEY (id);


--
-- Name: finding_verifications finding_verifications_subject_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.finding_verifications
    ADD CONSTRAINT finding_verifications_subject_check CHECK (((finding_id IS NOT NULL) OR (candidate_id IS NOT NULL))) NOT VALID;


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: fleet_node_events fleet_node_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_node_events
    ADD CONSTRAINT fleet_node_events_pkey PRIMARY KEY (id);


--
-- Name: http_archive_stats http_archive_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_archive_stats
    ADD CONSTRAINT http_archive_stats_pkey PRIMARY KEY (owner_kind, owner_id);


--
-- Name: http_transactions http_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_pkey PRIMARY KEY (id);


--
-- Name: hunt_actions hunt_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_actions
    ADD CONSTRAINT hunt_actions_pkey PRIMARY KEY (id);


--
-- Name: hunt_budget_amendments hunt_budget_amendments_hunt_run_id_request_key_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_budget_amendments
    ADD CONSTRAINT hunt_budget_amendments_hunt_run_id_request_key_sha256_key UNIQUE (hunt_run_id, request_key_sha256);


--
-- Name: hunt_budget_amendments hunt_budget_amendments_hunt_run_id_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_budget_amendments
    ADD CONSTRAINT hunt_budget_amendments_hunt_run_id_revision_key UNIQUE (hunt_run_id, revision);


--
-- Name: hunt_budget_amendments hunt_budget_amendments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_budget_amendments
    ADD CONSTRAINT hunt_budget_amendments_pkey PRIMARY KEY (id);


--
-- Name: hunt_cancellable_jobs hunt_cancellable_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_cancellable_jobs
    ADD CONSTRAINT hunt_cancellable_jobs_pkey PRIMARY KEY (hunt_id, job_id);


--
-- Name: hunt_coverage_angle_events hunt_coverage_angle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_coverage_angle_events
    ADD CONSTRAINT hunt_coverage_angle_events_pkey PRIMARY KEY (id);


--
-- Name: hunt_credential_uses hunt_credential_uses_action_slot_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_credential_uses
    ADD CONSTRAINT hunt_credential_uses_action_slot_unique UNIQUE (action_id, profile_id, slot);


--
-- Name: hunt_credential_uses hunt_credential_uses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_credential_uses
    ADD CONSTRAINT hunt_credential_uses_pkey PRIMARY KEY (id);


--
-- Name: hunt_permission_baselines hunt_permission_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_baselines
    ADD CONSTRAINT hunt_permission_baselines_pkey PRIMARY KEY (hunt_run_id);


--
-- Name: hunt_permission_events hunt_permission_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_events
    ADD CONSTRAINT hunt_permission_events_pkey PRIMARY KEY (id);


--
-- Name: hunt_permission_grants hunt_permission_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_grants
    ADD CONSTRAINT hunt_permission_grants_pkey PRIMARY KEY (id);


--
-- Name: hunt_permission_grants hunt_permission_grants_request_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_grants
    ADD CONSTRAINT hunt_permission_grants_request_unique UNIQUE (request_id);


--
-- Name: hunt_permission_requests hunt_permission_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_requests
    ADD CONSTRAINT hunt_permission_requests_pkey PRIMARY KEY (id);


--
-- Name: hunt_preauthorizations hunt_preauthorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_preauthorizations
    ADD CONSTRAINT hunt_preauthorizations_pkey PRIMARY KEY (id);


--
-- Name: hunt_runs hunt_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_runs
    ADD CONSTRAINT hunt_runs_pkey PRIMARY KEY (id);


--
-- Name: hunt_skill_events hunt_skill_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_skill_events
    ADD CONSTRAINT hunt_skill_events_pkey PRIMARY KEY (id);


--
-- Name: hypotheses hypotheses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hypotheses
    ADD CONSTRAINT hypotheses_pkey PRIMARY KEY (id);


--
-- Name: investigation_candidate_observations investigation_candidate_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_pkey PRIMARY KEY (id);


--
-- Name: investigation_candidates investigation_candidates_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_fingerprint_key UNIQUE (fingerprint);


--
-- Name: investigation_candidates investigation_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_pkey PRIMARY KEY (id);


--
-- Name: model_intake_admission_events model_intake_admission_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admission_events
    ADD CONSTRAINT model_intake_admission_events_pkey PRIMARY KEY (id);


--
-- Name: model_intake_admissions model_intake_admissions_idempotency_key_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_idempotency_key_sha256_key UNIQUE (idempotency_key_sha256);


--
-- Name: model_intake_admissions model_intake_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_pkey PRIMARY KEY (id);


--
-- Name: model_intake_admissions model_intake_admissions_scan_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_scan_id_key UNIQUE (scan_id);


--
-- Name: model_intake_admissions model_intake_admissions_statement_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_statement_sha256_key UNIQUE (statement_sha256);


--
-- Name: model_intake_agent_actions model_intake_agent_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_agent_actions
    ADD CONSTRAINT model_intake_agent_actions_pkey PRIMARY KEY (id);


--
-- Name: model_intake_agent_sessions model_intake_agent_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_agent_sessions
    ADD CONSTRAINT model_intake_agent_sessions_pkey PRIMARY KEY (id);


--
-- Name: model_intake_approval_receipts model_intake_approval_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_approval_receipts
    ADD CONSTRAINT model_intake_approval_receipts_pkey PRIMARY KEY (id);


--
-- Name: model_intake_approval_receipts model_intake_approval_receipts_receipt_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_approval_receipts
    ADD CONSTRAINT model_intake_approval_receipts_receipt_sha256_key UNIQUE (receipt_sha256);


--
-- Name: model_intake_automatic_reviews model_intake_automatic_review_scan_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_review_scan_unique UNIQUE (scan_id);


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_pkey PRIMARY KEY (id);


--
-- Name: model_intake_deployment_bindings model_intake_deployment_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_deployment_bindings
    ADD CONSTRAINT model_intake_deployment_bindings_pkey PRIMARY KEY (id);


--
-- Name: model_intake_evidence_records model_intake_evidence_invocation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_records
    ADD CONSTRAINT model_intake_evidence_invocation_unique UNIQUE (producer_id, invocation_id);


--
-- Name: model_intake_evidence_manifests model_intake_evidence_manifest_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_manifests
    ADD CONSTRAINT model_intake_evidence_manifest_version_unique UNIQUE (submission_id, version);


--
-- Name: model_intake_evidence_manifests model_intake_evidence_manifests_manifest_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_manifests
    ADD CONSTRAINT model_intake_evidence_manifests_manifest_sha256_key UNIQUE (manifest_sha256);


--
-- Name: model_intake_evidence_manifests model_intake_evidence_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_manifests
    ADD CONSTRAINT model_intake_evidence_manifests_pkey PRIMARY KEY (id);


--
-- Name: model_intake_evidence_records model_intake_evidence_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_records
    ADD CONSTRAINT model_intake_evidence_records_pkey PRIMARY KEY (id);


--
-- Name: model_intake_policy_decisions model_intake_policy_decisions_decision_sha256_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_policy_decisions
    ADD CONSTRAINT model_intake_policy_decisions_decision_sha256_key UNIQUE (decision_sha256);


--
-- Name: model_intake_policy_decisions model_intake_policy_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_policy_decisions
    ADD CONSTRAINT model_intake_policy_decisions_pkey PRIMARY KEY (id);


--
-- Name: model_intake_runner_jobs model_intake_runner_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_runner_jobs
    ADD CONSTRAINT model_intake_runner_jobs_pkey PRIMARY KEY (id);


--
-- Name: model_intake_runner_jobs model_intake_runner_jobs_remote_job_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_runner_jobs
    ADD CONSTRAINT model_intake_runner_jobs_remote_job_id_key UNIQUE (remote_job_id);


--
-- Name: model_intake_subjects model_intake_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_subjects
    ADD CONSTRAINT model_intake_subject_unique UNIQUE (submission_id, subject_kind, sha256);


--
-- Name: model_intake_subjects model_intake_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_subjects
    ADD CONSTRAINT model_intake_subjects_pkey PRIMARY KEY (id);


--
-- Name: model_intake_submission_events model_intake_submission_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_submission_events
    ADD CONSTRAINT model_intake_submission_events_pkey PRIMARY KEY (id);


--
-- Name: model_intake_submissions model_intake_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_submissions
    ADD CONSTRAINT model_intake_submissions_pkey PRIMARY KEY (id);


--
-- Name: model_intake_trust_anchors model_intake_trust_anchors_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_trust_anchors
    ADD CONSTRAINT model_intake_trust_anchors_name_key UNIQUE (name);


--
-- Name: model_intake_trust_anchors model_intake_trust_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_trust_anchors
    ADD CONSTRAINT model_intake_trust_anchors_pkey PRIMARY KEY (id);


--
-- Name: node_credentials node_credentials_credential_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_credentials
    ADD CONSTRAINT node_credentials_credential_hash_key UNIQUE (credential_hash);


--
-- Name: node_credentials node_credentials_node_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_credentials
    ADD CONSTRAINT node_credentials_node_version_unique UNIQUE (node_id, credential_version);


--
-- Name: node_credentials node_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_credentials
    ADD CONSTRAINT node_credentials_pkey PRIMARY KEY (id);


--
-- Name: node_join_tokens node_join_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_join_tokens
    ADD CONSTRAINT node_join_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: node_join_tokens node_join_tokens_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_join_tokens
    ADD CONSTRAINT node_join_tokens_token_id_key UNIQUE (token_id);


--
-- Name: nodes nodes_overlay_ip_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_overlay_ip_key UNIQUE (overlay_ip);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: nodes nodes_wireguard_public_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_wireguard_public_key_key UNIQUE (wireguard_public_key);


--
-- Name: operation_plans operation_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_plans
    ADD CONSTRAINT operation_plans_pkey PRIMARY KEY (id);


--
-- Name: policy_profiles policy_profiles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_profiles
    ADD CONSTRAINT policy_profiles_name_key UNIQUE (name);


--
-- Name: policy_profiles policy_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_profiles
    ADD CONSTRAINT policy_profiles_pkey PRIMARY KEY (id);


--
-- Name: public_api_idempotency public_api_idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_api_idempotency
    ADD CONSTRAINT public_api_idempotency_pkey PRIMARY KEY (method, path, key_sha256);


--
-- Name: refuter_reviews refuter_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refuter_reviews
    ADD CONSTRAINT refuter_reviews_pkey PRIMARY KEY (id);


--
-- Name: request_collection_bindings request_collection_bindings_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_bindings
    ADD CONSTRAINT request_collection_bindings_identity_unique UNIQUE (id, collection_id);


--
-- Name: request_collection_bindings request_collection_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_bindings
    ADD CONSTRAINT request_collection_bindings_pkey PRIMARY KEY (id);


--
-- Name: request_collection_bindings request_collection_bindings_target_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_bindings
    ADD CONSTRAINT request_collection_bindings_target_unique UNIQUE (collection_id, target_kind, target_id);


--
-- Name: request_collection_environments request_collection_environments_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_environments
    ADD CONSTRAINT request_collection_environments_identity_unique UNIQUE (id, collection_id);


--
-- Name: request_collection_environments request_collection_environments_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_environments
    ADD CONSTRAINT request_collection_environments_name_unique UNIQUE (collection_id, name);


--
-- Name: request_collection_environments request_collection_environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_environments
    ADD CONSTRAINT request_collection_environments_pkey PRIMARY KEY (id);


--
-- Name: request_collection_requests request_collection_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_requests
    ADD CONSTRAINT request_collection_requests_pkey PRIMARY KEY (collection_id, request_id);


--
-- Name: request_collection_selections request_collection_selections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_selections
    ADD CONSTRAINT request_collection_selections_pkey PRIMARY KEY (id);


--
-- Name: request_collections request_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collections
    ADD CONSTRAINT request_collections_pkey PRIMARY KEY (id);


--
-- Name: request_collections request_collections_target_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collections
    ADD CONSTRAINT request_collections_target_name_unique UNIQUE NULLS NOT DISTINCT (target_id, device_target_id, name);


--
-- Name: research_decisions research_decisions_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: research_decisions research_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_pkey PRIMARY KEY (id);


--
-- Name: research_episodes research_episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_pkey PRIMARY KEY (id);


--
-- Name: research_events research_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events
    ADD CONSTRAINT research_events_pkey PRIMARY KEY (id);


--
-- Name: research_observations research_observations_episode_sequence_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_observations
    ADD CONSTRAINT research_observations_episode_sequence_unique UNIQUE (episode_id, sequence);


--
-- Name: research_observations research_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_observations
    ADD CONSTRAINT research_observations_pkey PRIMARY KEY (id);


--
-- Name: scan_action_attempt_checkpoints scan_action_attempt_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_attempt_checkpoints
    ADD CONSTRAINT scan_action_attempt_checkpoints_pkey PRIMARY KEY (scan_id, action_id, attempt_id);


--
-- Name: scan_action_plan_revisions scan_action_plan_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_plan_revisions
    ADD CONSTRAINT scan_action_plan_revisions_pkey PRIMARY KEY (scan_id, revision);


--
-- Name: scan_action_plan_revisions scan_action_plan_revisions_scan_id_plan_digest_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_plan_revisions
    ADD CONSTRAINT scan_action_plan_revisions_scan_id_plan_digest_key UNIQUE (scan_id, plan_digest);


--
-- Name: scan_artifacts scan_artifacts_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_artifacts
    ADD CONSTRAINT scan_artifacts_identity_unique UNIQUE (scan_id, artifact_type, artifact_key);


--
-- Name: scan_artifacts scan_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_artifacts
    ADD CONSTRAINT scan_artifacts_pkey PRIMARY KEY (id);


--
-- Name: scan_campaigns scan_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_campaigns
    ADD CONSTRAINT scan_campaigns_pkey PRIMARY KEY (id);


--
-- Name: scan_capability_actions scan_capability_actions_action_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_capability_actions
    ADD CONSTRAINT scan_capability_actions_action_unique UNIQUE (scan_id, action_id);


--
-- Name: scan_capability_actions scan_capability_actions_ordinal_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_capability_actions
    ADD CONSTRAINT scan_capability_actions_ordinal_unique UNIQUE (scan_id, ordinal);


--
-- Name: scan_capability_actions scan_capability_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_capability_actions
    ADD CONSTRAINT scan_capability_actions_pkey PRIMARY KEY (id);


--
-- Name: scan_observation_manifests scan_observation_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_observation_manifests
    ADD CONSTRAINT scan_observation_identity_unique UNIQUE (scan_id, action_id, content_sha256);


--
-- Name: scan_observation_manifests scan_observation_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_observation_manifests
    ADD CONSTRAINT scan_observation_manifests_pkey PRIMARY KEY (id);


--
-- Name: scan_stage_checkpoints scan_stage_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_stage_checkpoints
    ADD CONSTRAINT scan_stage_checkpoints_pkey PRIMARY KEY (scan_id, job_id, stage_index);


--
-- Name: scan_stage_checkpoints scan_stage_checkpoints_stage_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_stage_checkpoints
    ADD CONSTRAINT scan_stage_checkpoints_stage_unique UNIQUE (scan_id, job_id, stage_name);


--
-- Name: scan_work_manifests scan_work_manifest_identity_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_work_manifests
    ADD CONSTRAINT scan_work_manifest_identity_unique UNIQUE (scan_id, kind, manifest_digest);


--
-- Name: scan_work_manifests scan_work_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_work_manifests
    ADD CONSTRAINT scan_work_manifests_pkey PRIMARY KEY (id);


--
-- Name: scans scans_job_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_job_id_key UNIQUE (job_id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: scope_receipts scope_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_receipts
    ADD CONSTRAINT scope_receipts_pkey PRIMARY KEY (id);


--
-- Name: target_credential_profiles target_credential_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_credential_profiles
    ADD CONSTRAINT target_credential_profiles_pkey PRIMARY KEY (id);


--
-- Name: target_device_profiles target_device_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_device_profiles
    ADD CONSTRAINT target_device_profiles_pkey PRIMARY KEY (target_id);


--
-- Name: target_endpoint_expectations target_endpoint_expectations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoint_expectations
    ADD CONSTRAINT target_endpoint_expectations_pkey PRIMARY KEY (id);


--
-- Name: target_endpoints target_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoints
    ADD CONSTRAINT target_endpoints_pkey PRIMARY KEY (id);


--
-- Name: target_invariant_contracts target_invariant_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_invariant_contracts
    ADD CONSTRAINT target_invariant_contracts_pkey PRIMARY KEY (id);


--
-- Name: target_principal_provisioning_attempts target_principal_provisioning_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_principal_provisioning_attempts
    ADD CONSTRAINT target_principal_provisioning_attempts_pkey PRIMARY KEY (id);


--
-- Name: target_principal_provisioning_attempts target_principal_provisioning_attempts_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_principal_provisioning_attempts
    ADD CONSTRAINT target_principal_provisioning_attempts_unique UNIQUE (target_id, auth_state);


--
-- Name: target_principals target_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_principals
    ADD CONSTRAINT target_principals_pkey PRIMARY KEY (id);


--
-- Name: targets targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT targets_pkey PRIMARY KEY (id);


--
-- Name: targets targets_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT targets_url_key UNIQUE (url);


--
-- Name: tool_receipts tool_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_pkey PRIMARY KEY (id);


--
-- Name: app_graph_device_node_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX app_graph_device_node_unique ON public.application_graph_nodes USING btree (device_target_id, node_type, node_key);


--
-- Name: authentication_validation_requests_profile_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authentication_validation_requests_profile_time ON public.authentication_validation_requests USING btree (profile_id, created_at DESC);


--
-- Name: authentication_validations_profile_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authentication_validations_profile_time ON public.authentication_validations USING btree (profile_id, revision, checked_at DESC, id);


--
-- Name: idx_agent_context_packs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_context_packs_created_at ON public.agent_context_packs USING btree (created_at DESC);


--
-- Name: idx_agent_context_packs_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_context_packs_hash ON public.agent_context_packs USING btree (context_hash);


--
-- Name: idx_agent_decision_traces_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_decision_traces_created_at ON public.agent_decision_traces USING btree (created_at DESC);


--
-- Name: idx_agent_decision_traces_plan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_decision_traces_plan ON public.agent_decision_traces USING btree (operation_plan_id, created_at DESC) WHERE (operation_plan_id IS NOT NULL);


--
-- Name: idx_agent_hunt_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_hunt_runs_status ON public.agent_hunt_runs USING btree (status, updated_at DESC);


--
-- Name: idx_agent_hunt_runs_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_hunt_runs_target ON public.agent_hunt_runs USING btree (target_id, created_at DESC);


--
-- Name: idx_ai_surface_attempts_surface; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_surface_attempts_surface ON public.ai_surface_attempts USING btree (surface_id, completed_at DESC);


--
-- Name: idx_ai_target_principals_target_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_target_principals_target_active ON public.ai_target_principals USING btree (ai_target_id, is_active);


--
-- Name: idx_ai_targets_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_targets_active ON public.ai_targets USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_ai_targets_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_targets_active_created ON public.ai_targets USING btree (is_active, created_at DESC);


--
-- Name: idx_ai_targets_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_targets_created ON public.ai_targets USING btree (created_at DESC);


--
-- Name: idx_app_graph_edges_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_graph_edges_target ON public.application_graph_edges USING btree (target_id);


--
-- Name: idx_app_graph_nodes_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_graph_nodes_target ON public.application_graph_nodes USING btree (target_id);


--
-- Name: idx_application_graph_nodes_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_application_graph_nodes_unified_target ON public.application_graph_nodes USING btree (target_id);


--
-- Name: idx_approval_receipts_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_receipts_scope ON public.approval_receipts USING btree (scope_receipt_id);


--
-- Name: idx_asm_endpoint_attempts_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_asm_endpoint_attempts_campaign ON public.asm_endpoint_attempts USING btree (campaign_id, status);


--
-- Name: idx_asm_endpoint_attempts_campaign_family; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_asm_endpoint_attempts_campaign_family ON public.asm_endpoint_attempts USING btree (campaign_id, check_family, status);


--
-- Name: idx_asm_endpoint_attempts_endpoint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_asm_endpoint_attempts_endpoint ON public.asm_endpoint_attempts USING btree (endpoint_id, started_at DESC);


--
-- Name: idx_asm_endpoint_attempts_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_asm_endpoint_attempts_scan ON public.asm_endpoint_attempts USING btree (scan_id) WHERE (scan_id IS NOT NULL);


--
-- Name: idx_auth_sessions_owner_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_owner_active ON public.auth_sessions USING btree (owner_kind, owner_id, principal_slot, status, expires_at);


--
-- Name: idx_auth_sessions_profile_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_profile_active ON public.auth_sessions USING btree (profile_id, profile_version, status, expires_at);


--
-- Name: idx_broker_job_leases_active_worker; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_broker_job_leases_active_worker ON public.broker_job_leases USING btree (node_id, worker_id) WHERE (status = 'leased'::text);


--
-- Name: idx_broker_job_leases_node_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_broker_job_leases_node_status ON public.broker_job_leases USING btree (node_id, status, lease_expires_at);


--
-- Name: idx_budget_reservations_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_budget_reservations_owner ON public.budget_reservations USING btree (owner_kind, owner_id, updated_at DESC);


--
-- Name: idx_budget_reservations_stale; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_budget_reservations_stale ON public.budget_reservations USING btree (lease_expires_at) WHERE (status = ANY (ARRAY['reserved'::text, 'running'::text]));


--
-- Name: idx_campaign_actions_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_actions_campaign ON public.campaign_actions USING btree (campaign_id, created_at DESC) WHERE (campaign_id IS NOT NULL);


--
-- Name: idx_campaign_actions_command_result; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_actions_command_result ON public.campaign_actions USING btree (command_result_id) WHERE (command_result_id IS NOT NULL);


--
-- Name: idx_campaign_actions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_actions_created_at ON public.campaign_actions USING btree (created_at DESC);


--
-- Name: idx_campaign_actions_mission_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_actions_mission_campaign ON public.campaign_actions USING btree (mission_campaign_id, created_at DESC) WHERE (mission_campaign_id IS NOT NULL);


--
-- Name: idx_campaign_actions_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_actions_target ON public.campaign_actions USING btree (target_id, created_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_campaigns_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaigns_created_at ON public.campaigns USING btree (created_at DESC);


--
-- Name: idx_campaigns_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaigns_target ON public.campaigns USING btree (target_id, created_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_command_results_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_command_results_campaign ON public.command_results USING btree (campaign_id, created_at DESC) WHERE (campaign_id IS NOT NULL);


--
-- Name: idx_command_results_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_command_results_created_at ON public.command_results USING btree (created_at DESC);


--
-- Name: idx_command_results_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_command_results_created_by ON public.command_results USING btree (created_by, created_at DESC) WHERE (created_by IS NOT NULL);


--
-- Name: idx_command_results_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_command_results_scan ON public.command_results USING btree (scan_id, created_at DESC) WHERE (scan_id IS NOT NULL);


--
-- Name: idx_credential_profile_bindings_consumer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credential_profile_bindings_consumer ON public.credential_profile_bindings USING btree (binding_kind, binding_id, is_active);


--
-- Name: idx_credential_profiles_target_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credential_profiles_target_active ON public.credential_profiles USING btree (target_kind, target_id, is_active, expires_at);


--
-- Name: idx_credential_profiles_target_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_credential_profiles_target_name_ci ON public.credential_profiles USING btree (target_kind, target_id, lower(name));


--
-- Name: idx_device_agent_actions_device_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_actions_device_day ON public.device_agent_actions USING btree (device_target_id, created_at DESC);


--
-- Name: idx_device_agent_actions_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_actions_run ON public.device_agent_actions USING btree (run_id, created_at);


--
-- Name: idx_device_agent_actions_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_actions_unified_target ON public.device_agent_actions USING btree (target_id);


--
-- Name: idx_device_agent_runs_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_runs_device ON public.device_agent_runs USING btree (device_target_id, created_at DESC);


--
-- Name: idx_device_agent_runs_one_active_per_device; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_device_agent_runs_one_active_per_device ON public.device_agent_runs USING btree (device_target_id) WHERE (status = ANY (ARRAY['awaiting_planner'::text, 'planning'::text]));


--
-- Name: idx_device_agent_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_runs_status ON public.device_agent_runs USING btree (status, updated_at DESC);


--
-- Name: idx_device_agent_runs_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_agent_runs_unified_target ON public.device_agent_runs USING btree (target_id);


--
-- Name: idx_device_credential_attempts_profile_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_credential_attempts_profile_time ON public.device_credential_attempts USING btree (credential_profile_id, attempted_at DESC);


--
-- Name: idx_device_credential_attempts_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_credential_attempts_unified_target ON public.device_credential_attempts USING btree (target_id);


--
-- Name: idx_device_interfaces_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_interfaces_unified_target ON public.device_interfaces USING btree (target_id);


--
-- Name: idx_device_locator_history_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_locator_history_device ON public.device_locator_history USING btree (device_target_id, changed_at DESC);


--
-- Name: idx_device_locator_history_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_locator_history_unified_target ON public.device_locator_history USING btree (target_id);


--
-- Name: idx_device_services_target_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_services_target_seen ON public.device_services USING btree (device_target_id, last_seen_at DESC);


--
-- Name: idx_device_services_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_services_unified_target ON public.device_services USING btree (target_id);


--
-- Name: idx_discovery_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_created ON public.discovery_runs USING btree (created_at DESC);


--
-- Name: idx_discovery_root_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_root_domain ON public.discovery_runs USING btree (root_domain);


--
-- Name: idx_evidence_instances_candidate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_instances_candidate ON public.evidence_instances USING btree (candidate_id, created_at DESC) WHERE (candidate_id IS NOT NULL);


--
-- Name: idx_evidence_instances_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_instances_finding ON public.evidence_instances USING btree (finding_id, created_at DESC) WHERE (finding_id IS NOT NULL);


--
-- Name: idx_evidence_instances_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_instances_hash ON public.evidence_instances USING btree (hash);


--
-- Name: idx_evidence_instances_tool_receipt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_instances_tool_receipt ON public.evidence_instances USING btree (tool_receipt_id) WHERE (tool_receipt_id IS NOT NULL);


--
-- Name: idx_evidence_instances_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_instances_unified_target ON public.evidence_instances USING btree (target_id);


--
-- Name: idx_evidence_objects_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_objects_finding ON public.evidence_objects USING btree (finding_id);


--
-- Name: idx_evidence_objects_finding_type_scan_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_evidence_objects_finding_type_scan_unique ON public.evidence_objects USING btree (finding_id, object_type, scan_id) WHERE ((finding_id IS NOT NULL) AND (scan_id IS NOT NULL));


--
-- Name: idx_evidence_objects_finding_type_unscoped_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_evidence_objects_finding_type_unscoped_unique ON public.evidence_objects USING btree (finding_id, object_type) WHERE ((finding_id IS NOT NULL) AND (scan_id IS NULL));


--
-- Name: idx_evidence_objects_retention_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_objects_retention_pending ON public.evidence_objects USING btree (retention_delete_pending_at) WHERE (retention_delete_pending_at IS NOT NULL);


--
-- Name: idx_evidence_objects_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_objects_scan ON public.evidence_objects USING btree (scan_id);


--
-- Name: idx_evidence_retention_previews_approval_once; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_evidence_retention_previews_approval_once ON public.evidence_retention_previews USING btree (approval_receipt_id) WHERE (approval_receipt_id IS NOT NULL);


--
-- Name: idx_evidence_retention_previews_ready; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_retention_previews_ready ON public.evidence_retention_previews USING btree (expires_at) WHERE (status = 'ready'::text);


--
-- Name: idx_evidence_retention_previews_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_evidence_retention_previews_target ON public.evidence_retention_previews USING btree (target_id, created_at DESC);


--
-- Name: idx_export_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_export_events_created_at ON public.export_events USING btree (created_at DESC);


--
-- Name: idx_export_events_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_export_events_finding ON public.export_events USING btree (finding_id, created_at DESC) WHERE (finding_id IS NOT NULL);


--
-- Name: idx_export_events_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_export_events_scan ON public.export_events USING btree (scan_id, created_at DESC) WHERE (scan_id IS NOT NULL);


--
-- Name: idx_export_events_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_export_events_target ON public.export_events USING btree (target_id, created_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_finding_exceptions_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_exceptions_finding ON public.finding_exceptions USING btree (finding_id);


--
-- Name: idx_finding_exceptions_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_exceptions_target_status ON public.finding_exceptions USING btree (target_id, status);


--
-- Name: idx_finding_hunt_verifications_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_hunt_verifications_finding ON public.finding_hunt_verifications USING btree (finding_id, verified_at, id);


--
-- Name: idx_finding_hunt_verifications_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_hunt_verifications_run ON public.finding_hunt_verifications USING btree (hunt_run_id, verified_at, id);


--
-- Name: idx_finding_verifications_finding_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_finding_id ON public.finding_verifications USING btree (finding_id, created_at DESC);


--
-- Name: idx_finding_verifications_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_job_id ON public.finding_verifications USING btree (job_id) WHERE (job_id IS NOT NULL);


--
-- Name: idx_finding_verifications_requested_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_requested_by ON public.finding_verifications USING btree (requested_by, created_at DESC) WHERE (requested_by IS NOT NULL);


--
-- Name: idx_finding_verifications_result_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_result_status ON public.finding_verifications USING btree (result_status);


--
-- Name: idx_finding_verifications_retry_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_retry_class ON public.finding_verifications USING btree (retry_class) WHERE (retry_class IS NOT NULL);


--
-- Name: idx_finding_verifications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_status ON public.finding_verifications USING btree (status);


--
-- Name: idx_finding_verifications_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_unified_target ON public.finding_verifications USING btree (target_id);


--
-- Name: idx_finding_verifications_verdict; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_finding_verifications_verdict ON public.finding_verifications USING btree (verdict);


--
-- Name: idx_findings_ai_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_ai_target ON public.findings USING btree (ai_target_id) WHERE (ai_target_id IS NOT NULL);


--
-- Name: idx_findings_ai_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_ai_target_id ON public.findings USING btree (ai_target_id) WHERE (ai_target_id IS NOT NULL);


--
-- Name: idx_findings_device_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_findings_device_fingerprint ON public.findings USING btree (device_target_id, fingerprint) WHERE (device_target_id IS NOT NULL);


--
-- Name: idx_findings_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_fingerprint ON public.findings USING btree (fingerprint);


--
-- Name: idx_findings_first_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_first_seen ON public.findings USING btree (first_seen_at DESC);


--
-- Name: idx_findings_first_seen_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_first_seen_scan_id ON public.findings USING btree (first_seen_scan_id);


--
-- Name: idx_findings_hunt_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_hunt_run_id ON public.findings USING btree (hunt_run_id) WHERE (hunt_run_id IS NOT NULL);


--
-- Name: idx_findings_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_last_seen ON public.findings USING btree (last_seen_at DESC NULLS LAST);


--
-- Name: idx_findings_last_seen_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_last_seen_scan_id ON public.findings USING btree (last_seen_scan_id);


--
-- Name: idx_findings_last_verification_verdict; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_last_verification_verdict ON public.findings USING btree (last_verification_verdict);


--
-- Name: idx_findings_last_verified_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_last_verified_at ON public.findings USING btree (last_verified_at DESC) WHERE (last_verified_at IS NOT NULL);


--
-- Name: idx_findings_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_scan_id ON public.findings USING btree (scan_id);


--
-- Name: idx_findings_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_session_id ON public.findings USING btree (session_id) WHERE (session_id IS NOT NULL);


--
-- Name: idx_findings_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_severity ON public.findings USING btree (severity);


--
-- Name: idx_findings_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_source ON public.findings USING btree (source);


--
-- Name: idx_findings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_status ON public.findings USING btree (status);


--
-- Name: idx_findings_target_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_findings_target_fingerprint ON public.findings USING btree (target_id, fingerprint) WHERE (target_id IS NOT NULL);


--
-- Name: idx_findings_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_target_id ON public.findings USING btree (target_id);


--
-- Name: idx_findings_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_findings_unified_target ON public.findings USING btree (target_id);


--
-- Name: idx_fleet_node_events_node_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_node_events_node_created ON public.fleet_node_events USING btree (node_id, created_at DESC);


--
-- Name: idx_http_transactions_hunt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_http_transactions_hunt ON public.http_transactions USING btree (hunt_run_id, sequence) WHERE (hunt_run_id IS NOT NULL);


--
-- Name: idx_http_transactions_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_http_transactions_scan ON public.http_transactions USING btree (scan_id, sequence) WHERE (scan_id IS NOT NULL);


--
-- Name: idx_http_transactions_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_http_transactions_target ON public.http_transactions USING btree (target_id, started_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_http_transactions_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_http_transactions_unified_target ON public.http_transactions USING btree (target_id);


--
-- Name: idx_hunt_actions_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_actions_run ON public.hunt_actions USING btree (hunt_run_id, started_at);


--
-- Name: idx_hunt_cancellable_jobs_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_cancellable_jobs_pending ON public.hunt_cancellable_jobs USING btree (hunt_id, signal_state) WHERE (signal_state <> 'terminal'::text);


--
-- Name: idx_hunt_coverage_angle_events_fingerprint_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_coverage_angle_events_fingerprint_seq ON public.hunt_coverage_angle_events USING btree (hunt_run_id, fingerprint, event_seq DESC);


--
-- Name: idx_hunt_coverage_angle_events_run_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_coverage_angle_events_run_seq ON public.hunt_coverage_angle_events USING btree (hunt_run_id, event_seq DESC);


--
-- Name: idx_hunt_credential_uses_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_credential_uses_run ON public.hunt_credential_uses USING btree (hunt_run_id, used_at, id);


--
-- Name: idx_hunt_permission_events_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_permission_events_run ON public.hunt_permission_events USING btree (hunt_run_id, created_at, id);


--
-- Name: idx_hunt_permission_grants_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_permission_grants_live ON public.hunt_permission_grants USING btree (hunt_run_id, kind) WHERE (revoked_at IS NULL);


--
-- Name: idx_hunt_permission_requests_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_permission_requests_run ON public.hunt_permission_requests USING btree (hunt_run_id, created_at, id);


--
-- Name: idx_hunt_preauthorizations_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_preauthorizations_run ON public.hunt_preauthorizations USING btree (hunt_run_id, created_at);


--
-- Name: idx_hunt_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_runs_created ON public.hunt_runs USING btree (created_at DESC);


--
-- Name: idx_hunt_runs_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_runs_device ON public.hunt_runs USING btree (device_target_id, created_at DESC) WHERE (device_target_id IS NOT NULL);


--
-- Name: idx_hunt_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_runs_status ON public.hunt_runs USING btree (status, updated_at DESC);


--
-- Name: idx_hunt_runs_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_runs_unified_target ON public.hunt_runs USING btree (target_id);


--
-- Name: idx_hunt_runs_web; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_runs_web ON public.hunt_runs USING btree (target_id, created_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_hunt_skill_events_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hunt_skill_events_run ON public.hunt_skill_events USING btree (hunt_run_id, created_at, id);


--
-- Name: idx_hypotheses_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hypotheses_claim ON public.hypotheses USING btree (status, claim_lease_expires_at, updated_at DESC);


--
-- Name: idx_hypotheses_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_hypotheses_dedupe ON public.hypotheses USING btree (COALESCE(target_id, '00000000-0000-0000-0000-000000000000'::uuid), family, dedupe_key);


--
-- Name: idx_hypotheses_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hypotheses_target_status ON public.hypotheses USING btree (target_id, status, updated_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_investigation_candidate_observations_candidate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidate_observations_candidate ON public.investigation_candidate_observations USING btree (candidate_id, observed_at DESC);


--
-- Name: idx_investigation_candidate_observations_device_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidate_observations_device_run ON public.investigation_candidate_observations USING btree (device_agent_run_id, observed_at DESC) WHERE (device_agent_run_id IS NOT NULL);


--
-- Name: idx_investigation_candidate_observations_hunt_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidate_observations_hunt_run ON public.investigation_candidate_observations USING btree (hunt_run_id, candidate_id) WHERE (hunt_run_id IS NOT NULL);


--
-- Name: idx_investigation_candidate_observations_web_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidate_observations_web_run ON public.investigation_candidate_observations USING btree (agent_hunt_run_id, observed_at DESC) WHERE (agent_hunt_run_id IS NOT NULL);


--
-- Name: idx_investigation_candidates_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidates_device ON public.investigation_candidates USING btree (device_target_id, status, last_seen_at DESC) WHERE (device_target_id IS NOT NULL);


--
-- Name: idx_investigation_candidates_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidates_run ON public.investigation_candidates USING btree (device_agent_run_id, created_at) WHERE (device_agent_run_id IS NOT NULL);


--
-- Name: idx_investigation_candidates_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidates_unified_target ON public.investigation_candidates USING btree (target_id);


--
-- Name: idx_investigation_candidates_web; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investigation_candidates_web ON public.investigation_candidates USING btree (target_id, status, last_seen_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_model_intake_admission_events_admission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_admission_events_admission ON public.model_intake_admission_events USING btree (admission_id, created_at DESC);


--
-- Name: idx_model_intake_admissions_idempotency; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_model_intake_admissions_idempotency ON public.model_intake_admissions USING btree (idempotency_key_sha256) WHERE (idempotency_key_sha256 IS NOT NULL);


--
-- Name: idx_model_intake_admissions_reassessment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_admissions_reassessment ON public.model_intake_admissions USING btree (status, reassessment_due_at);


--
-- Name: idx_model_intake_admissions_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_admissions_subject ON public.model_intake_admissions USING btree (artifact_sha256, status, expires_at);


--
-- Name: idx_model_intake_agent_actions_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_agent_actions_session ON public.model_intake_agent_actions USING btree (session_id, created_at);


--
-- Name: idx_model_intake_agent_sessions_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_agent_sessions_submission ON public.model_intake_agent_sessions USING btree (submission_id, created_at DESC);


--
-- Name: idx_model_intake_automatic_reviews_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_automatic_reviews_state ON public.model_intake_automatic_reviews USING btree (state, updated_at);


--
-- Name: idx_model_intake_evidence_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_evidence_submission ON public.model_intake_evidence_records USING btree (submission_id, evidence_type, created_at DESC);


--
-- Name: idx_model_intake_runner_jobs_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_runner_jobs_submission ON public.model_intake_runner_jobs USING btree (submission_id, created_at DESC);


--
-- Name: idx_model_intake_submission_events_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_submission_events_submission ON public.model_intake_submission_events USING btree (submission_id, created_at DESC);


--
-- Name: idx_model_intake_submissions_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_submissions_state ON public.model_intake_submissions USING btree (state, created_at DESC);


--
-- Name: idx_model_intake_trust_anchors_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_trust_anchors_active ON public.model_intake_trust_anchors USING btree (is_active, purpose, environment, policy_profile);


--
-- Name: idx_model_intake_trust_anchors_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_intake_trust_anchors_scope ON public.model_intake_trust_anchors USING btree (is_active, purpose, environment, policy_profile);


--
-- Name: idx_node_credentials_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_credentials_active ON public.node_credentials USING btree (node_id, credential_version DESC) WHERE (revoked_at IS NULL);


--
-- Name: idx_node_credentials_node_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_node_credentials_node_version ON public.node_credentials USING btree (node_id, credential_version);


--
-- Name: idx_node_join_tokens_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_join_tokens_expires ON public.node_join_tokens USING btree (expires_at) WHERE (consumed_at IS NULL);


--
-- Name: idx_node_join_tokens_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_node_join_tokens_token_id ON public.node_join_tokens USING btree (token_id);


--
-- Name: idx_nodes_status_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nodes_status_heartbeat ON public.nodes USING btree (status, last_heartbeat_at DESC);


--
-- Name: idx_nodes_wireguard_public_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_nodes_wireguard_public_key ON public.nodes USING btree (wireguard_public_key) WHERE (wireguard_public_key IS NOT NULL);


--
-- Name: idx_operation_plans_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operation_plans_created_at ON public.operation_plans USING btree (created_at DESC);


--
-- Name: idx_operation_plans_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operation_plans_scope ON public.operation_plans USING btree (scope_receipt_id, created_at DESC) WHERE (scope_receipt_id IS NOT NULL);


--
-- Name: idx_public_api_idempotency_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_public_api_idempotency_updated ON public.public_api_idempotency USING btree (updated_at);


--
-- Name: idx_refuter_reviews_finding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refuter_reviews_finding ON public.refuter_reviews USING btree (finding_id, created_at DESC) WHERE (finding_id IS NOT NULL);


--
-- Name: idx_refuter_reviews_hypothesis; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refuter_reviews_hypothesis ON public.refuter_reviews USING btree (hypothesis_id, created_at DESC) WHERE (hypothesis_id IS NOT NULL);


--
-- Name: idx_refuter_reviews_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refuter_reviews_subject ON public.refuter_reviews USING btree (subject_type, subject_id, created_at DESC);


--
-- Name: idx_request_collection_bindings_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collection_bindings_target ON public.request_collection_bindings USING btree (target_kind, target_id, is_active);


--
-- Name: idx_request_collection_environments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collection_environments_active ON public.request_collection_environments USING btree (collection_id, is_active, lower(name));


--
-- Name: idx_request_collection_requests_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collection_requests_page ON public.request_collection_requests USING btree (collection_id, ordinal);


--
-- Name: idx_request_collection_selections_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collection_selections_active ON public.request_collection_selections USING btree (collection_id, binding_id, is_active, lower(name));


--
-- Name: idx_request_collection_selections_current_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_request_collection_selections_current_name ON public.request_collection_selections USING btree (binding_id, lower(name)) WHERE ((is_active = true) AND (revoked_at IS NULL));


--
-- Name: idx_request_collections_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collections_device ON public.request_collections USING btree (device_target_id, updated_at DESC) WHERE ((device_target_id IS NOT NULL) AND (is_active = true));


--
-- Name: idx_request_collections_target_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_request_collections_target_name ON public.request_collections USING btree (COALESCE(target_id, '00000000-0000-0000-0000-000000000000'::uuid), COALESCE(device_target_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: idx_request_collections_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collections_unified_target ON public.request_collections USING btree (target_id);


--
-- Name: idx_request_collections_web; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_request_collections_web ON public.request_collections USING btree (target_id, updated_at DESC) WHERE ((target_id IS NOT NULL) AND (is_active = true));


--
-- Name: idx_research_decisions_episode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_decisions_episode ON public.research_decisions USING btree (episode_id, sequence DESC);


--
-- Name: idx_research_episodes_active_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_research_episodes_active_campaign ON public.research_episodes USING btree (campaign_id) WHERE ((campaign_id IS NOT NULL) AND ((planner ->> 'campaign_autopilot'::text) = 'true'::text) AND (status <> ALL (ARRAY['completed'::text, 'cancelled'::text, 'failed'::text, 'budget_exhausted'::text, 'blocked'::text])));


--
-- Name: idx_research_episodes_active_launch; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_research_episodes_active_launch ON public.research_episodes USING btree (target_id, ((planner #>> '{mission,profile}'::text[])), ((planner #>> '{mission,subject,type}'::text[])), ((planner #>> '{mission,subject,id}'::text[])), execution_mode, ((planner ->> 'launch_intensity'::text))) WHERE (((planner ->> 'dedupe_launch'::text) = 'true'::text) AND (status <> ALL (ARRAY['completed'::text, 'cancelled'::text, 'failed'::text, 'budget_exhausted'::text, 'blocked'::text])));


--
-- Name: idx_research_episodes_autopilot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_episodes_autopilot ON public.research_episodes USING btree (updated_at) WHERE ((autopilot_enabled = true) AND (status = 'awaiting_planner'::text));


--
-- Name: idx_research_episodes_autopilot_work; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_episodes_autopilot_work ON public.research_episodes USING btree (updated_at) WHERE ((autopilot_enabled = true) AND (status = ANY (ARRAY['awaiting_planner'::text, 'awaiting_observation'::text])));


--
-- Name: idx_research_episodes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_episodes_status ON public.research_episodes USING btree (status, updated_at DESC);


--
-- Name: idx_research_episodes_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_episodes_target ON public.research_episodes USING btree (target_id, created_at DESC);


--
-- Name: idx_research_events_episode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_events_episode ON public.research_events USING btree (episode_id, sequence);


--
-- Name: idx_research_observations_episode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_research_observations_episode ON public.research_observations USING btree (episode_id, sequence DESC);


--
-- Name: idx_scan_action_attempt_checkpoints_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_action_attempt_checkpoints_action ON public.scan_action_attempt_checkpoints USING btree (scan_id, action_id, created_at);


--
-- Name: idx_scan_artifacts_retention; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_artifacts_retention ON public.scan_artifacts USING btree (expires_at) WHERE ((status = 'available'::text) AND (expires_at IS NOT NULL));


--
-- Name: idx_scan_artifacts_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_artifacts_scan ON public.scan_artifacts USING btree (scan_id, created_at DESC);


--
-- Name: idx_scan_campaigns_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_campaigns_parent ON public.scan_campaigns USING btree (parent_scan_id) WHERE (parent_scan_id IS NOT NULL);


--
-- Name: idx_scan_campaigns_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_campaigns_target_status ON public.scan_campaigns USING btree (target_id, status, created_at DESC);


--
-- Name: idx_scan_capability_actions_lease_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_capability_actions_lease_expiry ON public.scan_capability_actions USING btree (lease_expires_at) WHERE (status = ANY (ARRAY['leased'::text, 'running'::text]));


--
-- Name: idx_scan_capability_actions_reservation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_capability_actions_reservation ON public.scan_capability_actions USING btree (reservation_id) WHERE (reservation_id IS NOT NULL);


--
-- Name: idx_scan_capability_actions_scan_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_capability_actions_scan_status ON public.scan_capability_actions USING btree (scan_id, status, ordinal);


--
-- Name: idx_scan_observation_manifests_scan_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_observation_manifests_scan_action ON public.scan_observation_manifests USING btree (scan_id, action_id, created_at DESC);


--
-- Name: idx_scan_stage_checkpoints_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_stage_checkpoints_scan ON public.scan_stage_checkpoints USING btree (scan_id, updated_at DESC);


--
-- Name: idx_scan_work_manifests_scan_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_work_manifests_scan_kind ON public.scan_work_manifests USING btree (scan_id, kind, created_at DESC);


--
-- Name: idx_scans_ai_target_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_ai_target_created ON public.scans USING btree (ai_target_id, created_at DESC) WHERE (ai_target_id IS NOT NULL);


--
-- Name: idx_scans_ai_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_ai_target_id ON public.scans USING btree (ai_target_id) WHERE (ai_target_id IS NOT NULL);


--
-- Name: idx_scans_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_created ON public.scans USING btree (created_at DESC);


--
-- Name: idx_scans_device_target_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_device_target_created ON public.scans USING btree (device_target_id, created_at DESC) WHERE (device_target_id IS NOT NULL);


--
-- Name: idx_scans_executing_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_executing_node ON public.scans USING btree (executing_node_id, created_at DESC) WHERE (executing_node_id IS NOT NULL);


--
-- Name: idx_scans_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_job_id ON public.scans USING btree (job_id);


--
-- Name: idx_scans_one_active_device_traffic; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_scans_one_active_device_traffic ON public.scans USING btree (device_target_id) WHERE ((device_target_id IS NOT NULL) AND (run_kind = ANY (ARRAY['device_posture'::text, 'device_probe'::text])) AND (status = ANY (ARRAY['pending'::text, 'queued'::text, 'running'::text, 'cancelling'::text])));


--
-- Name: idx_scans_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_parent ON public.scans USING btree (parent_scan_id) WHERE (parent_scan_id IS NOT NULL);


--
-- Name: idx_scans_run_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_run_kind ON public.scans USING btree (run_kind);


--
-- Name: idx_scans_run_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_run_kind_created ON public.scans USING btree (run_kind, created_at DESC);


--
-- Name: idx_scans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_status ON public.scans USING btree (status);


--
-- Name: idx_scans_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_target_id ON public.scans USING btree (target_id);


--
-- Name: idx_scans_unified_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_unified_target ON public.scans USING btree (target_id);


--
-- Name: idx_schedules_kind_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_schedules_kind_next_run ON public.schedules USING btree (schedule_kind, next_run_at) WHERE (is_active = true);


--
-- Name: idx_schedules_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_schedules_next_run ON public.schedules USING btree (next_run_at) WHERE (is_active = true);


--
-- Name: idx_scope_receipts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_receipts_created_at ON public.scope_receipts USING btree (created_at DESC);


--
-- Name: idx_scope_receipts_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_receipts_target ON public.scope_receipts USING btree (target_id, created_at DESC) WHERE (target_id IS NOT NULL);


--
-- Name: idx_target_credential_profiles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_credential_profiles_active ON public.target_credential_profiles USING btree (target_id, is_active, expires_at);


--
-- Name: idx_target_credential_profiles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_target_credential_profiles_name ON public.target_credential_profiles USING btree (target_id, lower(name));


--
-- Name: idx_target_endpoint_expectations_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_target_endpoint_expectations_identity ON public.target_endpoint_expectations USING btree (target_id, method, path, param_shape, param_location, COALESCE(principal_id, '00000000-0000-0000-0000-000000000000'::uuid), COALESCE(principal_role, ''::text), COALESCE(tenant_id, ''::text));


--
-- Name: idx_target_endpoint_expectations_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoint_expectations_target ON public.target_endpoint_expectations USING btree (target_id, path, expected_access);


--
-- Name: idx_target_endpoints_auth_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoints_auth_status ON public.target_endpoints USING btree (target_id, auth_state, test_status, priority_score DESC);


--
-- Name: idx_target_endpoints_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoints_campaign ON public.target_endpoints USING btree (campaign_id) WHERE (campaign_id IS NOT NULL);


--
-- Name: idx_target_endpoints_fp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_target_endpoints_fp ON public.target_endpoints USING btree (target_id, fingerprint);


--
-- Name: idx_target_endpoints_lease; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoints_lease ON public.target_endpoints USING btree (lease_expires_at) WHERE (test_status = 'in_progress'::text);


--
-- Name: idx_target_endpoints_seen_scan_auth; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoints_seen_scan_auth ON public.target_endpoints USING btree (target_id, last_seen_scan_id, auth_state) WHERE (last_seen_scan_id IS NOT NULL);


--
-- Name: idx_target_endpoints_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_endpoints_status ON public.target_endpoints USING btree (target_id, test_status, priority_score DESC);


--
-- Name: idx_target_invariant_contracts_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_invariant_contracts_target_status ON public.target_invariant_contracts USING btree (target_id, status, updated_at DESC);


--
-- Name: idx_target_principals_active_auth_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_target_principals_active_auth_slot ON public.target_principals USING btree (target_id, auth_state) WHERE ((is_active = true) AND (auth_state = ANY (ARRAY['user1'::text, 'user2'::text])));


--
-- Name: idx_target_principals_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_target_principals_identity ON public.target_principals USING btree (target_id, lower(label), COALESCE(tenant_id, ''::text), COALESCE(auth_state, ''::text));


--
-- Name: idx_target_principals_target_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_target_principals_target_active ON public.target_principals USING btree (target_id, is_active, role);


--
-- Name: idx_targets_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_targets_active ON public.targets USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_targets_asm_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_targets_asm_enabled ON public.targets USING btree (asm_enabled) WHERE (asm_enabled = true);


--
-- Name: idx_targets_asset_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_targets_asset_owner ON public.targets USING btree (asset_owner_id);


--
-- Name: idx_targets_canonical_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_targets_canonical_key ON public.targets USING btree (canonical_key);


--
-- Name: idx_targets_is_root; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_targets_is_root ON public.targets USING btree (is_root) WHERE (is_root = true);


--
-- Name: idx_targets_root_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_targets_root_domain ON public.targets USING btree (root_domain);


--
-- Name: idx_tool_receipts_hunt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tool_receipts_hunt ON public.tool_receipts USING btree (hunt_id, created_at DESC) WHERE (hunt_id IS NOT NULL);


--
-- Name: idx_tool_receipts_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tool_receipts_scope ON public.tool_receipts USING btree (scope_receipt_id) WHERE (scope_receipt_id IS NOT NULL);


--
-- Name: idx_tool_receipts_tool_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tool_receipts_tool_created ON public.tool_receipts USING btree (tool_name, created_at DESC);


--
-- Name: uq_hunt_permission_requests_pending_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_hunt_permission_requests_pending_subject ON public.hunt_permission_requests USING btree (hunt_run_id, subject_digest) WHERE (status = 'pending'::text);


--
-- Name: device_services device_service_asset_origin; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER device_service_asset_origin AFTER INSERT OR UPDATE OF web_origin ON public.device_services FOR EACH ROW EXECUTE FUNCTION public.link_device_service_origin();


--
-- Name: device_targets device_target_compatibility_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER device_target_compatibility_write INSTEAD OF INSERT OR DELETE OR UPDATE ON public.device_targets FOR EACH ROW EXECUTE FUNCTION public.write_device_target_view();


--
-- Name: hunt_permission_baselines hunt_permission_baselines_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hunt_permission_baselines_immutable BEFORE DELETE OR UPDATE ON public.hunt_permission_baselines FOR EACH ROW EXECUTE FUNCTION public.hunt_permission_baselines_immutable();


--
-- Name: hunt_permission_events hunt_permission_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hunt_permission_events_append_only BEFORE DELETE OR UPDATE ON public.hunt_permission_events FOR EACH ROW EXECUTE FUNCTION public.hunt_permission_events_append_only();


--
-- Name: targets target_asset_membership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER target_asset_membership AFTER INSERT OR UPDATE OF url ON public.targets FOR EACH ROW EXECUTE FUNCTION public.attach_target_asset_owner();


--
-- Name: targets target_asset_retirement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER target_asset_retirement AFTER UPDATE OF is_active ON public.targets FOR EACH ROW EXECUTE FUNCTION public.retire_asset_members();


--
-- Name: findings trg_bind_finding_observation_scans; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_bind_finding_observation_scans BEFORE INSERT OR UPDATE OF scan_id ON public.findings FOR EACH ROW EXECUTE FUNCTION public.bind_finding_observation_scans();


--
-- Name: findings trg_refresh_device_active_findings_count; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refresh_device_active_findings_count AFTER INSERT OR DELETE OR UPDATE OF status, device_target_id ON public.findings FOR EACH ROW EXECUTE FUNCTION public.refresh_device_active_findings_count();


--
-- Name: targets trg_targets_canonical_key; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_targets_canonical_key BEFORE INSERT OR UPDATE OF url, discovery_source, is_active ON public.targets FOR EACH ROW EXECUTE FUNCTION public.targets_set_canonical_key();


--
-- Name: findings trigger_update_finding_timestamps; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_finding_timestamps BEFORE UPDATE ON public.findings FOR EACH ROW EXECUTE FUNCTION public.update_finding_timestamps();


--
-- Name: scans trigger_update_target_stats; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_target_stats AFTER UPDATE ON public.scans FOR EACH ROW WHEN (((new.status = 'completed'::text) AND (old.status <> 'completed'::text))) EXECUTE FUNCTION public.update_target_stats();


--
-- Name: application_graph_nodes unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.application_graph_nodes FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_agent_actions unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_agent_actions FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_agent_runs unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_agent_runs FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_credential_attempts unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_credential_attempts FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_interfaces unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_interfaces FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_locator_history unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_locator_history FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: device_services unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.device_services FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: evidence_instances unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.evidence_instances FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: finding_verifications unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.finding_verifications FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: findings unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.findings FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: http_transactions unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.http_transactions FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: hunt_runs unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.hunt_runs FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: investigation_candidates unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.investigation_candidates FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: request_collections unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.request_collections FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: scans unified_target_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unified_target_reference BEFORE INSERT OR UPDATE OF target_id, device_target_id ON public.scans FOR EACH ROW EXECUTE FUNCTION public.enforce_device_target_alias();


--
-- Name: agent_context_packs agent_context_packs_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_context_packs
    ADD CONSTRAINT agent_context_packs_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: agent_decision_traces agent_decision_traces_context_pack_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_decision_traces
    ADD CONSTRAINT agent_decision_traces_context_pack_id_fkey FOREIGN KEY (context_pack_id) REFERENCES public.agent_context_packs(id) ON DELETE SET NULL;


--
-- Name: agent_decision_traces agent_decision_traces_operation_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_decision_traces
    ADD CONSTRAINT agent_decision_traces_operation_plan_id_fkey FOREIGN KEY (operation_plan_id) REFERENCES public.operation_plans(id) ON DELETE SET NULL;


--
-- Name: agent_hunt_runs agent_hunt_runs_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_hunt_runs
    ADD CONSTRAINT agent_hunt_runs_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.research_episodes(id) ON DELETE SET NULL;


--
-- Name: agent_hunt_runs agent_hunt_runs_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_hunt_runs
    ADD CONSTRAINT agent_hunt_runs_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: ai_surface_attempts ai_surface_attempts_surface_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surface_attempts
    ADD CONSTRAINT ai_surface_attempts_surface_id_fkey FOREIGN KEY (surface_id) REFERENCES public.ai_surfaces(id) ON DELETE CASCADE;


--
-- Name: ai_surfaces ai_surfaces_ai_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_surfaces
    ADD CONSTRAINT ai_surfaces_ai_target_id_fkey FOREIGN KEY (ai_target_id) REFERENCES public.ai_targets(id) ON DELETE CASCADE;


--
-- Name: ai_target_credentials ai_target_credentials_ai_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_credentials
    ADD CONSTRAINT ai_target_credentials_ai_target_id_fkey FOREIGN KEY (ai_target_id) REFERENCES public.ai_targets(id) ON DELETE CASCADE;


--
-- Name: ai_target_principals ai_target_principals_ai_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_target_principals
    ADD CONSTRAINT ai_target_principals_ai_target_id_fkey FOREIGN KEY (ai_target_id) REFERENCES public.ai_targets(id) ON DELETE CASCADE;


--
-- Name: ai_targets ai_targets_last_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_targets
    ADD CONSTRAINT ai_targets_last_scan_id_fkey FOREIGN KEY (last_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: application_graph_edges application_graph_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_edges
    ADD CONSTRAINT application_graph_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: application_graph_nodes application_graph_nodes_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_nodes
    ADD CONSTRAINT application_graph_nodes_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: application_graph_nodes application_graph_nodes_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_graph_nodes
    ADD CONSTRAINT application_graph_nodes_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: approval_receipts approval_receipts_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_receipts
    ADD CONSTRAINT approval_receipts_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: asm_endpoint_attempts asm_endpoint_attempts_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asm_endpoint_attempts
    ADD CONSTRAINT asm_endpoint_attempts_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: asm_endpoint_attempts asm_endpoint_attempts_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asm_endpoint_attempts
    ADD CONSTRAINT asm_endpoint_attempts_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.target_endpoints(id) ON DELETE CASCADE;


--
-- Name: asm_endpoint_attempts asm_endpoint_attempts_parent_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asm_endpoint_attempts
    ADD CONSTRAINT asm_endpoint_attempts_parent_scan_id_fkey FOREIGN KEY (parent_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: asm_endpoint_attempts asm_endpoint_attempts_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asm_endpoint_attempts
    ADD CONSTRAINT asm_endpoint_attempts_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: auth_sessions auth_sessions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.credential_profiles(id) ON DELETE CASCADE;


--
-- Name: authenticated_profile_revisions authenticated_profile_revisio_profile_id_credential_versio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticated_profile_revisions
    ADD CONSTRAINT authenticated_profile_revisio_profile_id_credential_versio_fkey FOREIGN KEY (profile_id, credential_version) REFERENCES public.credential_profile_versions(profile_id, version);


--
-- Name: authenticated_profile_revisions authenticated_profile_revisions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticated_profile_revisions
    ADD CONSTRAINT authenticated_profile_revisions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.credential_profiles(id);


--
-- Name: authentication_validation_requests authentication_validation_requests_profile_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validation_requests
    ADD CONSTRAINT authentication_validation_requests_profile_id_revision_fkey FOREIGN KEY (profile_id, revision) REFERENCES public.authenticated_profile_revisions(profile_id, revision);


--
-- Name: authentication_validation_requests authentication_validation_requests_reservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validation_requests
    ADD CONSTRAINT authentication_validation_requests_reservation_id_fkey FOREIGN KEY (reservation_id) REFERENCES public.budget_reservations(id);


--
-- Name: authentication_validation_requests authentication_validation_requests_validation_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validation_requests
    ADD CONSTRAINT authentication_validation_requests_validation_record_id_fkey FOREIGN KEY (validation_record_id) REFERENCES public.authentication_validations(id);


--
-- Name: authentication_validations authentication_validations_profile_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_validations
    ADD CONSTRAINT authentication_validations_profile_id_revision_fkey FOREIGN KEY (profile_id, revision) REFERENCES public.authenticated_profile_revisions(profile_id, revision);


--
-- Name: broker_job_leases broker_job_leases_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_leases
    ADD CONSTRAINT broker_job_leases_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: broker_job_results broker_job_results_lease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_job_results
    ADD CONSTRAINT broker_job_results_lease_id_fkey FOREIGN KEY (lease_id) REFERENCES public.broker_job_leases(id) ON DELETE CASCADE;


--
-- Name: campaign_actions campaign_actions_approval_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_approval_receipt_id_fkey FOREIGN KEY (approval_receipt_id) REFERENCES public.approval_receipts(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_command_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_command_result_id_fkey FOREIGN KEY (command_result_id) REFERENCES public.command_results(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_mission_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_mission_campaign_id_fkey FOREIGN KEY (mission_campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_operation_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_operation_plan_id_fkey FOREIGN KEY (operation_plan_id) REFERENCES public.operation_plans(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: campaign_actions campaign_actions_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_actions
    ADD CONSTRAINT campaign_actions_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_operation_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_operation_plan_id_fkey FOREIGN KEY (operation_plan_id) REFERENCES public.operation_plans(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: command_results command_results_approval_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_approval_receipt_id_fkey FOREIGN KEY (approval_receipt_id) REFERENCES public.approval_receipts(id) ON DELETE SET NULL;


--
-- Name: command_results command_results_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: command_results command_results_operation_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_operation_plan_id_fkey FOREIGN KEY (operation_plan_id) REFERENCES public.operation_plans(id) ON DELETE SET NULL;


--
-- Name: command_results command_results_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: command_results command_results_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_results
    ADD CONSTRAINT command_results_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: credential_profile_bindings credential_profile_bindings_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profile_bindings
    ADD CONSTRAINT credential_profile_bindings_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.credential_profiles(id) ON DELETE CASCADE;


--
-- Name: credential_profile_versions credential_profile_versions_profile_auth_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_profile_versions
    ADD CONSTRAINT credential_profile_versions_profile_auth_fk FOREIGN KEY (profile_id, auth_kind) REFERENCES public.credential_profiles(id, auth_kind) ON DELETE CASCADE;


--
-- Name: device_agent_actions device_agent_actions_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_actions
    ADD CONSTRAINT device_agent_actions_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_agent_actions device_agent_actions_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_actions
    ADD CONSTRAINT device_agent_actions_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.device_agent_runs(id) ON DELETE CASCADE;


--
-- Name: device_agent_actions device_agent_actions_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_actions
    ADD CONSTRAINT device_agent_actions_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_agent_runs device_agent_runs_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_runs
    ADD CONSTRAINT device_agent_runs_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_agent_runs device_agent_runs_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_agent_runs
    ADD CONSTRAINT device_agent_runs_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_credential_attempts device_credential_attempts_credential_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_credential_profile_id_fkey FOREIGN KEY (credential_profile_id) REFERENCES public.credential_profiles(id) ON DELETE CASCADE;


--
-- Name: device_credential_attempts device_credential_attempts_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_credential_attempts device_credential_attempts_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: device_credential_attempts device_credential_attempts_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_credential_attempts
    ADD CONSTRAINT device_credential_attempts_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_interfaces device_interfaces_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_interfaces
    ADD CONSTRAINT device_interfaces_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_interfaces device_interfaces_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_interfaces
    ADD CONSTRAINT device_interfaces_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_locator_history device_locator_history_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_locator_history
    ADD CONSTRAINT device_locator_history_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_locator_history device_locator_history_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_locator_history
    ADD CONSTRAINT device_locator_history_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_services device_services_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: device_services device_services_interface_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_interface_id_fkey FOREIGN KEY (interface_id) REFERENCES public.device_interfaces(id) ON DELETE SET NULL;


--
-- Name: device_services device_services_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: device_services device_services_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_services
    ADD CONSTRAINT device_services_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: evidence_instances evidence_instances_campaign_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_campaign_action_id_fkey FOREIGN KEY (campaign_action_id) REFERENCES public.campaign_actions(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.investigation_candidates(id) ON DELETE CASCADE;


--
-- Name: evidence_instances evidence_instances_device_agent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_device_agent_run_id_fkey FOREIGN KEY (device_agent_run_id) REFERENCES public.device_agent_runs(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_evidence_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_evidence_object_id_fkey FOREIGN KEY (evidence_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE CASCADE;


--
-- Name: evidence_instances evidence_instances_research_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_research_episode_id_fkey FOREIGN KEY (research_episode_id) REFERENCES public.research_episodes(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: evidence_instances evidence_instances_tool_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_instances
    ADD CONSTRAINT evidence_instances_tool_receipt_id_fkey FOREIGN KEY (tool_receipt_id) REFERENCES public.tool_receipts(id) ON DELETE SET NULL;


--
-- Name: evidence_objects evidence_objects_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_objects
    ADD CONSTRAINT evidence_objects_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE CASCADE;


--
-- Name: evidence_objects evidence_objects_retention_delete_preview_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_objects
    ADD CONSTRAINT evidence_objects_retention_delete_preview_fk FOREIGN KEY (retention_delete_preview_id) REFERENCES public.evidence_retention_previews(id) ON DELETE RESTRICT;


--
-- Name: evidence_retention_previews evidence_retention_previews_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_retention_previews
    ADD CONSTRAINT evidence_retention_previews_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: export_events export_events_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_events
    ADD CONSTRAINT export_events_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE SET NULL;


--
-- Name: export_events export_events_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_events
    ADD CONSTRAINT export_events_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: finding_exceptions finding_exceptions_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_exceptions
    ADD CONSTRAINT finding_exceptions_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy_profiles(id) ON DELETE SET NULL;


--
-- Name: finding_hunt_verifications finding_hunt_verifications_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_hunt_verifications
    ADD CONSTRAINT finding_hunt_verifications_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.hunt_actions(id) ON DELETE CASCADE;


--
-- Name: finding_hunt_verifications finding_hunt_verifications_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_hunt_verifications
    ADD CONSTRAINT finding_hunt_verifications_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE CASCADE;


--
-- Name: finding_hunt_verifications finding_hunt_verifications_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_hunt_verifications
    ADD CONSTRAINT finding_hunt_verifications_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: finding_verifications finding_verifications_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: finding_verifications finding_verifications_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.investigation_candidates(id) ON DELETE CASCADE;


--
-- Name: finding_verifications finding_verifications_device_agent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_device_agent_run_id_fkey FOREIGN KEY (device_agent_run_id) REFERENCES public.device_agent_runs(id) ON DELETE SET NULL;


--
-- Name: finding_verifications finding_verifications_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: finding_verifications finding_verifications_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE CASCADE;


--
-- Name: finding_verifications finding_verifications_research_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_research_episode_id_fkey FOREIGN KEY (research_episode_id) REFERENCES public.research_episodes(id) ON DELETE SET NULL;


--
-- Name: finding_verifications finding_verifications_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: finding_verifications finding_verifications_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finding_verifications
    ADD CONSTRAINT finding_verifications_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: findings findings_ai_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_ai_target_id_fkey FOREIGN KEY (ai_target_id) REFERENCES public.ai_targets(id) ON DELETE CASCADE;


--
-- Name: findings findings_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: findings findings_first_seen_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_first_seen_scan_id_fkey FOREIGN KEY (first_seen_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: findings findings_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE SET NULL;


--
-- Name: findings findings_last_seen_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_last_seen_scan_id_fkey FOREIGN KEY (last_seen_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: findings findings_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: findings findings_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: fleet_node_events fleet_node_events_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_node_events
    ADD CONSTRAINT fleet_node_events_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: http_transactions http_transactions_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: http_transactions http_transactions_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: http_transactions http_transactions_request_body_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_request_body_object_id_fkey FOREIGN KEY (request_body_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: http_transactions http_transactions_request_headers_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_request_headers_object_id_fkey FOREIGN KEY (request_headers_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: http_transactions http_transactions_response_body_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_response_body_object_id_fkey FOREIGN KEY (response_body_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: http_transactions http_transactions_response_headers_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_response_headers_object_id_fkey FOREIGN KEY (response_headers_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: http_transactions http_transactions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: http_transactions http_transactions_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_transactions
    ADD CONSTRAINT http_transactions_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: hunt_actions hunt_actions_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_actions
    ADD CONSTRAINT hunt_actions_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_budget_amendments hunt_budget_amendments_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_budget_amendments
    ADD CONSTRAINT hunt_budget_amendments_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_cancellable_jobs hunt_cancellable_jobs_hunt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_cancellable_jobs
    ADD CONSTRAINT hunt_cancellable_jobs_hunt_id_fkey FOREIGN KEY (hunt_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_coverage_angle_events hunt_coverage_angle_events_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_coverage_angle_events
    ADD CONSTRAINT hunt_coverage_angle_events_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_credential_uses hunt_credential_uses_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_credential_uses
    ADD CONSTRAINT hunt_credential_uses_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.hunt_actions(id) ON DELETE CASCADE;


--
-- Name: hunt_credential_uses hunt_credential_uses_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_credential_uses
    ADD CONSTRAINT hunt_credential_uses_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_permission_baselines hunt_permission_baselines_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_baselines
    ADD CONSTRAINT hunt_permission_baselines_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_permission_events hunt_permission_events_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_events
    ADD CONSTRAINT hunt_permission_events_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_permission_grants hunt_permission_grants_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_grants
    ADD CONSTRAINT hunt_permission_grants_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_permission_grants hunt_permission_grants_preauthorization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_grants
    ADD CONSTRAINT hunt_permission_grants_preauthorization_id_fkey FOREIGN KEY (preauthorization_id) REFERENCES public.hunt_preauthorizations(id) ON DELETE SET NULL;


--
-- Name: hunt_permission_grants hunt_permission_grants_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_grants
    ADD CONSTRAINT hunt_permission_grants_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.hunt_permission_requests(id) ON DELETE CASCADE;


--
-- Name: hunt_permission_requests hunt_permission_requests_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_permission_requests
    ADD CONSTRAINT hunt_permission_requests_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_preauthorizations hunt_preauthorizations_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_preauthorizations
    ADD CONSTRAINT hunt_preauthorizations_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hunt_runs hunt_runs_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_runs
    ADD CONSTRAINT hunt_runs_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: hunt_runs hunt_runs_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_runs
    ADD CONSTRAINT hunt_runs_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: hunt_skill_events hunt_skill_events_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_skill_events
    ADD CONSTRAINT hunt_skill_events_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.hunt_actions(id) ON DELETE SET NULL;


--
-- Name: hunt_skill_events hunt_skill_events_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hunt_skill_events
    ADD CONSTRAINT hunt_skill_events_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE CASCADE;


--
-- Name: hypotheses hypotheses_campaign_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hypotheses
    ADD CONSTRAINT hypotheses_campaign_action_id_fkey FOREIGN KEY (campaign_action_id) REFERENCES public.campaign_actions(id) ON DELETE SET NULL;


--
-- Name: hypotheses hypotheses_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hypotheses
    ADD CONSTRAINT hypotheses_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: hypotheses hypotheses_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hypotheses
    ADD CONSTRAINT hypotheses_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: investigation_candidate_observations investigation_candidate_observations_agent_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_agent_hunt_run_id_fkey FOREIGN KEY (agent_hunt_run_id) REFERENCES public.agent_hunt_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidate_observations investigation_candidate_observations_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.investigation_candidates(id) ON DELETE CASCADE;


--
-- Name: investigation_candidate_observations investigation_candidate_observations_device_agent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_device_agent_run_id_fkey FOREIGN KEY (device_agent_run_id) REFERENCES public.device_agent_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidate_observations investigation_candidate_observations_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidate_observations investigation_candidate_observations_research_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidate_observations
    ADD CONSTRAINT investigation_candidate_observations_research_episode_id_fkey FOREIGN KEY (research_episode_id) REFERENCES public.research_episodes(id) ON DELETE SET NULL;


--
-- Name: investigation_candidates investigation_candidates_agent_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_agent_hunt_run_id_fkey FOREIGN KEY (agent_hunt_run_id) REFERENCES public.agent_hunt_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidates investigation_candidates_device_agent_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_device_agent_run_id_fkey FOREIGN KEY (device_agent_run_id) REFERENCES public.device_agent_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidates investigation_candidates_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: investigation_candidates investigation_candidates_hunt_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_hunt_run_id_fkey FOREIGN KEY (hunt_run_id) REFERENCES public.hunt_runs(id) ON DELETE SET NULL;


--
-- Name: investigation_candidates investigation_candidates_research_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_research_episode_id_fkey FOREIGN KEY (research_episode_id) REFERENCES public.research_episodes(id) ON DELETE SET NULL;


--
-- Name: investigation_candidates investigation_candidates_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investigation_candidates
    ADD CONSTRAINT investigation_candidates_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: model_intake_admission_events model_intake_admission_events_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admission_events
    ADD CONSTRAINT model_intake_admission_events_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.model_intake_admissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_admissions model_intake_admissions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: model_intake_admissions model_intake_admissions_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE SET NULL;


--
-- Name: model_intake_admissions model_intake_admissions_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_admissions
    ADD CONSTRAINT model_intake_admissions_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: model_intake_agent_actions model_intake_agent_actions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_agent_actions
    ADD CONSTRAINT model_intake_agent_actions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.model_intake_agent_sessions(id) ON DELETE CASCADE;


--
-- Name: model_intake_agent_sessions model_intake_agent_sessions_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_agent_sessions
    ADD CONSTRAINT model_intake_agent_sessions_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_approval_receipts model_intake_approval_receipts_evidence_manifest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_approval_receipts
    ADD CONSTRAINT model_intake_approval_receipts_evidence_manifest_id_fkey FOREIGN KEY (evidence_manifest_id) REFERENCES public.model_intake_evidence_manifests(id) ON DELETE CASCADE;


--
-- Name: model_intake_approval_receipts model_intake_approval_receipts_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_approval_receipts
    ADD CONSTRAINT model_intake_approval_receipts_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_calibration_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_calibration_job_id_fkey FOREIGN KEY (calibration_job_id) REFERENCES public.model_intake_runner_jobs(id) ON DELETE SET NULL;


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_conversion_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_conversion_job_id_fkey FOREIGN KEY (conversion_job_id) REFERENCES public.model_intake_runner_jobs(id) ON DELETE SET NULL;


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_runtime_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_runtime_job_id_fkey FOREIGN KEY (runtime_job_id) REFERENCES public.model_intake_runner_jobs(id) ON DELETE SET NULL;


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: model_intake_automatic_reviews model_intake_automatic_reviews_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_automatic_reviews
    ADD CONSTRAINT model_intake_automatic_reviews_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE SET NULL;


--
-- Name: model_intake_deployment_bindings model_intake_deployment_bindings_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_deployment_bindings
    ADD CONSTRAINT model_intake_deployment_bindings_admission_id_fkey FOREIGN KEY (admission_id) REFERENCES public.model_intake_admissions(id) ON DELETE SET NULL;


--
-- Name: model_intake_deployment_bindings model_intake_deployment_bindings_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_deployment_bindings
    ADD CONSTRAINT model_intake_deployment_bindings_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_evidence_manifests model_intake_evidence_manifests_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_manifests
    ADD CONSTRAINT model_intake_evidence_manifests_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_evidence_manifests model_intake_evidence_manifests_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_manifests
    ADD CONSTRAINT model_intake_evidence_manifests_supersedes_id_fkey FOREIGN KEY (supersedes_id) REFERENCES public.model_intake_evidence_manifests(id) ON DELETE SET NULL;


--
-- Name: model_intake_evidence_records model_intake_evidence_records_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_records
    ADD CONSTRAINT model_intake_evidence_records_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_evidence_records model_intake_evidence_records_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_evidence_records
    ADD CONSTRAINT model_intake_evidence_records_supersedes_id_fkey FOREIGN KEY (supersedes_id) REFERENCES public.model_intake_evidence_records(id) ON DELETE SET NULL;


--
-- Name: model_intake_policy_decisions model_intake_policy_decisions_evidence_manifest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_policy_decisions
    ADD CONSTRAINT model_intake_policy_decisions_evidence_manifest_id_fkey FOREIGN KEY (evidence_manifest_id) REFERENCES public.model_intake_evidence_manifests(id) ON DELETE CASCADE;


--
-- Name: model_intake_policy_decisions model_intake_policy_decisions_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_policy_decisions
    ADD CONSTRAINT model_intake_policy_decisions_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_runner_jobs model_intake_runner_jobs_evidence_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_runner_jobs
    ADD CONSTRAINT model_intake_runner_jobs_evidence_record_id_fkey FOREIGN KEY (evidence_record_id) REFERENCES public.model_intake_evidence_records(id) ON DELETE SET NULL;


--
-- Name: model_intake_runner_jobs model_intake_runner_jobs_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_runner_jobs
    ADD CONSTRAINT model_intake_runner_jobs_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_subjects model_intake_subjects_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_subjects
    ADD CONSTRAINT model_intake_subjects_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_submission_events model_intake_submission_events_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_submission_events
    ADD CONSTRAINT model_intake_submission_events_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.model_intake_submissions(id) ON DELETE CASCADE;


--
-- Name: model_intake_submissions model_intake_submissions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_intake_submissions
    ADD CONSTRAINT model_intake_submissions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: node_credentials node_credentials_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_credentials
    ADD CONSTRAINT node_credentials_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: operation_plans operation_plans_approval_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_plans
    ADD CONSTRAINT operation_plans_approval_receipt_id_fkey FOREIGN KEY (approval_receipt_id) REFERENCES public.approval_receipts(id) ON DELETE SET NULL;


--
-- Name: operation_plans operation_plans_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_plans
    ADD CONSTRAINT operation_plans_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: refuter_reviews refuter_reviews_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refuter_reviews
    ADD CONSTRAINT refuter_reviews_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: refuter_reviews refuter_reviews_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refuter_reviews
    ADD CONSTRAINT refuter_reviews_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id) ON DELETE SET NULL;


--
-- Name: refuter_reviews refuter_reviews_hypothesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refuter_reviews
    ADD CONSTRAINT refuter_reviews_hypothesis_id_fkey FOREIGN KEY (hypothesis_id) REFERENCES public.hypotheses(id) ON DELETE SET NULL;


--
-- Name: refuter_reviews refuter_reviews_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refuter_reviews
    ADD CONSTRAINT refuter_reviews_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: request_collection_bindings request_collection_bindings_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_bindings
    ADD CONSTRAINT request_collection_bindings_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.request_collections(id) ON DELETE CASCADE;


--
-- Name: request_collection_bindings request_collection_bindings_environment_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_bindings
    ADD CONSTRAINT request_collection_bindings_environment_fk FOREIGN KEY (environment_id, collection_id) REFERENCES public.request_collection_environments(id, collection_id);


--
-- Name: request_collection_environments request_collection_environments_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_environments
    ADD CONSTRAINT request_collection_environments_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.request_collections(id) ON DELETE CASCADE;


--
-- Name: request_collection_requests request_collection_requests_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_requests
    ADD CONSTRAINT request_collection_requests_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.request_collections(id) ON DELETE CASCADE;


--
-- Name: request_collection_selections request_collection_selections_binding_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_selections
    ADD CONSTRAINT request_collection_selections_binding_fk FOREIGN KEY (binding_id, collection_id) REFERENCES public.request_collection_bindings(id, collection_id) ON DELETE CASCADE;


--
-- Name: request_collection_selections request_collection_selections_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collection_selections
    ADD CONSTRAINT request_collection_selections_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.request_collections(id) ON DELETE CASCADE;


--
-- Name: request_collections request_collections_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collections
    ADD CONSTRAINT request_collections_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: request_collections request_collections_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_collections
    ADD CONSTRAINT request_collections_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: research_decisions research_decisions_command_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_command_result_id_fkey FOREIGN KEY (command_result_id) REFERENCES public.command_results(id) ON DELETE SET NULL;


--
-- Name: research_decisions research_decisions_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.research_episodes(id) ON DELETE CASCADE;


--
-- Name: research_decisions research_decisions_hypothesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_hypothesis_id_fkey FOREIGN KEY (hypothesis_id) REFERENCES public.hypotheses(id) ON DELETE SET NULL;


--
-- Name: research_decisions research_decisions_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_decisions
    ADD CONSTRAINT research_decisions_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.research_observations(id) ON DELETE CASCADE;


--
-- Name: research_episodes research_episodes_approval_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_approval_receipt_id_fkey FOREIGN KEY (approval_receipt_id) REFERENCES public.approval_receipts(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_current_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_current_decision_id_fkey FOREIGN KEY (current_decision_id) REFERENCES public.research_decisions(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_current_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_current_observation_id_fkey FOREIGN KEY (current_observation_id) REFERENCES public.research_observations(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_operation_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_operation_plan_id_fkey FOREIGN KEY (operation_plan_id) REFERENCES public.operation_plans(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: research_episodes research_episodes_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_episodes
    ADD CONSTRAINT research_episodes_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: research_events research_events_command_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events
    ADD CONSTRAINT research_events_command_result_id_fkey FOREIGN KEY (command_result_id) REFERENCES public.command_results(id) ON DELETE SET NULL;


--
-- Name: research_events research_events_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events
    ADD CONSTRAINT research_events_decision_id_fkey FOREIGN KEY (decision_id) REFERENCES public.research_decisions(id) ON DELETE SET NULL;


--
-- Name: research_events research_events_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events
    ADD CONSTRAINT research_events_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.research_episodes(id) ON DELETE CASCADE;


--
-- Name: research_events research_events_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_events
    ADD CONSTRAINT research_events_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.research_observations(id) ON DELETE SET NULL;


--
-- Name: research_observations research_observations_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_observations
    ADD CONSTRAINT research_observations_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.research_episodes(id) ON DELETE CASCADE;


--
-- Name: research_observations research_observations_previous_command_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_observations
    ADD CONSTRAINT research_observations_previous_command_result_id_fkey FOREIGN KEY (previous_command_result_id) REFERENCES public.command_results(id) ON DELETE SET NULL;


--
-- Name: scan_action_attempt_checkpoints scan_action_attempt_checkpoints_scan_id_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_attempt_checkpoints
    ADD CONSTRAINT scan_action_attempt_checkpoints_scan_id_action_id_fkey FOREIGN KEY (scan_id, action_id) REFERENCES public.scan_capability_actions(scan_id, action_id) ON DELETE CASCADE;


--
-- Name: scan_action_attempt_checkpoints scan_action_attempt_checkpoints_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_attempt_checkpoints
    ADD CONSTRAINT scan_action_attempt_checkpoints_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_action_plan_revisions scan_action_plan_revisions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_action_plan_revisions
    ADD CONSTRAINT scan_action_plan_revisions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_artifacts scan_artifacts_parent_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_artifacts
    ADD CONSTRAINT scan_artifacts_parent_scan_id_fkey FOREIGN KEY (parent_scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_artifacts scan_artifacts_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_artifacts
    ADD CONSTRAINT scan_artifacts_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_campaigns scan_campaigns_parent_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_campaigns
    ADD CONSTRAINT scan_campaigns_parent_scan_id_fkey FOREIGN KEY (parent_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: scan_campaigns scan_campaigns_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_campaigns
    ADD CONSTRAINT scan_campaigns_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: scan_capability_actions scan_capability_actions_reservation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_capability_actions
    ADD CONSTRAINT scan_capability_actions_reservation_fk FOREIGN KEY (reservation_id, reservation_owner_kind, reservation_owner_id, action_id, action_digest) REFERENCES public.budget_reservations(id, owner_kind, owner_id, action_id, action_digest) ON DELETE RESTRICT;


--
-- Name: scan_capability_actions scan_capability_actions_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_capability_actions
    ADD CONSTRAINT scan_capability_actions_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_observation_manifests scan_observation_manifests_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_observation_manifests
    ADD CONSTRAINT scan_observation_manifests_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_stage_checkpoints scan_stage_checkpoints_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_stage_checkpoints
    ADD CONSTRAINT scan_stage_checkpoints_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scan_work_manifests scan_work_manifests_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_work_manifests
    ADD CONSTRAINT scan_work_manifests_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE CASCADE;


--
-- Name: scans scans_ai_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_ai_target_id_fkey FOREIGN KEY (ai_target_id) REFERENCES public.ai_targets(id) ON DELETE SET NULL;


--
-- Name: scans scans_baseline_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_baseline_scan_id_fkey FOREIGN KEY (baseline_scan_id) REFERENCES public.scans(id);


--
-- Name: scans scans_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: scans scans_device_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_device_target_id_fkey FOREIGN KEY (device_target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: scans scans_executing_node_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_executing_node_fk FOREIGN KEY (executing_node_id) REFERENCES public.nodes(id) ON DELETE SET NULL;


--
-- Name: scans scans_parent_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_parent_scan_id_fkey FOREIGN KEY (parent_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: scans scans_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: schedules schedules_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_credential_profiles target_credential_profiles_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_credential_profiles
    ADD CONSTRAINT target_credential_profiles_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_device_profiles target_device_profiles_last_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_device_profiles
    ADD CONSTRAINT target_device_profiles_last_scan_id_fkey FOREIGN KEY (last_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: target_device_profiles target_device_profiles_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_device_profiles
    ADD CONSTRAINT target_device_profiles_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.device_policies(id) ON DELETE SET NULL;


--
-- Name: target_device_profiles target_device_profiles_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_device_profiles
    ADD CONSTRAINT target_device_profiles_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_endpoint_expectations target_endpoint_expectations_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoint_expectations
    ADD CONSTRAINT target_endpoint_expectations_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.target_endpoints(id) ON DELETE CASCADE;


--
-- Name: target_endpoint_expectations target_endpoint_expectations_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoint_expectations
    ADD CONSTRAINT target_endpoint_expectations_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.target_principals(id) ON DELETE SET NULL;


--
-- Name: target_endpoint_expectations target_endpoint_expectations_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoint_expectations
    ADD CONSTRAINT target_endpoint_expectations_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_endpoints target_endpoints_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoints
    ADD CONSTRAINT target_endpoints_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.scan_campaigns(id) ON DELETE SET NULL;


--
-- Name: target_endpoints target_endpoints_last_seen_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoints
    ADD CONSTRAINT target_endpoints_last_seen_scan_id_fkey FOREIGN KEY (last_seen_scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: target_endpoints target_endpoints_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_endpoints
    ADD CONSTRAINT target_endpoints_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_invariant_contracts target_invariant_contracts_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_invariant_contracts
    ADD CONSTRAINT target_invariant_contracts_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_principal_provisioning_attempts target_principal_provisioning_attempts_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_principal_provisioning_attempts
    ADD CONSTRAINT target_principal_provisioning_attempts_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: target_principals target_principals_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.target_principals
    ADD CONSTRAINT target_principals_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.targets(id) ON DELETE CASCADE;


--
-- Name: targets targets_asset_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT targets_asset_owner_id_fkey FOREIGN KEY (asset_owner_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: targets targets_parent_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT targets_parent_target_id_fkey FOREIGN KEY (parent_target_id) REFERENCES public.targets(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_approval_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_approval_receipt_id_fkey FOREIGN KEY (approval_receipt_id) REFERENCES public.approval_receipts(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_hunt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_hunt_id_fkey FOREIGN KEY (hunt_id) REFERENCES public.hunt_runs(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_output_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_output_artifact_id_fkey FOREIGN KEY (output_artifact_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_policy_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_policy_profile_id_fkey FOREIGN KEY (policy_profile_id) REFERENCES public.policy_profiles(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_scope_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_scope_receipt_id_fkey FOREIGN KEY (scope_receipt_id) REFERENCES public.scope_receipts(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_stderr_evidence_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_stderr_evidence_object_id_fkey FOREIGN KEY (stderr_evidence_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- Name: tool_receipts tool_receipts_stdout_evidence_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_receipts
    ADD CONSTRAINT tool_receipts_stdout_evidence_object_id_fkey FOREIGN KEY (stdout_evidence_object_id) REFERENCES public.evidence_objects(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--


